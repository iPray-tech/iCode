<?php
require_once '../config/database.php';
require_once '../includes/auth.php';
require_once '../includes/header.php';
requireAdmin();

// Get date from query parameter, default to today
$date = $_GET['date'] ?? date('Y-m-d');

// Get account closures with user details
$stmt = $conn->prepare("
    SELECT 
        ac.*,
        u.username,
        u.full_name,
        ac.total_sales as system_total,
        (ac.cash_amount - ac.total_sales) as difference
    FROM account_closures ac
    JOIN users u ON ac.requested_by = u.id
    WHERE ac.status = 'pending'
    ORDER BY ac.requested_at DESC
");
$stmt->execute();
$closures = $stmt->get_result();
?>

<div class="card">
    <div class="card-header">
        <h5 class="card-title">Pending Account Closures</h5>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Employee</th>
                        <th>System Amount</th>
                        <th>Cash Amount</th>
                        <th>Difference</th>
                        <th>Status</th>
                        <th>Notes</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($closure = $closures->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo formatDate($closure['date']); ?></td>
                            <td><?php echo htmlspecialchars($closure['full_name'] ?: $closure['username']); ?></td>
                            <td><?php echo formatMoney($closure['system_total']); ?></td>
                            <td><?php echo formatMoney($closure['cash_amount']); ?></td>
                            <td>
                                <?php 
                                $difference = $closure['difference'];
                                $class = $difference > 0 ? 'text-success' : ($difference < 0 ? 'text-danger' : '');
                                $label = $difference > 0 ? 'Excess' : ($difference < 0 ? 'Shortage' : 'Balanced');
                                echo "<span class='$class'>";
                                echo $difference != 0 ? "$label: " . formatMoney(abs($difference)) : 'Balanced';
                                echo "</span>";
                                ?>
                            </td>
                            <td>
                                <span class="badge bg-warning">Pending</span>
                            </td>
                            <td><?php echo nl2br(htmlspecialchars($closure['notes'])); ?></td>
                            <td>
                                <button type="button" class="btn btn-sm btn-success" 
                                        onclick="approveRequest(<?php echo $closure['id']; ?>)">
                                    Approve
                                </button>
                                <button type="button" class="btn btn-sm btn-danger" 
                                        onclick="rejectRequest(<?php echo $closure['id']; ?>)">
                                    Reject
                                </button>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Add a section for viewing closure history -->
<div class="card mt-4">
    <div class="card-header">
        <h5 class="card-title">Account Closure History</h5>
    </div>
    <div class="card-body">
        <!-- Date Range Filter -->
        <form class="mb-3">
            <div class="row">
                <div class="col-md-4">
                    <label>Start Date</label>
                    <input type="date" class="form-control" name="start_date" 
                           value="<?php echo $_GET['start_date'] ?? date('Y-m-01'); ?>">
                </div>
                <div class="col-md-4">
                    <label>End Date</label>
                    <input type="date" class="form-control" name="end_date" 
                           value="<?php echo $_GET['end_date'] ?? date('Y-m-d'); ?>">
                </div>
                <div class="col-md-4">
                    <label>&nbsp;</label><br>
                    <button type="submit" class="btn btn-primary">Filter</button>
                </div>
            </div>
        </form>

        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Employee</th>
                        <th>System Amount</th>
                        <th>Cash Amount</th>
                        <th>Difference</th>
                        <th>Status</th>
                        <th>Notes</th>
                        <th>Admin Notes</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $start_date = $_GET['start_date'] ?? date('Y-m-01');
                    $end_date = $_GET['end_date'] ?? date('Y-m-d');

                    $stmt = $conn->prepare("
                        SELECT 
                            ac.*,
                            u.username,
                            u.full_name,
                            ac.total_sales as system_total,
                            (ac.cash_amount - ac.total_sales) as difference,
                            au.username as approved_by_name
                        FROM account_closures ac
                        JOIN users u ON ac.requested_by = u.id
                        LEFT JOIN users au ON ac.approved_by = au.id
                        WHERE ac.date BETWEEN ? AND ?
                        ORDER BY ac.date DESC, ac.processed_at DESC
                    ");
                    $stmt->bind_param("ss", $start_date, $end_date);
                    $stmt->execute();
                    $history = $stmt->get_result();

                    while ($closure = $history->fetch_assoc()):
                    ?>
                        <tr>
                            <td><?php echo formatDate($closure['date']); ?></td>
                            <td><?php echo htmlspecialchars($closure['full_name'] ?: $closure['username']); ?></td>
                            <td><?php echo formatMoney($closure['system_total']); ?></td>
                            <td><?php echo formatMoney($closure['cash_amount']); ?></td>
                            <td>
                                <?php 
                                $difference = $closure['difference'];
                                $class = $difference > 0 ? 'text-success' : ($difference < 0 ? 'text-danger' : '');
                                $label = $difference > 0 ? 'Excess' : ($difference < 0 ? 'Shortage' : 'Balanced');
                                echo "<span class='$class'>";
                                echo $difference != 0 ? "$label: " . formatMoney(abs($difference)) : 'Balanced';
                                echo "</span>";
                                ?>
                            </td>
                            <td>
                                <?php
                                $status_class = [
                                    'pending' => 'warning',
                                    'approved' => 'success',
                                    'rejected' => 'danger'
                                ][$closure['status']];
                                ?>
                                <span class="badge bg-<?php echo $status_class; ?>">
                                    <?php echo ucfirst($closure['status']); ?>
                                </span>
                            </td>
                            <td><?php echo nl2br(htmlspecialchars($closure['notes'])); ?></td>
                            <td>
                                <?php 
                                if ($closure['admin_notes']) {
                                    echo nl2br(htmlspecialchars($closure['admin_notes']));
                                }
                                if ($closure['approved_by']) {
                                    echo "<br><small class='text-muted'>By: " . 
                                         htmlspecialchars($closure['approved_by_name']) . "</small>";
                                }
                                ?>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Details Modal -->
<div class="modal fade" id="detailsModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Account Closure Details</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" id="closureDetails">
                Loading...
            </div>
        </div>
    </div>
</div>

<script>
function approveRequest(id) {
    processAccountClosure(id, 'approved');
}

function rejectRequest(id) {
    processAccountClosure(id, 'rejected');
}

function processAccountClosure(id, status) {
    if (!confirm(`Are you sure you want to ${status} this account closure?`)) {
        return;
    }

    const notes = prompt(`Enter any notes for this ${status} action:`);
    if (notes === null) return;

    fetch('process_account_closure.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            closure_id: id,
            status: status,
            admin_notes: notes
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert(`Account closure has been ${status} successfully`);
            location.reload();
        } else {
            alert('Error: ' + (data.error || 'Unknown error occurred'));
        }
    })
    .catch(error => {
        alert('Error: ' + error);
    });
}

function viewDetails(id) {
    const modal = new bootstrap.Modal(document.getElementById('detailsModal'));
    const detailsDiv = document.getElementById('closureDetails');
    
    detailsDiv.innerHTML = 'Loading...';
    modal.show();
    
    fetch(`get_closure_details.php?id=${id}`)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                detailsDiv.innerHTML = data.html;
            } else {
                detailsDiv.innerHTML = `Error: ${data.error}`;
            }
        })
        .catch(error => {
            detailsDiv.innerHTML = `Error: ${error}`;
        });
}

function printClosure(id) {
    const printWindow = window.open('', '_blank');
    printWindow.document.write(`
        <!DOCTYPE html>
        <html>
        <head>
            <title>Account Closure Report</title>
            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
            <style>
                @media print {
                    .print-header {
                        text-align: center;
                        margin-bottom: 30px;
                    }
                    .print-header h3 {
                        margin-bottom: 5px;
                    }
                    .print-header p {
                        margin-bottom: 5px;
                    }
                    .closure-details {
                        margin-top: 20px;
                    }
                    .signatures {
                        margin-top: 50px;
                    }
                    table {
                        width: 100%;
                        margin-bottom: 1rem;
                        border-collapse: collapse;
                    }
                    th, td {
                        padding: 8px;
                        border: 1px solid #dee2e6;
                    }
                    th {
                        background-color: #f8f9fa;
                    }
                    @page {
                        margin: 2cm;
                    }
                }
            </style>
        </head>
        <body>
    `);
    
    // Get the print template content
    const template = document.getElementById('printTemplate').innerHTML;
    printWindow.document.write(template);
    
    printWindow.document.write(`
        </body>
        </html>
    `);
    
    printWindow.document.close();
    
    // Wait for resources to load
    printWindow.onload = function() {
        printWindow.print();
        // Optional: close the window after printing
        // printWindow.close();
    };
}
</script>

<?php require_once '../includes/footer.php'; ?> 