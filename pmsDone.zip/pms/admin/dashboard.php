<?php
require_once '../config/database.php';
require_once '../includes/auth.php';
require_once '../includes/header.php';
requireAdmin();

// Get admin details with activity summary
try {
    // First, get basic admin info
    $stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->bind_param("i", $_SESSION['user_id']);
    $stmt->execute();
    $admin = $stmt->get_result()->fetch_assoc();

    // Then get today's activity summary
    $stmt = $conn->prepare("
        SELECT 
            COUNT(*) as total_actions,
            COUNT(CASE WHEN action_type = 'process_account_closure' THEN 1 END) as closures_processed,
            COUNT(CASE WHEN action_type = 'update_settings' THEN 1 END) as settings_updates
        FROM user_activity 
        WHERE user_id = ? 
        AND DATE(timestamp) = CURDATE()
    ");
    $stmt->bind_param("i", $_SESSION['user_id']);
    $stmt->execute();
    $activity = $stmt->get_result()->fetch_assoc();

    // Merge activity data with admin info
    $admin = array_merge($admin, $activity);

} catch (Exception $e) {
    // If there's an error, set default values
    $admin['total_actions'] = 0;
    $admin['closures_processed'] = 0;
    $admin['settings_updates'] = 0;
}

// Get today's system overview
$today_stats = $conn->query("
    SELECT 
        COUNT(DISTINCT CASE WHEN status = 'completed' THEN s.id END) as total_sales,
        COALESCE(SUM(CASE WHEN status = 'completed' THEN total_amount ELSE 0 END), 0) as total_revenue,
        COUNT(DISTINCT CASE WHEN status = 'reversed' THEN s.id END) as reversed_sales,
        COUNT(DISTINCT employee_id) as active_employees
    FROM sales s
    WHERE DATE(sale_date) = CURDATE()
")->fetch_assoc();

// Get user details
$stmt = $conn->prepare("SELECT username, email FROM users WHERE id = ?");
$stmt->bind_param("i", $_SESSION['user_id']);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

// Get today's statistics excluding reversed sales
$today_stats_excluding_reversed = $conn->query("
    SELECT 
        COUNT(DISTINCT CASE WHEN status = 'completed' THEN s.id END) as total_sales,
        COALESCE(SUM(CASE WHEN status = 'completed' THEN total_amount ELSE 0 END), 0) as total_revenue,
        COUNT(DISTINCT CASE WHEN status = 'reversed' THEN s.id END) as reversed_sales,
        COALESCE(SUM(CASE WHEN status = 'reversed' THEN total_amount ELSE 0 END), 0) as reversed_amount,
        COALESCE(SUM(CASE 
            WHEN status = 'completed' THEN total_amount 
            WHEN status = 'reversed' THEN -total_amount 
            ELSE 0 
        END), 0) as net_revenue,
        COUNT(DISTINCT employee_id) as active_employees
    FROM sales s
    WHERE DATE(sale_date) = CURDATE()
")->fetch_assoc();

// Get low stock alerts
$low_stock_query = "
    SELECT m.*, s.name as supplier_name
    FROM medicines m
    LEFT JOIN suppliers s ON m.supplier_id = s.id
    WHERE m.stock_quantity < 10
    ORDER BY m.stock_quantity ASC
    LIMIT 5
";
$low_stock = $conn->query($low_stock_query);

// Get expiring medicines (within next 30 days)
$expiring_query = "
    SELECT m.*, s.name as supplier_name,
           DATEDIFF(m.expiry_date, CURDATE()) as days_until_expiry
    FROM medicines m
    LEFT JOIN suppliers s ON m.supplier_id = s.id
    WHERE m.expiry_date IS NOT NULL 
    AND m.expiry_date <= DATE_ADD(CURDATE(), INTERVAL 30 DAY)
    AND m.expiry_date >= CURDATE()
    ORDER BY m.expiry_date ASC
    LIMIT 5
";
$expiring = $conn->query($expiring_query);

// Get recent sales
$recent_sales = $conn->query("
    SELECT s.*, u.username as employee_name,
           COUNT(si.id) as total_items
    FROM sales s
    JOIN users u ON s.employee_id = u.id
    LEFT JOIN sale_items si ON s.id = si.sale_id
    WHERE DATE(s.sale_date) = CURDATE()
    GROUP BY s.id
    ORDER BY s.sale_date DESC
    LIMIT 5
");

// Get last 7 days revenue for chart
$revenue_data = $conn->query("
    SELECT 
        DATE(sale_date) as date,
        COALESCE(SUM(CASE 
            WHEN status = 'completed' THEN total_amount 
            WHEN status = 'reversed' THEN -total_amount 
            ELSE 0 
        END), 0) as revenue
    FROM sales
    WHERE sale_date >= DATE_SUB(CURDATE(), INTERVAL 6 DAY)
    GROUP BY DATE(sale_date)
    ORDER BY date ASC
");

$dates = [];
$revenues = [];
while ($row = $revenue_data->fetch_assoc()) {
    $dates[] = formatDate($row['date'], 'M d');
    $revenues[] = $row['revenue'];
}

// Get inventory statistics
$inventory_stats = $conn->query("
    SELECT 
        COUNT(*) as total_medicines,
        SUM(CASE WHEN stock_quantity < 10 THEN 1 ELSE 0 END) as low_stock,
        SUM(CASE WHEN expiry_date <= DATE_ADD(CURDATE(), INTERVAL 30 DAY) THEN 1 ELSE 0 END) as expiring_soon
    FROM medicines
")->fetch_assoc();

// Get top selling medicines
$top_medicines = $conn->query("
    SELECT 
        m.name,
        m.generic_name,
        SUM(si.quantity) as total_quantity,
        SUM(si.total_price) as total_revenue
    FROM sale_items si
    JOIN medicines m ON si.medicine_id = m.id
    WHERE si.sale_id IN (
        SELECT id FROM sales 
        WHERE sale_date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
    )
    GROUP BY m.id
    ORDER BY total_quantity DESC
    LIMIT 5
");

// Get top performing employees
$top_employees = $conn->query("
    SELECT 
        u.username,
        COUNT(s.id) as total_sales,
        SUM(s.total_amount) as total_revenue
    FROM users u
    JOIN sales s ON u.id = s.employee_id
    WHERE s.sale_date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
    GROUP BY u.id
    ORDER BY total_revenue DESC
    LIMIT 5
");

// Get employee performance data
$employee_performance = $conn->query("
    SELECT 
        u.username,
        COUNT(s.id) as total_sales,
        COALESCE(SUM(s.total_amount), 0) as total_revenue
    FROM users u
    LEFT JOIN sales s ON u.id = s.employee_id 
        AND DATE(s.sale_date) = CURDATE()
    WHERE u.role = 'employee'
    GROUP BY u.id, u.username
    ORDER BY total_revenue DESC
    LIMIT 5
");

// Calculate total revenue for percentage
$total_revenue = $today_stats_excluding_reversed['total_revenue'] ?? 0;
?>

<!-- Admin Profile Card -->
<div class="row mb-4">
    <div class="col-12">
        <div class="card shadow">
            <div class="card-body">
                <div class="row align-items-center">
                    <div class="col-md-2 text-center mb-3 mb-md-0">
                        <div class="rounded-circle bg-primary p-3 mx-auto" style="width: fit-content">
                            <i class="bi bi-person-circle text-white" style="font-size: 3rem;"></i>
                        </div>
                    </div>
                    <div class="col-md-4 mb-3 mb-md-0">
                        <h4 class="mb-1"><?php echo htmlspecialchars($admin['full_name'] ?? $admin['username']); ?></h4>
                        <p class="text-muted mb-2"><?php echo htmlspecialchars($admin['email']); ?></p>
                        <span class="badge bg-primary">System Administrator</span>
                    </div>
                    <div class="col-md-6">
                        <div class="row">
                            <div class="col-md-4">
                                <div class="card bg-primary text-white mb-3">
                                    <div class="card-body p-3">
                                        <div class="d-flex justify-content-between align-items-center">
                                            <div>
                                                <h6 class="mb-0">Today's Actions</h6>
                                                <h3 class="mb-0"><?php echo $admin['total_actions']; ?></h3>
                                            </div>
                                            <i class="bi bi-activity h3 mb-0"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="card bg-success text-white mb-3">
                                    <div class="card-body p-3">
                                        <div class="d-flex justify-content-between align-items-center">
                                            <div>
                                                <h6 class="mb-0">Closures</h6>
                                                <h3 class="mb-0"><?php echo $admin['closures_processed']; ?></h3>
                                            </div>
                                            <i class="bi bi-check-circle h3 mb-0"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="card bg-info text-white mb-3">
                                    <div class="card-body p-3">
                                        <div class="d-flex justify-content-between align-items-center">
                                            <div>
                                                <h6 class="mb-0">Settings</h6>
                                                <h3 class="mb-0"><?php echo $admin['settings_updates']; ?></h3>
                                            </div>
                                            <i class="bi bi-gear h3 mb-0"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row mb-4">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <h4 class="card-title">Welcome, <?php echo htmlspecialchars($user['username']); ?>!</h4>
                <p class="text-muted"><?php echo htmlspecialchars($user['email']); ?></p>
            </div>
        </div>
    </div>
</div>

<div class="row mb-4">
    <!-- Total Sales Today -->
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-primary shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                            Total Sales Today</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800">
                            <?php echo $today_stats['total_sales']; ?>
                        </div>
                    </div>
                    <div class="col-auto">
                        <i class="bi bi-cart text-gray-300 fs-2"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Net Revenue Today -->
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-success shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                            Net Revenue Today</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800">
                            <?php echo formatMoney($today_stats_excluding_reversed['net_revenue']); ?>
                        </div>
                    </div>
                    <div class="col-auto">
                        <i class="bi bi-currency-dollar text-gray-300 fs-2"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Reversed Sales -->
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-warning shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                            Reversed Sales Today</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800">
                            <?php echo formatMoney($today_stats_excluding_reversed['reversed_amount']); ?>
                        </div>
                    </div>
                    <div class="col-auto">
                        <i class="bi bi-arrow-return-left text-gray-300 fs-2"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Active Employees -->
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-info shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                            Active Employees Today</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800">
                            <?php echo $today_stats['active_employees']; ?>
                        </div>
                    </div>
                    <div class="col-auto">
                        <i class="bi bi-people text-gray-300 fs-2"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <!-- Revenue Chart -->
    <div class="col-xl-8 col-lg-7">
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Revenue Overview (Last 7 Days)</h6>
            </div>
            <div class="card-body">
                <canvas id="revenueChart"></canvas>
            </div>
        </div>
    </div>

    <!-- Low Stock Alerts -->
    <div class="col-xl-4 col-lg-5">
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-danger">Low Stock Alerts</h6>
            </div>
            <div class="card-body">
                <?php if ($low_stock->num_rows > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-sm">
                            <thead>
                                <tr>
                                    <th>Medicine</th>
                                    <th>Stock</th>
                                    <th>Supplier</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($item = $low_stock->fetch_assoc()): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($item['name']); ?></td>
                                    <td>
                                        <span class="badge bg-danger">
                                            <?php echo $item['stock_quantity']; ?>
                                        </span>
                                    </td>
                                    <td><?php echo htmlspecialchars($item['supplier_name']); ?></td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <p class="text-center mb-0">No low stock items</p>
                <?php endif; ?>
            </div>
        </div>

        <!-- Expiring Medicines -->
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-warning">Expiring Soon</h6>
            </div>
            <div class="card-body">
                <?php if ($expiring->num_rows > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-sm">
                            <thead>
                                <tr>
                                    <th>Medicine</th>
                                    <th>Expires In</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($item = $expiring->fetch_assoc()): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($item['name']); ?></td>
                                    <td>
                                        <span class="badge bg-warning text-dark">
                                            <?php echo $item['days_until_expiry']; ?> days
                                        </span>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <p class="text-center mb-0">No medicines expiring soon</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- Recent Sales -->
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Recent Sales Today</h6>
    </div>
    <div class="card-body">
        <?php if ($recent_sales->num_rows > 0): ?>
            <div class="table-responsive">
                <table class="table table-sm">
                    <thead>
                        <tr>
                            <th>Time</th>
                            <th>Employee</th>
                            <th>Items</th>
                            <th>Amount</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($sale = $recent_sales->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo formatDate($sale['sale_date'], 'H:i'); ?></td>
                            <td><?php echo htmlspecialchars($sale['employee_name']); ?></td>
                            <td><?php echo $sale['total_items']; ?></td>
                            <td><?php echo formatMoney($sale['total_amount']); ?></td>
                            <td>
                                <span class="badge bg-<?php echo $sale['status'] === 'completed' ? 'success' : 'danger'; ?>">
                                    <?php echo ucfirst($sale['status']); ?>
                                </span>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <p class="text-center mb-0">No sales recorded today</p>
        <?php endif; ?>
    </div>
</div>

<div class="row">
    <!-- Statistics Cards -->
    <div class="col-md-4 mb-4">
        <div class="card bg-primary text-white">
            <div class="card-body">
                <h5 class="card-title">Today's Sales</h5>
                <h2><?php echo $today_stats['total_sales']; ?></h2>
                <p class="mb-0">By <?php echo $today_stats['active_employees'] ?? 0; ?> employees</p>
            </div>
        </div>
    </div>
    
    <div class="col-md-4 mb-4">
        <div class="card bg-success text-white">
            <div class="card-body">
                <h5 class="card-title">Today's Revenue</h5>
                <h2><?php echo formatMoney($today_stats['total_revenue']); ?></h2>
            </div>
        </div>
    </div>
    
    <div class="col-md-4 mb-4">
        <div class="card bg-info text-white">
            <div class="card-body">
                <h5 class="card-title">Inventory Status</h5>
                <h2><?php echo $inventory_stats['total_medicines']; ?></h2>
                <p class="mb-0">
                    <span class="text-warning"><?php echo $inventory_stats['low_stock']; ?> low stock</span> | 
                    <span class="text-danger"><?php echo $inventory_stats['expiring_soon']; ?> expiring soon</span>
                </p>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <!-- Top Selling Medicines -->
    <div class="col-md-4 mb-4">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-0">Top Selling Products(30 Days)</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Item</th>
                                <th>Generic Name</th>
                                <th>Quantity Sold</th>
                                <th>Revenue</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($medicine = $top_medicines->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($medicine['name']); ?></td>
                                <td><?php echo htmlspecialchars($medicine['generic_name']); ?></td>
                                <td><?php echo $medicine['total_quantity']; ?></td>
                                <td><?php echo formatMoney($medicine['total_revenue']); ?></td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <!-- Top Performing Employees -->
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-0">Top Performing Employees (30 Days)</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Employee</th>
                                <th>Total Sales</th>
                                <th>Total Revenue</th>
                                <th>Performance</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($employee = $top_employees->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($employee['username']); ?></td>
                                <td><?php echo $employee['total_sales']; ?></td>
                                <td>$<?php echo number_format($employee['total_revenue'], 2); ?></td>
                                <td>
                                    <div class="progress">
                                        <?php 
                                        $percentage = ($total_revenue > 0) 
                                            ? (($employee['total_revenue'] / $total_revenue) * 100) 
                                            : 0;
                                        ?>
                                        <div class="progress-bar bg-success" role="progressbar" 
                                             style="width: <?php echo $percentage; ?>%">
                                            <?php echo number_format($percentage, 1); ?>%
                                        </div>
                                    </div>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row mb-4">
    <!-- Quick Actions -->
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-0">Management</h5>
            </div>
            <div class="card-body">
                <div class="row g-3">
                    <div class="col-md-3">
                        <a href="inventory/add.php" class="btn btn-primary w-100">
                            <i class="bi bi-box"></i> Inventory
                        </a>
                    </div>
                    <div class="col-md-3">
                        <a href="suppliers/list.php" class="btn btn-success w-100">
                            <i class="bi bi-truck"></i> Suppliers
                        </a>
                    </div>
                    <div class="col-md-3">
                        <a href="users/list.php" class="btn btn-info w-100">
                            <i class="bi bi-people"></i> Users
                        </a>
                    </div>
                    <div class="col-md-3">
                        <a href="reports/sales.php" class="btn btn-secondary w-100">
                            <i class="bi bi-graph-up"></i> View All Reports
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- After the Quick Actions card -->

<div class="row mb-4">
    <!-- Reports Section -->
    <div class="col-12">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="card-title mb-0">Reports Overview</h5>
            </div>
            <div class="card-body">
                <div class="row g-4">
                    <!-- Sales Report -->
                    <div class="col-md-4">
                        <div class="card bg-light">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-start">
                                    <div>
                                        <h6 class="card-title text-primary">Sales Reports</h6>
                                        <p class="small text-muted mb-0">View detailed sales analytics</p>
                                    </div>
                                    <div class="rounded-circle bg-primary p-2">
                                        <i class="bi bi-graph-up text-white"></i>
                                    </div>
                                </div>
                                <div class="mt-3">
                                    <a href="reports/sales.php" class="btn btn-sm btn-primary">View Report</a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Inventory Report -->
                    <div class="col-md-4">
                        <div class="card bg-light">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-start">
                                    <div>
                                        <h6 class="card-title text-success">Inventory Reports</h6>
                                        <p class="small text-muted mb-0">Track stock levels and movements</p>
                                    </div>
                                    <div class="rounded-circle bg-success p-2">
                                        <i class="bi bi-box text-white"></i>
                                    </div>
                                </div>
                                <div class="mt-3">
                                    <a href="reports/inventory.php" class="btn btn-sm btn-success">View Report</a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Audit Report -->
                    <div class="col-md-4">
                        <div class="card bg-light">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-start">
                                    <div>
                                        <h6 class="card-title text-info">Audit Reports</h6>
                                        <p class="small text-muted mb-0">Review system activities</p>
                                    </div>
                                    <div class="rounded-circle bg-info p-2">
                                        <i class="bi bi-shield-check text-white"></i>
                                    </div>
                                </div>
                                <div class="mt-3">
                                    <a href="reports/audit.php" class="btn btn-sm btn-info">View Report</a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Account Closures -->
                    <div class="col-md-4">
                        <div class="card bg-light">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-start">
                                    <div>
                                        <h6 class="card-title text-warning">Account Closures</h6>
                                        <p class="small text-muted mb-0">Daily account reconciliation</p>
                                    </div>
                                    <div class="rounded-circle bg-warning p-2">
                                        <i class="bi bi-wallet2 text-white"></i>
                                    </div>
                                </div>
                                <div class="mt-3">
                                    <a href="account_closures.php" class="btn btn-sm btn-warning">View Closures</a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Employee Performance -->
                    <div class="col-md-4">
                        <div class="card bg-light">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-start">
                                    <div>
                                        <h6 class="card-title text-danger">Employee Performance</h6>
                                        <p class="small text-muted mb-0">Staff productivity metrics</p>
                                    </div>
                                    <div class="rounded-circle bg-danger p-2">
                                        <i class="bi bi-people text-white"></i>
                                    </div>
                                </div>
                                <div class="mt-3">
                                    <a href="reports/employee_performance.php" class="btn btn-sm btn-danger">View Report</a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Expiry Tracking -->
                    <div class="col-md-4">
                        <div class="card bg-light">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-start">
                                    <div>
                                        <h6 class="card-title text-secondary">Expiry Tracking</h6>
                                        <p class="small text-muted mb-0">Monitor expiring medicines</p>
                                    </div>
                                    <div class="rounded-circle bg-secondary p-2">
                                        <i class="bi bi-calendar-x text-white"></i>
                                    </div>
                                </div>
                                <div class="mt-3">
                                    <a href="reports/expiry.php" class="btn btn-sm btn-secondary">View Report</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
// Revenue Chart
const ctx = document.getElementById('revenueChart').getContext('2d');
new Chart(ctx, {
    type: 'line',
    data: {
        labels: <?php echo json_encode($dates); ?>,
        datasets: [{
            label: 'Daily Revenue',
            data: <?php echo json_encode($revenues); ?>,
            borderColor: 'rgb(75, 192, 192)',
            tension: 0.1
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
            y: {
                beginAtZero: true,
                ticks: {
                    callback: function(value) {
                        return '<?php echo CURRENCY_SYMBOL; ?> ' + value.toLocaleString();
                    }
                }
            }
        },
        plugins: {
            tooltip: {
                callbacks: {
                    label: function(context) {
                        return '<?php echo CURRENCY_SYMBOL; ?> ' + context.parsed.y.toLocaleString();
                    }
                }
            }
        }
    }
});
</script>

<style>
.border-left-primary { border-left: 4px solid #4e73df; }
.border-left-success { border-left: 4px solid #1cc88a; }
.border-left-warning { border-left: 4px solid #f6c23e; }
.border-left-info { border-left: 4px solid #36b9cc; }
.text-gray-300 { color: #dddfeb; }
.text-gray-800 { color: #5a5c69; }
</style>

<?php require_once '../includes/footer.php'; ?>
