<?php
require_once '../config/database.php';
require_once '../includes/auth.php';
requireAdmin();

header('Content-Type: application/json');

if (isset($_GET['id'])) {
    $closure_id = (int)$_GET['id'];
    
    try {
        $stmt = $conn->prepare("
            SELECT ac.*,
                   u1.username as requested_by_name,
                   u2.username as approved_by_name
            FROM account_closures ac
            JOIN users u1 ON ac.requested_by = u1.id
            LEFT JOIN users u2 ON ac.approved_by = u2.id
            WHERE ac.id = ?
        ");
        $stmt->bind_param("i", $closure_id);
        $stmt->execute();
        $closure = $stmt->get_result()->fetch_assoc();

        if (!$closure) {
            throw new Exception('Account closure not found');
        }

        // Get sales details for the closure date
        $stmt = $conn->prepare("
            SELECT 
                COUNT(*) as total_transactions,
                COALESCE(SUM(CASE WHEN status = 'completed' THEN total_amount ELSE 0 END), 0) as total_revenue,
                COALESCE(SUM(CASE WHEN status = 'reversed' THEN total_amount ELSE 0 END), 0) as reversed_amount,
                COALESCE(SUM(CASE 
                    WHEN status = 'completed' THEN total_amount 
                    WHEN status = 'reversed' THEN -total_amount 
                    ELSE 0 
                END), 0) as net_revenue,
                COUNT(CASE WHEN payment_method = 'cash' AND status = 'completed' THEN 1 END) as cash_transactions,
                COALESCE(SUM(CASE WHEN payment_method = 'cash' AND status = 'completed' THEN total_amount ELSE 0 END), 0) as cash_sales,
                COUNT(CASE WHEN payment_method = 'card' AND status = 'completed' THEN 1 END) as card_transactions,
                COALESCE(SUM(CASE WHEN payment_method = 'card' AND status = 'completed' THEN total_amount ELSE 0 END), 0) as card_sales,
                COUNT(CASE WHEN payment_method = 'mobile_money' AND status = 'completed' THEN 1 END) as mobile_transactions,
                COALESCE(SUM(CASE WHEN payment_method = 'mobile_money' AND status = 'completed' THEN total_amount ELSE 0 END), 0) as mobile_sales
            FROM sales 
            WHERE DATE(sale_date) = ?
        ");
        $stmt->bind_param("s", $closure['date']);
        $stmt->execute();
        $sales_summary = $stmt->get_result()->fetch_assoc();

        // Prepare the HTML content
        $html = "
            <div class='modal-header'>
                <h5 class='modal-title'>Account Closure Details</h5>
                <button type='button' class='btn-close' data-bs-dismiss='modal'></button>
            </div>
            <div class='modal-body'>
                <div class='row mb-3'>
                    <div class='col-md-6'>
                        <strong>Date:</strong> " . formatDate($closure['date']) . "<br>
                        <strong>Requested By:</strong> " . htmlspecialchars($closure['requested_by_name']) . "<br>
                        <strong>Status:</strong> <span class='badge bg-" . 
                            ($closure['status'] === 'approved' ? 'success' : 
                            ($closure['status'] === 'rejected' ? 'danger' : 'warning')) . 
                            "'>" . ucfirst($closure['status']) . "</span>
                    </div>
                    <div class='col-md-6'>
                        <strong>Cash Amount:</strong> " . formatMoney($closure['cash_amount']) . "<br>
                        <strong>System Total:</strong> " . formatMoney($closure['system_total']) . "<br>
                        <strong>Difference:</strong> " . formatMoney($closure['difference']) . "
                    </div>
                </div>

                <div class='card mb-3'>
                    <div class='card-header'>
                        <h6 class='mb-0'>Sales Summary</h6>
                    </div>
                    <div class='card-body'>
                        <div class='row'>
                            <div class='col-md-4'>
                                <strong>Total Sales:</strong> " . formatMoney($sales_summary['total_revenue']) . "<br>
                                <strong>Reversed:</strong> " . formatMoney($sales_summary['reversed_amount']) . "<br>
                                <strong>Net Revenue:</strong> " . formatMoney($sales_summary['net_revenue']) . "
                            </div>
                            <div class='col-md-8'>
                                <strong>Cash Sales:</strong> " . formatMoney($sales_summary['cash_sales']) . " (" . $sales_summary['cash_transactions'] . " transactions)<br>
                                <strong>Card Sales:</strong> " . formatMoney($sales_summary['card_sales']) . " (" . $sales_summary['card_transactions'] . " transactions)<br>
                                <strong>Mobile Money:</strong> " . formatMoney($sales_summary['mobile_sales']) . " (" . $sales_summary['mobile_transactions'] . " transactions)
                            </div>
                        </div>
                    </div>
                </div>

                " . ($closure['notes'] ? "<div class='mb-3'><strong>Notes:</strong><br>" . nl2br(htmlspecialchars($closure['notes'])) . "</div>" : "") . "
                " . ($closure['admin_notes'] ? "<div class='mb-3'><strong>Admin Notes:</strong><br>" . nl2br(htmlspecialchars($closure['admin_notes'])) . "</div>" : "") . "
            </div>";

        // Add actions for pending closures
        if ($closure['status'] === 'pending') {
            $html .= "
                <div class='modal-footer'>
                    <button type='button' class='btn btn-success' onclick='processAccountClosure(" . $closure_id . ", \"approved\")'>
                        Approve
                    </button>
                    <button type='button' class='btn btn-danger' onclick='processAccountClosure(" . $closure_id . ", \"rejected\")'>
                        Reject
                    </button>
                </div>";
        }

        echo json_encode([
            'success' => true,
            'html' => $html
        ]);

    } catch (Exception $e) {
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
} else {
    echo json_encode(['success' => false, 'error' => 'No closure ID provided']);
} 