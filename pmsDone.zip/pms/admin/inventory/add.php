<?php
require_once '../../config/database.php';
require_once '../../includes/auth.php';
require_once '../../includes/header.php';
requireAdmin();

$success = $error = '';

// Get all suppliers for dropdown
$suppliers = $conn->query("SELECT id, name FROM suppliers ORDER BY name ASC");

// Define medicine categories
$categories = [
    'Antibiotics',
    'Antibactirials',
    'Analgesics',
    'Antacids',
    'Antidepressants',
    'Antidiabetics',
    'Antifungals',
    'Antihistamines',
    'Antihypertensives',
    'Antivirals',
    'Capsules',
    'Chocolates',
    'Contraceptives',
    'Cough',
    'Cold',
    'Decongestants',
    'Dietary Supplements',
    'Deodorants',
    'Hormones',
    'Immunosuppressants',
    'Laxatives',
    'Muscle Relaxants',
    'NSAIDs',
    'Sedatives',
    'Steroids',
    'Syrups',
    'Tablets',
    'Vitamins',
    'Injections',
    'Drops',
    'Creams',
    'Gels',
    'Sprays',
    'Suppositories',
    'Others'
];
sort($categories); // Sort categories alphabetically




if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'] ?? '';
    $generic_name = $_POST['generic_name'] ?? '';
    $category = $_POST['category'] ?? '';
    $supplier_id = $_POST['supplier_id'] ?? '';
    $unit_price = $_POST['unit_price'] ?? '';
    $stock_quantity = $_POST['stock_quantity'] ?? '';
    $expiry_date = $_POST['expiry_date'] ?? '';
    
    // Validate input
    if (empty($name) || empty($unit_price) || empty($stock_quantity)) {
        $error = "Name, unit price, and stock quantity are required";
    } else {
        $stmt = $conn->prepare("
            INSERT INTO medicines (
                name, generic_name, category, supplier_id, 
                unit_price, stock_quantity, expiry_date
            ) VALUES (?, ?, ?, ?, ?, ?, ?)
        ");
        
        $stmt->bind_param("sssiids", 
            $name, $generic_name, $category, $supplier_id, 
            $unit_price, $stock_quantity, $expiry_date
        );
        
        if ($stmt->execute()) {
            $medicine_id = $conn->insert_id;
            
            // Log initial stock addition
            $stmt = $conn->prepare("
                INSERT INTO stock_history (
                    medicine_id, quantity_added, expiry_date, added_by
                ) VALUES (?, ?, ?, ?)
            ");
            $stmt->bind_param("iisi", 
                $medicine_id, $stock_quantity, $expiry_date, $_SESSION['user_id']
            );
            $stmt->execute();
            
            $success = "Medicine added successfully";
            
            // Clear form data
            $_POST = array();
        } else {
            $error = "Error adding medicine: " . $conn->error;
        }
    }
}
?>

<div class="card">
    <div class="card-header">
        <h5 class="card-title mb-0">Add New Medicine</h5>
    </div>
    <div class="card-body">
        <?php if ($success): ?>
            <div class="alert alert-success"><?php echo $success; ?></div>
        <?php endif; ?>
        
        <?php if ($error): ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php endif; ?>
        
        <form method="post">
            <div class="row">
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="name" class="form-label">Medicine Name</label>
                        <input type="text" class="form-control" id="name" name="name" 
                               value="<?php echo htmlspecialchars($_POST['name'] ?? ''); ?>" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="generic_name" class="form-label">Generic Name</label>
                        <input type="text" class="form-control" id="generic_name" name="generic_name"
                               value="<?php echo htmlspecialchars($_POST['generic_name'] ?? ''); ?>">
                    </div>
                    
                    <div class="mb-3">
                        <label for="category" class="form-label">Category</label>
                        <select class="form-select" id="category" name="category" required>
                            <option value="">Select Category</option>
                            <?php foreach ($categories as $cat): ?>
                                <option value="<?php echo htmlspecialchars($cat); ?>"
                                    <?php echo (isset($_POST['category']) && $_POST['category'] === $cat) ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($cat); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="supplier_id" class="form-label">Supplier</label>
                        <select class="form-select" id="supplier_id" name="supplier_id">
                            <option value="">Select Supplier</option>
                            <?php while ($supplier = $suppliers->fetch_assoc()): ?>
                                <option value="<?php echo $supplier['id']; ?>"
                                    <?php echo (isset($_POST['supplier_id']) && $_POST['supplier_id'] == $supplier['id']) ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($supplier['name']); ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    
                    <div class="mb-3">
                        <label for="unit_price" class="form-label">Unit Price</label>
                        <div class="input-group">
                            <span class="input-group-text"><?php echo CURRENCY_SYMBOL; ?></span>
                            <input type="number" class="form-control" id="unit_price" name="unit_price" 
                                   step="0.01" min="0" value="<?php echo htmlspecialchars($_POST['unit_price'] ?? ''); ?>" required>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="stock_quantity" class="form-label">Initial Stock Quantity</label>
                        <input type="number" class="form-control" id="stock_quantity" name="stock_quantity" 
                               min="0" value="<?php echo htmlspecialchars($_POST['stock_quantity'] ?? ''); ?>" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="expiry_date" class="form-label">Expiry Date</label>
                        <input type="date" class="form-control" id="expiry_date" name="expiry_date"
                               min="<?php echo date('Y-m-d'); ?>"
                               value="<?php echo htmlspecialchars($_POST['expiry_date'] ?? ''); ?>">
                    </div>
                </div>
            </div>
            
            <button type="submit" class="btn btn-primary">Add Medicine</button>
            <a href="list.php" class="btn btn-secondary">Back to Inventory</a>
        </form>
    </div>
</div>

<?php require_once '../../includes/footer.php'; ?>
