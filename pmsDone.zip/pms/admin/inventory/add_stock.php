<?php
require_once '../../config/database.php';
require_once '../../includes/auth.php';
requireAdmin();

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $medicine_id = $_POST['medicineId'] ?? '';
    $quantity = $_POST['quantity'] ?? '';
    $new_expiry_date = $_POST['newExpiryDate'] ?? '';
    
    if (empty($medicine_id) || empty($quantity) || empty($new_expiry_date)) {
        echo json_encode(['success' => false, 'error' => 'All fields are required']);
        exit;
    }
    
    // Start transaction
    $conn->begin_transaction();
    
    try {
        // Update stock quantity
        $stmt = $conn->prepare("UPDATE medicines SET stock_quantity = stock_quantity + ? WHERE id = ?");
        $stmt->bind_param("ii", $quantity, $medicine_id);
        $stmt->execute();
        
        // Log stock addition
        $stmt = $conn->prepare("INSERT INTO stock_history (medicine_id, quantity_added, expiry_date, added_by) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("iisi", $medicine_id, $quantity, $new_expiry_date, $_SESSION['user_id']);
        $stmt->execute();
        
        $conn->commit();
        echo json_encode(['success' => true]);
    } catch (Exception $e) {
        $conn->rollback();
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
} else {
    echo json_encode(['success' => false, 'error' => 'Invalid request method']);
}
?> 