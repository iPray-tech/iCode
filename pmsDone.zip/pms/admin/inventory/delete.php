<?php
require_once '../../config/database.php';
require_once '../../includes/auth.php';
requireAdmin();

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'] ?? '';
    
    if (empty($id)) {
        echo json_encode(['success' => false, 'error' => 'Medicine ID is required']);
        exit;
    }
    
    // Check if medicine exists
    $stmt = $conn->prepare("SELECT id FROM medicines WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    if ($stmt->get_result()->num_rows === 0) {
        echo json_encode(['success' => false, 'error' => 'Medicine not found']);
        exit;
    }
    
    // Start transaction
    $conn->begin_transaction();
    
    try {
        // Delete related records in stock_history
        $stmt = $conn->prepare("DELETE FROM stock_history WHERE medicine_id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        
        // Delete related records in sale_items
        $stmt = $conn->prepare("DELETE FROM sale_items WHERE medicine_id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        
        // Delete the medicine
        $stmt = $conn->prepare("DELETE FROM medicines WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        
        $conn->commit();
        echo json_encode(['success' => true]);
    } catch (Exception $e) {
        $conn->rollback();
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
} else {
    echo json_encode(['success' => false, 'error' => 'Invalid request method']);
}
?> 