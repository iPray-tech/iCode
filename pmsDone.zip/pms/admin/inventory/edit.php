<?php
require_once '../../config/database.php';
require_once '../../includes/auth.php';
require_once '../../includes/header.php';
requireAdmin();

$success = $error = '';
$medicine = null;

if (isset($_GET['id'])) {
    $id = (int)$_GET['id'];
    $stmt = $conn->prepare("SELECT * FROM medicines WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $medicine = $stmt->get_result()->fetch_assoc();
    
    if (!$medicine) {
        header("Location: list.php");
        exit();
    }
}

// Get all suppliers for dropdown
$suppliers = $conn->query("SELECT id, name FROM suppliers ORDER BY name ASC");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'] ?? '';
    $generic_name = $_POST['generic_name'] ?? '';
    $category = $_POST['category'] ?? '';
    $supplier_id = $_POST['supplier_id'] ?? '';
    $unit_price = $_POST['unit_price'] ?? '';
    $expiry_date = $_POST['expiry_date'] ?? '';
    
    if (empty($name) || empty($unit_price)) {
        $error = "Name and unit price are required";
    } else {
        $stmt = $conn->prepare("UPDATE medicines SET name=?, generic_name=?, category=?, supplier_id=?, unit_price=?, expiry_date=? WHERE id=?");
        $stmt->bind_param("sssiisi", $name, $generic_name, $category, $supplier_id, $unit_price, $expiry_date, $id);
        
        if ($stmt->execute()) {
            $success = "Medicine updated successfully";
            // Refresh medicine data
            $stmt = $conn->prepare("SELECT * FROM medicines WHERE id = ?");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $medicine = $stmt->get_result()->fetch_assoc();
        } else {
            $error = "Error updating medicine: " . $conn->error;
        }
    }
}
?>

<div class="card">
    <div class="card-header">
        <h5 class="card-title mb-0">Edit Medicine</h5>
    </div>
    <div class="card-body">
        <?php if ($success): ?>
            <div class="alert alert-success"><?php echo $success; ?></div>
        <?php endif; ?>
        
        <?php if ($error): ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php endif; ?>
        
        <form method="POST" action="">
            <div class="row">
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="name" class="form-label">Medicine Name</label>
                        <input type="text" class="form-control" id="name" name="name" value="<?php echo htmlspecialchars($medicine['name']); ?>" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="generic_name" class="form-label">Generic Name</label>
                        <input type="text" class="form-control" id="generic_name" name="generic_name" value="<?php echo htmlspecialchars($medicine['generic_name']); ?>">
                    </div>
                    
                    <div class="mb-3">
                        <label for="category" class="form-label">Category</label>
                        <select class="form-control" id="category" name="category">
                            <option value="">Select Category</option>
                            <?php
                            $categories = [
                                'Antibiotics',
                                'Antibactirials',
                                'Analgesics',
                                'Antacids',
                                'Antidepressants',
                                'Antidiabetics',
                                'Antifungals',
                                'Antihistamines',
                                'Antihypertensives',
                                'Antivirals',
                                'Capsules',
                                'Chocolates',
                                'Contraceptives',
                                'Cough',
                                'Cold',
                                'Decongestants',
                                'Dietary Supplements',
                                'Deodorants',
                                'Hormones',
                                'Immunosuppressants',
                                'Laxatives',
                                'Muscle Relaxants',
                                'NSAIDs',
                                'Sedatives',
                                'Steroids',
                                'Syrups',
                                'Tablets',
                                'Vitamins',
                                'Injections',
                                'Drops',
                                'Creams',
                                'Gels',
                                'Sprays',
                                'Suppositories',
                                'Others'
                                    ];
                            foreach ($categories as $cat) {
                                $selected = ($medicine['category'] === $cat) ? 'selected' : '';
                                echo "<option value=\"$cat\" $selected>$cat</option>";
                            }
                            ?>
                        </select>
                    </div>
                </div>
                
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="supplier_id" class="form-label">Supplier</label>
                        <select class="form-control" id="supplier_id" name="supplier_id">
                            <option value="">Select Supplier</option>
                            <?php while ($supplier = $suppliers->fetch_assoc()): ?>
                                <option value="<?php echo $supplier['id']; ?>" <?php echo ($medicine['supplier_id'] == $supplier['id']) ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($supplier['name']); ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    
                    <div class="mb-3">
                        <label for="unit_price" class="form-label">Unit Price</label>
                        <div class="input-group">
                            <span class="input-group-text"><?php echo CURRENCY_SYMBOL; ?></span>
                            <input type="number" class="form-control" id="unit_price" name="unit_price" step="0.01" min="0" value="<?php echo htmlspecialchars($medicine['unit_price']); ?>" required>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="expiry_date" class="form-label">Expiry Date</label>
                        <input type="date" class="form-control" id="expiry_date" name="expiry_date" value="<?php echo $medicine['expiry_date']; ?>">
                    </div>
                </div>
            </div>
            
            <button type="submit" class="btn btn-primary">Update Medicine</button>
            <a href="list.php" class="btn btn-secondary">Back to Inventory</a>
        </form>
    </div>
</div>

<?php require_once '../../includes/footer.php'; ?>
