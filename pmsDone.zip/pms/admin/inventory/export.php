<?php
require_once '../../config/database.php';
require_once '../../includes/auth.php';
requireAdmin();

// Set headers for Excel download
header('Content-Type: application/vnd.ms-excel');
header('Content-Disposition: attachment; filename="inventory_report.xls"');

// Get all medicines with supplier information
$query = "SELECT m.*, s.name as supplier_name 
          FROM medicines m 
          LEFT JOIN suppliers s ON m.supplier_id = s.id 
          ORDER BY m.name ASC";
$result = $conn->query($query);

// Create Excel header
echo "Medicine ID\tName\tGeneric Name\tCategory\tSupplier\tStock Quantity\tUnit Price\tExpiry Date\n";

// Output data
while ($row = $result->fetch_assoc()) {
    echo $row['id'] . "\t";
    echo $row['name'] . "\t";
    echo $row['generic_name'] . "\t";
    echo $row['category'] . "\t";
    echo $row['supplier_name'] . "\t";
    echo $row['stock_quantity'] . "\t";
    echo $row['unit_price'] . "\t";
    echo $row['expiry_date'] . "\n";
}
?> 