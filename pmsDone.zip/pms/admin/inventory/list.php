<?php
require_once '../../config/database.php';
require_once '../../includes/auth.php';
require_once '../../includes/header.php';
requireAdmin();

// Get all medicines with supplier information
$query = "SELECT m.*, s.name as supplier_name 
          FROM medicines m 
          LEFT JOIN suppliers s ON m.supplier_id = s.id 
          ORDER BY m.name ASC";
$result = $conn->query($query);
?>

<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="card-title mb-0">Inventory Management</h5>
        <div>
            <a href="add.php" class="btn btn-primary">Add New Inventory</a>
            <button class="btn btn-success" onclick="exportToExcel()">Export to Excel</button>
        </div>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-striped" id="inventoryTable">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Generic Name</th>
                        <th>Category</th>
                        <th>Supplier</th>
                        <th>Stock</th>
                        <th>Unit Price</th>
                        <th>Expiry Date</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($medicine = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo $medicine['id']; ?></td>
                        <td><?php echo htmlspecialchars($medicine['name'] ?? ''); ?></td>
                        <td><?php echo htmlspecialchars($medicine['generic_name'] ?? ''); ?></td>
                        <td><?php echo htmlspecialchars($medicine['category'] ?? ''); ?></td>
                        <td><?php echo htmlspecialchars($medicine['supplier_name'] ?? ''); ?></td>
                        <td>
                            <?php 
                            $stock_class = $medicine['stock_quantity'] < 10 ? 'text-danger' : 'text-success';
                            echo "<span class='$stock_class'>" . ($medicine['stock_quantity'] ?? 0) . "</span>";
                            ?>
                        </td>
                        <td><?php echo formatMoney($medicine['unit_price']); ?></td>
                        <td><?php echo $medicine['expiry_date'] ?? ''; ?></td>
                        <td>
                            <?php
                            if ($medicine['expiry_date']) {
                                $days_until_expiry = (strtotime($medicine['expiry_date']) - time()) / (60 * 60 * 24);
                                if ($days_until_expiry < 0) {
                                    echo '<span class="badge bg-danger">Expired</span>';
                                } elseif ($days_until_expiry < 30) {
                                    echo '<span class="badge bg-warning">Expiring Soon</span>';
                                } else {
                                    echo '<span class="badge bg-success">Valid</span>';
                                }
                            }
                            ?>
                        </td>
                        <td>
                            <a href="edit.php?id=<?php echo $medicine['id']; ?>" class="btn btn-sm btn-warning">Edit</a>
                            <button class="btn btn-sm btn-info" onclick="addStock(<?php echo $medicine['id']; ?>)">Add Stock</button>
                            <button class="btn btn-sm btn-danger" onclick="deleteMedicine(<?php echo $medicine['id']; ?>)">Delete</button>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Add Stock Modal -->
<div class="modal fade" id="addStockModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Add Stock</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <form id="addStockForm">
                    <input type="hidden" id="medicineId" name="medicineId">
                    <div class="mb-3">
                        <label for="quantity" class="form-label">Quantity to Add</label>
                        <input type="number" class="form-control" id="quantity" name="quantity" required min="1">
                    </div>
                    <div class="mb-3">
                        <label for="newExpiryDate" class="form-label">New Batch Expiry Date</label>
                        <input type="date" class="form-control" id="newExpiryDate" name="newExpiryDate" required>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" onclick="submitAddStock()">Add Stock</button>
            </div>
        </div>
    </div>
</div>

<script>
function addStock(medicineId) {
    document.getElementById('medicineId').value = medicineId;
    new bootstrap.Modal(document.getElementById('addStockModal')).show();
}

function submitAddStock() {
    const formData = new FormData(document.getElementById('addStockForm'));
    
    fetch('add_stock.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            location.reload();
        } else {
            alert('Error adding stock: ' + data.error);
        }
    });
}

function deleteMedicine(medicineId) {
    if (confirm('Are you sure you want to delete this medicine?')) {
        fetch('delete.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: 'id=' + medicineId
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                location.reload();
            } else {
                alert('Error deleting medicine: ' + data.error);
            }
        });
    }
}

function exportToExcel() {
    window.location.href = 'export.php';
}
</script>

<?php require_once '../../includes/footer.php'; ?>
