<?php
require_once '../../config/database.php';
require_once '../../includes/auth.php';
require_once '../../includes/header.php';
requireAdmin();

// Get medicine ID from URL if provided
$medicine_id = isset($_GET['medicine_id']) ? (int)$_GET['id'] : null;

try {
    // First check if table exists
    $table_exists = $conn->query("SHOW TABLES LIKE 'stock_history'")->num_rows > 0;
    
    if (!$table_exists) {
        // Create the table if it doesn't exist
        $conn->query("
            CREATE TABLE IF NOT EXISTS stock_history (
                id INT PRIMARY KEY AUTO_INCREMENT,
                medicine_id INT NOT NULL,
                quantity_added INT NOT NULL,
                expiry_date DATE,
                added_by INT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (medicine_id) REFERENCES medicines(id) ON DELETE CASCADE,
                FOREIGN KEY (added_by) REFERENCES users(id) ON DELETE SET NULL
            )
        ");
    }

    // Get all stock history with medicine and user information
    $query = "SELECT sh.*, m.name as medicine_name, u.username as added_by_user 
              FROM stock_history sh 
              JOIN medicines m ON sh.medicine_id = m.id 
              JOIN users u ON sh.added_by = u.id ";

    if ($medicine_id) {
        $query .= "WHERE sh.medicine_id = $medicine_id ";
    }

    $query .= "ORDER BY sh.created_at DESC";
    $result = $conn->query($query);

} catch (Exception $e) {
    // If there's an error, just show empty results
    $result = false;
}
?>

<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="card-title mb-0">Stock History</h5>
        <a href="../inventory/list.php" class="btn btn-secondary">Back to Inventory</a>
    </div>
    <div class="card-body">
        <?php if ($result && $result->num_rows > 0): ?>
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Medicine</th>
                            <th>Quantity Added</th>
                            <th>Expiry Date</th>
                            <th>Added By</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($history = $result->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo date('Y-m-d H:i', strtotime($history['created_at'])); ?></td>
                            <td><?php echo htmlspecialchars($history['medicine_name']); ?></td>
                            <td><?php echo $history['quantity_added']; ?></td>
                            <td><?php echo $history['expiry_date']; ?></td>
                            <td><?php echo htmlspecialchars($history['added_by_user']); ?></td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <div class="alert alert-info">No stock history records found.</div>
        <?php endif; ?>
    </div>
</div>

<?php require_once '../../includes/footer.php'; ?> 