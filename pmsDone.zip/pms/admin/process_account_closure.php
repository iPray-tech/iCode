<?php
require_once '../config/database.php';
require_once '../includes/auth.php';
requireAdmin();

header('Content-Type: application/json');

// Get JSON input
$input = json_decode(file_get_contents('php://input'), true);

if (!isset($input['closure_id']) || !isset($input['status'])) {
    echo json_encode(['success' => false, 'error' => 'Missing required parameters']);
    exit;
}

$closure_id = (int)$input['closure_id'];
$status = $input['status'];
$admin_notes = $input['admin_notes'] ?? '';

try {
    $conn->begin_transaction();

    // Verify closure exists and is pending
    $stmt = $conn->prepare("
        SELECT * FROM account_closures 
        WHERE id = ? AND status = 'pending'
    ");
    $stmt->bind_param("i", $closure_id);
    $stmt->execute();
    $closure = $stmt->get_result()->fetch_assoc();

    if (!$closure) {
        throw new Exception('Account closure not found or already processed');
    }

    // Update closure status
    $stmt = $conn->prepare("
        UPDATE account_closures 
        SET status = ?,
            admin_notes = ?,
            approved_by = ?,
            processed_at = CURRENT_TIMESTAMP
        WHERE id = ?
    ");
    $stmt->bind_param("ssii", $status, $admin_notes, $_SESSION['user_id'], $closure_id);
    $stmt->execute();

    // Log the activity
    logUserActivity(
        $_SESSION['user_id'], 
        'account_closure_' . $status, 
        "Account closure #$closure_id " . $status . ". Notes: " . $admin_notes
    );

    $conn->commit();
    echo json_encode(['success' => true]);

} catch (Exception $e) {
    $conn->rollback();
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
} 