<?php
require_once '../../config/database.php';
require_once '../../includes/auth.php';
require_once '../../includes/header.php';
requireAdmin();

// Get date range from request, default to last 7 days
$start_date = $_GET['start_date'] ?? date('Y-m-d', strtotime('-7 days'));
$end_date = $_GET['end_date'] ?? date('Y-m-d');

// Get audit logs
$query = "
    SELECT l.*, u.username
    FROM user_activity_logs l
    LEFT JOIN users u ON l.user_id = u.id
    WHERE DATE(l.created_at) BETWEEN ? AND ?
    ORDER BY l.created_at DESC
";

$stmt = $conn->prepare($query);
$stmt->bind_param("ss", $start_date, $end_date);
$stmt->execute();
$logs = $stmt->get_result();

// Get activity summary
$summary_query = "
    SELECT 
        COUNT(*) as total_activities,
        COUNT(DISTINCT user_id) as unique_users,
        COUNT(CASE WHEN action LIKE '%login%' THEN 1 END) as login_attempts,
        COUNT(CASE WHEN action LIKE '%failed%' THEN 1 END) as failed_actions
    FROM user_activity_logs
    WHERE DATE(created_at) BETWEEN ? AND ?
";

$stmt = $conn->prepare($summary_query);
$stmt->bind_param("ss", $start_date, $end_date);
$stmt->execute();
$summary = $stmt->get_result()->fetch_assoc();
?>

<div class="card mb-4">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="card-title mb-0">Audit Log</h5>
        <div>
            <button onclick="exportToExcel()" class="btn btn-success">
                <i class="bi bi-file-excel"></i> Export to Excel
            </button>
            <button onclick="window.print()" class="btn btn-secondary">
                <i class="bi bi-printer"></i> Print Log
            </button>
        </div>
    </div>
    <div class="card-body">
        <!-- Date Range Filter -->
        <form method="GET" class="row mb-4">
            <div class="col-md-4">
                <label class="form-label">Start Date</label>
                <input type="date" class="form-control" name="start_date" 
                       value="<?php echo $start_date; ?>">
            </div>
            <div class="col-md-4">
                <label class="form-label">End Date</label>
                <input type="date" class="form-control" name="end_date" 
                       value="<?php echo $end_date; ?>">
            </div>
            <div class="col-md-4">
                <label class="form-label">&nbsp;</label>
                <button type="submit" class="btn btn-primary d-block">Apply Filter</button>
            </div>
        </form>

        <!-- Summary Cards -->
        <div class="row mb-4">
            <div class="col-md-3">
                <div class="card bg-primary text-white">
                    <div class="card-body">
                        <h6 class="card-title">Total Activities</h6>
                        <h2><?php echo $summary['total_activities']; ?></h2>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card bg-success text-white">
                    <div class="card-body">
                        <h6 class="card-title">Active Users</h6>
                        <h2><?php echo $summary['unique_users']; ?></h2>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card bg-info text-white">
                    <div class="card-body">
                        <h6 class="card-title">Login Attempts</h6>
                        <h2><?php echo $summary['login_attempts']; ?></h2>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card bg-danger text-white">
                    <div class="card-body">
                        <h6 class="card-title">Failed Actions</h6>
                        <h2><?php echo $summary['failed_actions']; ?></h2>
                    </div>
                </div>
            </div>
        </div>

        <!-- Activity Log Table -->
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Date/Time</th>
                        <th>User</th>
                        <th>Action</th>
                        <th>Details</th>
                        <th>IP Address</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($log = $logs->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo formatDate($log['created_at'], 'Y-m-d H:i:s'); ?></td>
                        <td><?php echo htmlspecialchars($log['username'] ?? 'System'); ?></td>
                        <td>
                            <?php 
                            $class = strpos($log['action'], 'failed') !== false ? 'danger' : 
                                   (strpos($log['action'], 'login') !== false ? 'info' : 'success');
                            ?>
                            <span class="badge bg-<?php echo $class; ?>">
                                <?php echo htmlspecialchars($log['action']); ?>
                            </span>
                        </td>
                        <td><?php echo htmlspecialchars($log['details'] ?? ''); ?></td>
                        <td><?php echo htmlspecialchars($log['ip_address'] ?? ''); ?></td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
function exportToExcel() {
    window.location.href = 'export_audit.php?start_date=<?php echo $start_date; ?>&end_date=<?php echo $end_date; ?>';
}
</script>

<style>
@media print {
    .navbar, .btn, footer {
        display: none !important;
    }
    .card {
        border: none !important;
    }
    .card-header {
        background: none !important;
    }
}
</style>

<?php require_once '../../includes/footer.php'; ?>
