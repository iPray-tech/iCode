<?php
require_once '../../config/database.php';
require_once '../../includes/auth.php';
require_once '../../includes/header.php';
requireAdmin();

// Get date range from query parameters, default to current month
$start_date = $_GET['start_date'] ?? date('Y-m-01');
$end_date = $_GET['end_date'] ?? date('Y-m-t');

// Get employee performance data
$stmt = $conn->prepare("
    SELECT 
        u.id,
        u.username,
        u.full_name,
        COUNT(DISTINCT CASE WHEN s.status = 'completed' THEN s.id END) as total_sales,
        COALESCE(SUM(CASE WHEN s.status = 'completed' THEN s.total_amount ELSE 0 END), 0) as total_revenue,
        COUNT(DISTINCT CASE WHEN s.status = 'reversed' THEN s.id END) as reversed_sales,
        COALESCE(SUM(CASE WHEN s.status = 'reversed' THEN s.total_amount ELSE 0 END), 0) as reversed_amount,
        COALESCE(SUM(CASE 
            WHEN s.status = 'completed' THEN s.total_amount 
            WHEN s.status = 'reversed' THEN -s.total_amount 
            ELSE 0 
        END), 0) as net_revenue
    FROM users u
    LEFT JOIN sales s ON u.id = s.employee_id 
        AND DATE(s.sale_date) BETWEEN ? AND ?
    WHERE u.role = 'employee'
    GROUP BY u.id, u.username, u.full_name
    ORDER BY net_revenue DESC
");

$stmt->bind_param("ss", $start_date, $end_date);
$stmt->execute();
$employees = $stmt->get_result();
?>

<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="card-title mb-0">Employee Performance Report</h5>
        <div>
            <form class="d-flex gap-2">
                <input type="date" class="form-control" name="start_date" value="<?php echo $start_date; ?>">
                <input type="date" class="form-control" name="end_date" value="<?php echo $end_date; ?>">
                <button type="submit" class="btn btn-primary">Filter</button>
            </form>
        </div>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Employee</th>
                        <th>Total Sales</th>
                        <th>Gross Revenue</th>
                        <th>Reversed Sales</th>
                        <th>Reversed Amount</th>
                        <th>Net Revenue</th>
                        <th>Performance</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($emp = $employees->fetch_assoc()): ?>
                    <tr>
                        <td>
                            <?php echo htmlspecialchars($emp['full_name']); ?>
                            <br>
                            <small class="text-muted"><?php echo htmlspecialchars($emp['username']); ?></small>
                        </td>
                        <td><?php echo $emp['total_sales']; ?></td>
                        <td><?php echo formatMoney($emp['total_revenue']); ?></td>
                        <td><?php echo $emp['reversed_sales']; ?></td>
                        <td><?php echo formatMoney($emp['reversed_amount']); ?></td>
                        <td>
                            <span class="<?php echo $emp['net_revenue'] >= 0 ? 'text-success' : 'text-danger'; ?>">
                                <?php echo formatMoney($emp['net_revenue']); ?>
                            </span>
                        </td>
                        <td>
                            <?php
                            $reversal_rate = $emp['total_sales'] > 0 ? 
                                ($emp['reversed_sales'] / $emp['total_sales']) * 100 : 0;
                            
                            if ($reversal_rate <= 5) {
                                echo '<span class="badge bg-success">Excellent</span>';
                            } elseif ($reversal_rate <= 10) {
                                echo '<span class="badge bg-warning">Good</span>';
                            } else {
                                echo '<span class="badge bg-danger">Needs Improvement</span>';
                            }
                            ?>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require_once '../../includes/footer.php'; ?> 