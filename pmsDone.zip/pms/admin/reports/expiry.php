<?php
require_once '../../config/database.php';
require_once '../../includes/auth.php';
require_once '../../includes/header.php';
requireAdmin();

// Get filter parameters
$days = isset($_GET['days']) ? (int)$_GET['days'] : 30;
$category = $_GET['category'] ?? '';

// Build the query
$query = "
    SELECT m.*, s.name as supplier_name,
           DATEDIFF(m.expiry_date, CURDATE()) as days_until_expiry
    FROM medicines m
    LEFT JOIN suppliers s ON m.supplier_id = s.id
    WHERE m.expiry_date IS NOT NULL 
    AND m.expiry_date <= DATE_ADD(CURDATE(), INTERVAL ? DAY)
    AND m.expiry_date >= CURDATE()
";

if ($category) {
    $query .= " AND m.category = ?";
}

$query .= " ORDER BY m.expiry_date ASC";

$stmt = $conn->prepare($query);

if ($category) {
    $stmt->bind_param("is", $days, $category);
} else {
    $stmt->bind_param("i", $days);
}

$stmt->execute();
$medicines = $stmt->get_result();

// Get unique categories for filter
$categories = $conn->query("SELECT DISTINCT category FROM medicines WHERE category IS NOT NULL ORDER BY category")->fetch_all(MYSQLI_ASSOC);
?>

<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="card-title mb-0">Expiry Tracking Report</h5>
        <div>
            <form class="d-flex gap-2">
                <select class="form-select" name="days">
                    <option value="30" <?php echo $days == 30 ? 'selected' : ''; ?>>Next 30 Days</option>
                    <option value="60" <?php echo $days == 60 ? 'selected' : ''; ?>>Next 60 Days</option>
                    <option value="90" <?php echo $days == 90 ? 'selected' : ''; ?>>Next 90 Days</option>
                </select>
                <select class="form-select" name="category">
                    <option value="">All Categories</option>
                    <?php foreach ($categories as $cat): ?>
                        <option value="<?php echo htmlspecialchars($cat['category']); ?>"
                                <?php echo $category === $cat['category'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($cat['category']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                <button type="submit" class="btn btn-primary">Filter</button>
            </form>
        </div>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Medicine</th>
                        <th>Category</th>
                        <th>Stock</th>
                        <th>Supplier</th>
                        <th>Expiry Date</th>
                        <th>Days Until Expiry</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($med = $medicines->fetch_assoc()): ?>
                    <tr>
                        <td>
                            <?php echo htmlspecialchars($med['name']); ?>
                            <br>
                            <small class="text-muted"><?php echo htmlspecialchars($med['generic_name']); ?></small>
                        </td>
                        <td><?php echo htmlspecialchars($med['category']); ?></td>
                        <td><?php echo $med['stock_quantity']; ?></td>
                        <td><?php echo htmlspecialchars($med['supplier_name']); ?></td>
                        <td><?php echo formatDate($med['expiry_date']); ?></td>
                        <td><?php echo $med['days_until_expiry']; ?> days</td>
                        <td>
                            <?php
                            if ($med['days_until_expiry'] <= 7) {
                                echo '<span class="badge bg-danger">Critical</span>';
                            } elseif ($med['days_until_expiry'] <= 30) {
                                echo '<span class="badge bg-warning">Warning</span>';
                            } else {
                                echo '<span class="badge bg-success">OK</span>';
                            }
                            ?>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require_once '../../includes/footer.php'; ?> 