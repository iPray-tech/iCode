<?php
require_once '../../config/database.php';
require_once '../../includes/auth.php';
requireAdmin();

// Set headers for Excel download
header('Content-Type: application/vnd.ms-excel');
header('Content-Disposition: attachment; filename="audit_log_' . date('Y-m-d') . '.xls"');
header('Pragma: no-cache');
header('Expires: 0');

// Get audit log data
$query = "
    SELECT 
        ua.id,
        ua.timestamp,
        u.username,
        ua.action_type,
        ua.details
    FROM user_activity ua
    JOIN users u ON ua.user_id = u.id
    ORDER BY ua.timestamp DESC
";
$result = $conn->query($query);

// Start the Excel file content
echo "
<table border='1'>
    <thead>
        <tr>
            <th colspan='5'>Audit Log Report (" . date('Y-m-d') . ")</th>
        </tr>
        <tr>
            <th>ID</th>
            <th>Timestamp</th>
            <th>User</th>
            <th>Action</th>
            <th>Details</th>
        </tr>
    </thead>
    <tbody>";

while ($row = $result->fetch_assoc()) {
    echo "<tr>
        <td>" . $row['id'] . "</td>
        <td>" . formatDate($row['timestamp'], 'Y-m-d H:i:s') . "</td>
        <td>" . htmlspecialchars($row['username']) . "</td>
        <td>" . htmlspecialchars($row['action_type']) . "</td>
        <td>" . htmlspecialchars($row['details']) . "</td>
    </tr>";
}

echo "</tbody></table>"; 