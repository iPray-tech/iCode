<?php
require_once '../../config/database.php';
require_once '../../includes/auth.php';
requireAdmin();

// Set headers for Excel download
header('Content-Type: application/vnd.ms-excel');
header('Content-Disposition: attachment; filename="inventory_report_' . date('Y-m-d') . '.xls"');
header('Pragma: no-cache');
header('Expires: 0');

// Get inventory data
$query = "
    SELECT 
        m.id,
        m.name,
        m.generic_name,
        m.stock_quantity,
        m.unit_price,
        m.expiry_date,
        s.name as supplier_name,
        DATEDIFF(m.expiry_date, CURDATE()) as days_until_expiry
    FROM medicines m
    LEFT JOIN suppliers s ON m.supplier_id = s.id
    ORDER BY m.name
";
$result = $conn->query($query);

// Start the Excel file content
echo "
<table border='1'>
    <thead>
        <tr>
            <th colspan='7'>Inventory Report (" . date('Y-m-d') . ")</th>
        </tr>
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Generic Name</th>
            <th>Stock</th>
            <th>Unit Price</th>
            <th>Expiry Date</th>
            <th>Supplier</th>
        </tr>
    </thead>
    <tbody>";

while ($row = $result->fetch_assoc()) {
    echo "<tr>
        <td>" . $row['id'] . "</td>
        <td>" . htmlspecialchars($row['name']) . "</td>
        <td>" . htmlspecialchars($row['generic_name']) . "</td>
        <td>" . $row['stock_quantity'] . "</td>
        <td>" . CURRENCY_SYMBOL . ' ' . number_format($row['unit_price'], 2) . "</td>
        <td>" . formatDate($row['expiry_date']) . "</td>
        <td>" . htmlspecialchars($row['supplier_name']) . "</td>
    </tr>";
}

echo "</tbody></table>"; 