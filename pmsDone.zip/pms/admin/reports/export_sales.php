<?php
require_once '../../config/database.php';
require_once '../../includes/auth.php';
requireAdmin();

// Get date range from request, default to current month
$start_date = $_GET['start_date'] ?? date('Y-m-01');
$end_date = $_GET['end_date'] ?? date('Y-m-t');

// Set headers for Excel download
header('Content-Type: application/vnd.ms-excel');
header('Content-Disposition: attachment; filename="sales_report_' . date('Y-m-d') . '.xls"');
header('Pragma: no-cache');
header('Expires: 0');

// Get sales data
$stmt = $conn->prepare("
    SELECT 
        s.id as sale_id,
        s.sale_date,
        s.total_amount,
        s.payment_method,
        s.status,
        u.username as employee,
        COALESCE(p.name, 'Walk-in') as customer,
        GROUP_CONCAT(CONCAT(m.name, ' (', si.quantity, ')') SEPARATOR ', ') as items
    FROM sales s
    LEFT JOIN users u ON s.employee_id = u.id
    LEFT JOIN patients p ON s.patient_id = p.id
    LEFT JOIN sale_items si ON s.id = si.sale_id
    LEFT JOIN medicines m ON si.medicine_id = m.id
    WHERE DATE(s.sale_date) BETWEEN ? AND ?
    GROUP BY s.id
    ORDER BY s.sale_date DESC
");

$stmt->bind_param("ss", $start_date, $end_date);
$stmt->execute();
$result = $stmt->get_result();

// Start the Excel file content
echo "
<table border='1'>
    <thead>
        <tr>
            <th colspan='7'>Sales Report (" . formatDate($start_date) . " to " . formatDate($end_date) . ")</th>
        </tr>
        <tr>
            <th>Sale ID</th>
            <th>Date & Time</th>
            <th>Employee</th>
            <th>Customer</th>
            <th>Items</th>
            <th>Amount</th>
            <th>Status</th>
        </tr>
    </thead>
    <tbody>";

while ($row = $result->fetch_assoc()) {
    echo "<tr>
        <td>" . $row['sale_id'] . "</td>
        <td>" . formatDate($row['sale_date'], 'Y-m-d H:i:s') . "</td>
        <td>" . htmlspecialchars($row['employee']) . "</td>
        <td>" . htmlspecialchars($row['customer']) . "</td>
        <td>" . htmlspecialchars($row['items']) . "</td>
        <td>" . formatMoney($row['total_amount']) . "</td>
        <td>" . ucfirst($row['status']) . "</td>
    </tr>";
}

// Add summary section
$summary = $conn->query("
    SELECT 
        COUNT(*) as total_sales,
        COALESCE(SUM(CASE WHEN status = 'completed' THEN total_amount ELSE 0 END), 0) as total_revenue,
        COUNT(DISTINCT CASE WHEN status = 'reversed' THEN id END) as reversed_sales,
        COALESCE(SUM(CASE WHEN status = 'reversed' THEN total_amount ELSE 0 END), 0) as reversed_amount
    FROM sales 
    WHERE DATE(sale_date) BETWEEN '$start_date' AND '$end_date'
")->fetch_assoc();

echo "
    <tr>
        <td colspan='7'>&nbsp;</td>
    </tr>
    <tr>
        <td colspan='2'><strong>Total Sales:</strong></td>
        <td colspan='5'>" . $summary['total_sales'] . "</td>
    </tr>
    <tr>
        <td colspan='2'><strong>Total Revenue:</strong></td>
        <td colspan='5'>" . formatMoney($summary['total_revenue']) . "</td>
    </tr>
    <tr>
        <td colspan='2'><strong>Reversed Sales:</strong></td>
        <td colspan='5'>" . $summary['reversed_sales'] . " (" . formatMoney($summary['reversed_amount']) . ")</td>
    </tr>
    </tbody>
</table>"; 