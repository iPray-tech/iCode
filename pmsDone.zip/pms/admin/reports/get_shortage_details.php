<?php
require_once '../../config/database.php';
require_once '../../includes/auth.php';
requireAdmin();

header('Content-Type: application/json');

if (isset($_GET['employee_id'])) {
    $employee_id = (int)$_GET['employee_id'];
    $start_date = $_GET['start_date'] ?? date('Y-m-01');
    $end_date = $_GET['end_date'] ?? date('Y-m-t');
    
    try {
        // Get employee details
        $stmt = $conn->prepare("SELECT username, full_name FROM users WHERE id = ?");
        $stmt->bind_param("i", $employee_id);
        $stmt->execute();
        $employee = $stmt->get_result()->fetch_assoc();

        // Get all shortages for the period
        $stmt = $conn->prepare("
            SELECT 
                ac.*,
                ac.total_sales - ac.cash_amount as shortage_amount,
                COUNT(s.id) as total_transactions,
                SUM(CASE WHEN s.payment_method = 'cash' THEN s.total_amount ELSE 0 END) as cash_sales
            FROM account_closures ac
            LEFT JOIN sales s ON DATE(s.sale_date) = ac.date AND s.employee_id = ac.requested_by
            WHERE ac.requested_by = ?
            AND ac.date BETWEEN ? AND ?
            AND ac.cash_amount < ac.total_sales
            GROUP BY ac.id
            ORDER BY ac.date DESC
        ");
        
        $stmt->bind_param("iss", $employee_id, $start_date, $end_date);
        $stmt->execute();
        $shortages = $stmt->get_result();

        $html = "<h6>Employee: " . htmlspecialchars($employee['full_name'] ?: $employee['username']) . "</h6>";
        $html .= "<div class='table-responsive'>";
        $html .= "<table class='table table-sm'>";
        $html .= "<thead><tr>
                    <th>Date</th>
                    <th>System Total</th>
                    <th>Cash Count</th>
                    <th>Shortage</th>
                    <th>Status</th>
                    <th>Notes</th>
                </tr></thead><tbody>";

        while ($shortage = $shortages->fetch_assoc()) {
            $html .= "<tr>";
            $html .= "<td>" . formatDate($shortage['date']) . "</td>";
            $html .= "<td>" . formatMoney($shortage['total_sales']) . "</td>";
            $html .= "<td>" . formatMoney($shortage['cash_amount']) . "</td>";
            $html .= "<td class='text-danger'>" . formatMoney($shortage['shortage_amount']) . "</td>";
            $html .= "<td><span class='badge bg-" . 
                    ($shortage['status'] == 'approved' ? 'success' : 
                    ($shortage['status'] == 'rejected' ? 'danger' : 'warning')) . 
                    "'>" . ucfirst($shortage['status']) . "</span></td>";
            $html .= "<td>" . htmlspecialchars($shortage['notes'] ?? '') . "</td>";
            $html .= "</tr>";
        }

        $html .= "</tbody></table></div>";

        echo json_encode(['success' => true, 'html' => $html]);

    } catch (Exception $e) {
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
} else {
    echo json_encode(['success' => false, 'error' => 'No employee ID provided']);
} 