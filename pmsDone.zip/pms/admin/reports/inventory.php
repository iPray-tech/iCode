<?php
require_once '../../config/database.php';
require_once '../../includes/auth.php';
require_once '../../includes/header.php';
requireAdmin();

// Get inventory summary
$summary = $conn->query("
    SELECT 
        COUNT(*) as total_medicines,
        SUM(CASE WHEN stock_quantity < 10 THEN 1 ELSE 0 END) as low_stock,
        SUM(CASE WHEN expiry_date <= DATE_ADD(CURDATE(), INTERVAL 30 DAY) THEN 1 ELSE 0 END) as expiring_soon,
        SUM(stock_quantity) as total_stock,
        SUM(stock_quantity * unit_price) as total_value
    FROM medicines
")->fetch_assoc();

// Get medicines by category
$categories = $conn->query("
    SELECT 
        category,
        COUNT(*) as total_items,
        SUM(stock_quantity) as total_stock,
        SUM(stock_quantity * unit_price) as total_value
    FROM medicines
    WHERE category IS NOT NULL
    GROUP BY category
    ORDER BY total_items DESC
");

// Get low stock medicines
$low_stock = $conn->query("
    SELECT m.*, s.name as supplier_name
    FROM medicines m
    LEFT JOIN suppliers s ON m.supplier_id = s.id
    WHERE m.stock_quantity < 10
    ORDER BY m.stock_quantity ASC
");

// Get expiring medicines
$expiring = $conn->query("
    SELECT m.*, s.name as supplier_name,
           DATEDIFF(m.expiry_date, CURDATE()) as days_until_expiry
    FROM medicines m
    LEFT JOIN suppliers s ON m.supplier_id = s.id
    WHERE m.expiry_date IS NOT NULL 
    AND m.expiry_date <= DATE_ADD(CURDATE(), INTERVAL 30 DAY)
    ORDER BY m.expiry_date ASC
");
?>

<div class="card mb-4">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="card-title mb-0">Inventory Report</h5>
        <div>
            <button onclick="exportToExcel()" class="btn btn-success">
                <i class="bi bi-file-excel"></i> Export to Excel
            </button>
            <button onclick="window.print()" class="btn btn-secondary">
                <i class="bi bi-printer"></i> Print Report
            </button>
        </div>
    </div>
    <div class="card-body">
        <!-- Summary Cards -->
        <div class="row mb-4">
            <div class="col-md-3">
                <div class="card bg-primary text-white">
                    <div class="card-body">
                        <h6 class="card-title">Total Medicines</h6>
                        <h2><?php echo $summary['total_medicines']; ?></h2>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card bg-warning text-white">
                    <div class="card-body">
                        <h6 class="card-title">Low Stock Items</h6>
                        <h2><?php echo $summary['low_stock']; ?></h2>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card bg-danger text-white">
                    <div class="card-body">
                        <h6 class="card-title">Expiring Soon</h6>
                        <h2><?php echo $summary['expiring_soon']; ?></h2>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card bg-success text-white">
                    <div class="card-body">
                        <h6 class="card-title">Total Value</h6>
                        <h2><?php echo formatMoney($summary['total_value']); ?></h2>
                    </div>
                </div>
            </div>
        </div>

        <!-- Category Analysis -->
        <h5 class="mb-3">Inventory by Category</h5>
        <div class="table-responsive mb-4">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Category</th>
                        <th>Total Items</th>
                        <th>Total Stock</th>
                        <th>Total Value</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($category = $categories->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($category['category'] ?? 'Uncategorized'); ?></td>
                        <td><?php echo $category['total_items']; ?></td>
                        <td><?php echo $category['total_stock']; ?></td>
                        <td><?php echo formatMoney($category['total_value']); ?></td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>

        <!-- Low Stock Alert -->
        <h5 class="mb-3">Low Stock Alert</h5>
        <div class="table-responsive mb-4">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Medicine</th>
                        <th>Current Stock</th>
                        <th>Supplier</th>
                        <th>Unit Price</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($item = $low_stock->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($item['name'] ?? ''); ?></td>
                        <td class="text-danger"><?php echo $item['stock_quantity']; ?></td>
                        <td><?php echo htmlspecialchars($item['supplier_name'] ?? ''); ?></td>
                        <td><?php echo formatMoney($item['unit_price']); ?></td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>

        <!-- Expiring Medicines -->
        <h5 class="mb-3">Expiring Medicines</h5>
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Medicine</th>
                        <th>Expiry Date</th>
                        <th>Days Left</th>
                        <th>Stock</th>
                        <th>Value</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($item = $expiring->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($item['name'] ?? ''); ?></td>
                        <td><?php echo $item['expiry_date']; ?></td>
                        <td>
                            <span class="badge bg-<?php echo $item['days_until_expiry'] < 0 ? 'danger' : 'warning'; ?>">
                                <?php echo $item['days_until_expiry'] < 0 ? 'Expired' : $item['days_until_expiry'] . ' days'; ?>
                            </span>
                        </td>
                        <td><?php echo $item['stock_quantity']; ?></td>
                        <td><?php echo formatMoney($item['stock_quantity'] * $item['unit_price']); ?></td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
function exportToExcel() {
    window.location.href = 'export_inventory.php';
}
</script>

<style>
@media print {
    .navbar, .btn, footer {
        display: none !important;
    }
    .card {
        border: none !important;
    }
    .card-header {
        background: none !important;
    }
}
</style>

<?php require_once '../../includes/footer.php'; ?>
