<?php
require_once '../../config/database.php';
require_once '../../includes/auth.php';
require_once '../../includes/header.php';
requireAdmin();

// Get date range from request, default to current month
$start_date = $_GET['start_date'] ?? date('Y-m-01');
$end_date = $_GET['end_date'] ?? date('Y-m-t');

// Get sales summary
$summary = $conn->query("
    SELECT 
        COUNT(DISTINCT s.id) as total_sales,
        COUNT(DISTINCT s.employee_id) as total_employees,
        COUNT(DISTINCT s.patient_id) as total_patients,
        COALESCE(SUM(CASE WHEN s.status = 'completed' THEN s.total_amount ELSE 0 END), 0) as total_revenue,
        COUNT(DISTINCT CASE WHEN s.status = 'reversed' THEN s.id END) as reversed_sales,
        COALESCE(SUM(CASE WHEN s.status = 'reversed' THEN s.total_amount ELSE 0 END), 0) as reversed_amount
    FROM sales s
    WHERE DATE(s.sale_date) BETWEEN '$start_date' AND '$end_date'
")->fetch_assoc();

// Get daily sales data
$daily_sales = $conn->query("
    SELECT 
        DATE(sale_date) as sale_date,
        COUNT(*) as num_sales,
        SUM(CASE WHEN status = 'completed' THEN total_amount ELSE 0 END) as revenue,
        COUNT(CASE WHEN status = 'reversed' THEN 1 END) as reversed_count,
        SUM(CASE WHEN status = 'reversed' THEN total_amount ELSE 0 END) as reversed_amount
    FROM sales
    WHERE DATE(sale_date) BETWEEN '$start_date' AND '$end_date'
    GROUP BY DATE(sale_date)
    ORDER BY sale_date DESC
");

// Get employee performance
$employee_sales = $conn->query("
    SELECT 
        u.username,
        COUNT(s.id) as total_sales,
        COALESCE(SUM(s.total_amount), 0) as total_revenue,
        AVG(s.total_amount) as avg_sale_value
    FROM users u
    LEFT JOIN sales s ON u.id = s.employee_id 
        AND DATE(s.sale_date) BETWEEN '$start_date' AND '$end_date'
    WHERE u.role = 'employee'
    GROUP BY u.id, u.username
    ORDER BY total_revenue DESC
");

// Get top selling medicines
$top_medicines = $conn->query("
    SELECT 
        m.name,
        m.generic_name,
        SUM(si.quantity) as total_quantity,
        SUM(si.total_price) as total_revenue
    FROM sale_items si
    JOIN medicines m ON si.medicine_id = m.id
    JOIN sales s ON si.sale_id = s.id
    WHERE DATE(s.sale_date) BETWEEN '$start_date' AND '$end_date'
    GROUP BY m.id
    ORDER BY total_quantity DESC
    LIMIT 10
");

function formatDateForDisplay($date) {
    return date('M d, Y', strtotime($date));
}
?>

<!-- Main Report Card -->
<div class="card shadow mb-4">
    <div class="card-header py-3 d-flex justify-content-between align-items-center">
        <h6 class="m-0 font-weight-bold text-primary">Sales Report</h6>
        <div class="d-flex gap-2">
            <form class="d-flex gap-2">
                <input type="date" class="form-control" name="start_date" value="<?php echo $start_date; ?>">
                <input type="date" class="form-control" name="end_date" value="<?php echo $end_date; ?>">
                <button type="submit" class="btn btn-primary">
                    <i class="bi bi-filter"></i> Filter
                </button>
                <a href="export_sales.php?start_date=<?php echo $start_date; ?>&end_date=<?php echo $end_date; ?>" 
                   class="btn btn-success">
                    <i class="bi bi-file-excel"></i> Export
                </a>
            </form>
            <button type="button" onclick="printReport()" class="btn btn-secondary">
                <i class="bi bi-printer"></i> Print
            </button>
        </div>
    </div>
    <div class="card-body">
        <!-- Summary Cards -->
        <div class="row mb-4">
            <div class="col-xl-3 col-md-6 mb-4">
                <div class="card border-left-primary shadow h-100 py-2">
                    <div class="card-body">
                        <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Total Sales</div>
                                <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $summary['total_sales']; ?></div>
                            </div>
                            <div class="col-auto">
                                <i class="bi bi-cart text-gray-300 h3 mb-0"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-3 col-md-6 mb-4">
                <div class="card border-left-success shadow h-100 py-2">
                    <div class="card-body">
                        <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold text-success text-uppercase mb-1">Total Revenue</div>
                                <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo formatMoney($summary['total_revenue']); ?></div>
                            </div>
                            <div class="col-auto">
                                <i class="bi bi-currency-dollar text-gray-300 h3 mb-0"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-3 col-md-6 mb-4">
                <div class="card border-left-warning shadow h-100 py-2">
                    <div class="card-body">
                        <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">Reversed Sales</div>
                                <div class="h5 mb-0 font-weight-bold text-gray-800">
                                    <?php echo $summary['reversed_sales']; ?>
                                    <small class="text-muted">(<?php echo formatMoney($summary['reversed_amount']); ?>)</small>
                                </div>
                            </div>
                            <div class="col-auto">
                                <i class="bi bi-arrow-return-left text-gray-300 h3 mb-0"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-3 col-md-6 mb-4">
                <div class="card border-left-info shadow h-100 py-2">
                    <div class="card-body">
                        <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Active Employees</div>
                                <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $summary['total_employees']; ?></div>
                            </div>
                            <div class="col-auto">
                                <i class="bi bi-people text-gray-300 h3 mb-0"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Daily Sales Table -->
        <div class="table-responsive">
            <table class="table table-bordered table-striped">
                <thead class="bg-light">
                    <tr>
                        <th>Date</th>
                        <th>Sales Count</th>
                        <th>Revenue</th>
                        <th>Reversed Sales</th>
                        <th>Net Revenue</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($day = $daily_sales->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo formatDate($day['sale_date']); ?></td>
                        <td><?php echo $day['num_sales']; ?></td>
                        <td><?php echo formatMoney($day['revenue']); ?></td>
                        <td>
                            <?php if ($day['reversed_count'] > 0): ?>
                                <span class="text-danger">
                                    <?php echo $day['reversed_count']; ?> 
                                    (<?php echo formatMoney($day['reversed_amount']); ?>)
                                </span>
                            <?php else: ?>
                                <span class="text-success">None</span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo formatMoney($day['revenue'] - $day['reversed_amount']); ?></td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>

        <!-- Employee Performance -->
        <h5 class="mb-3">Employee Performance</h5>
        <div class="table-responsive mb-4">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Employee</th>
                        <th>Total Sales</th>
                        <th>Total Revenue</th>
                        <th>Average Sale Value</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($employee = $employee_sales->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($employee['username']); ?></td>
                        <td><?php echo $employee['total_sales']; ?></td>
                        <td><?php echo formatMoney($employee['total_revenue']); ?></td>
                        <td><?php echo formatMoney($employee['avg_sale_value']); ?></td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>

        <!-- Top Selling Medicines -->
        <h5 class="mb-3">Top Selling Medicines</h5>
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Medicine</th>
                        <th>Generic Name</th>
                        <th>Quantity Sold</th>
                        <th>Revenue</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($medicine = $top_medicines->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($medicine['name']); ?></td>
                        <td><?php echo htmlspecialchars($medicine['generic_name']); ?></td>
                        <td><?php echo $medicine['total_quantity']; ?></td>
                        <td><?php echo formatMoney($medicine['total_revenue']); ?></td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<style>
.border-left-primary { border-left: 4px solid #4e73df; }
.border-left-success { border-left: 4px solid #1cc88a; }
.border-left-warning { border-left: 4px solid #f6c23e; }
.border-left-info { border-left: 4px solid #36b9cc; }
.text-gray-300 { color: #dddfeb; }
.text-gray-800 { color: #5a5c69; }
@media print {
    .no-print { display: none !important; }
    .card { border: none !important; }
    .table { width: 100%; }
    .table th, .table td { border: 1px solid #ddd !important; }
}
</style>

<script>
function printReport() {
    // Create print-specific styling
    const style = `
        <style>
            @media print {
                body { padding: 20px; }
                .no-print, .btn, .card-header { display: none !important; }
                .card { border: none !important; box-shadow: none !important; }
                .card-body { padding: 0 !important; }
                .table { width: 100%; border-collapse: collapse; margin-bottom: 1rem; }
                .table th, .table td { 
                    border: 1px solid #ddd; 
                    padding: 8px; 
                    text-align: left; 
                }
                .table thead th { 
                    background-color: #f8f9fa !important; 
                    color: #000 !important;
                }
                .text-success { color: #28a745 !important; }
                .text-danger { color: #dc3545 !important; }
                .text-primary { color: #007bff !important; }
                .h5, .h6 { margin-bottom: 0.5rem; }
                .mb-4 { margin-bottom: 1.5rem !important; }
            }
        </style>
    `;

    // Get date range
    const startDate = '<?php echo formatDateForDisplay($start_date); ?>';
    const endDate = '<?php echo formatDateForDisplay($end_date); ?>';

    // Create print content
    const printContent = document.querySelector('.card-body').cloneNode(true);
    
    // Remove any unwanted elements from the clone
    printContent.querySelectorAll('.no-print, .btn').forEach(el => el.remove());

    // Open print window
    const printWindow = window.open('', '', 'height=600,width=800');
    printWindow.document.write(`
        <!DOCTYPE html>
        <html>
            <head>
                <title>Sales Report</title>
                <link href="../../assets/css/bootstrap.min.css" rel="stylesheet">
                ${style}
            </head>
            <body>
                <div class="container">
                    <h4 class="text-center mb-4">Sales Report</h4>
                    <p class="text-center mb-4">Period: ${startDate} - ${endDate}</p>
                    ${printContent.innerHTML}
                </div>
            </body>
        </html>
    `);

    printWindow.document.close();

    // Print after resources are loaded
    printWindow.onload = function() {
        setTimeout(() => {
            printWindow.print();
            printWindow.close();
        }, 250);
    };
}
</script>

<?php require_once '../../includes/footer.php'; ?>
