<?php
require_once '../../config/database.php';
require_once '../../includes/auth.php';
require_once '../../includes/header.php';
requireAdmin();

// Add this at the start of the file after requireAdmin()
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Get date range from request, default to current month
$start_date = $_GET['start_date'] ?? date('Y-m-01');
$end_date = $_GET['end_date'] ?? date('Y-m-t');

// First verify the table exists
$table_exists = $conn->query("SHOW TABLES LIKE 'account_closures'")->num_rows > 0;

if (!$table_exists) {
    echo '<div class="alert alert-warning">Account closures table not found. Please run the database setup script.</div>';
    require_once '../../includes/footer.php';
    exit;
}

// Verify table structure
$columns = $conn->query("SHOW COLUMNS FROM account_closures");
$has_total_sales = false;
while ($col = $columns->fetch_assoc()) {
    if ($col['Field'] === 'total_sales') {
        $has_total_sales = true;
        break;
    }
}

if (!$has_total_sales) {
    // Add the total_sales column if it doesn't exist
    $conn->query("ALTER TABLE account_closures ADD COLUMN total_sales DECIMAL(10,2) NOT NULL AFTER cash_amount");
}

// Add this after the table existence check
if ($table_exists) {
    // Remove the unique constraint if it exists
    $conn->query("
        ALTER TABLE account_closures 
        DROP INDEX IF EXISTS unique_date
    ");
}

// Modified query to include excess and shortage totals
$stmt = $conn->prepare("
    SELECT 
        u.id as employee_id,
        u.username,
        u.full_name,
        COUNT(ac.id) as total_closures,
        COUNT(CASE WHEN ac.cash_amount < ac.total_sales THEN 1 END) as shortage_count,
        COUNT(CASE WHEN ac.cash_amount > ac.total_sales THEN 1 END) as excess_count,
        SUM(CASE 
            WHEN ac.cash_amount < ac.total_sales 
            THEN ac.total_sales - ac.cash_amount 
            ELSE 0 
        END) as total_shortage,
        SUM(CASE 
            WHEN ac.cash_amount > ac.total_sales 
            THEN ac.cash_amount - ac.total_sales 
            ELSE 0 
        END) as total_excess,
        MAX(CASE 
            WHEN ac.cash_amount < ac.total_sales 
            THEN ac.total_sales - ac.cash_amount 
            ELSE 0 
        END) as max_shortage,
        MAX(CASE 
            WHEN ac.cash_amount > ac.total_sales 
            THEN ac.cash_amount - ac.total_sales 
            ELSE 0 
        END) as max_excess
    FROM users u
    LEFT JOIN account_closures ac ON u.id = ac.requested_by 
        AND ac.date BETWEEN ? AND ?
    WHERE u.role = 'employee'
    GROUP BY u.id, u.username, u.full_name
    HAVING shortage_count > 0 OR excess_count > 0 OR total_closures > 0
    ORDER BY total_shortage DESC
");

if (!$stmt) {
    echo '<div class="alert alert-danger">Error preparing query: ' . $conn->error . '</div>';
    require_once '../../includes/footer.php';
    exit;
}

$stmt->bind_param("ss", $start_date, $end_date);
$stmt->execute();

if ($stmt->error) {
    echo '<div class="alert alert-danger">Error executing query: ' . $stmt->error . '</div>';
}

$summaries = $stmt->get_result();

if ($summaries->num_rows === 0) {
    echo '<div class="alert alert-info">No shortages found for the selected period.</div>';
}
?>

<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="card-title mb-0">Employee Cash Differences Report</h5>
        <div>
            <button class="btn btn-success" onclick="exportToExcel()">Export to Excel</button>
        </div>
    </div>
    <div class="card-body">
        <!-- Date Range Filter -->
        <form class="mb-4" method="get">
            <div class="row">
                <div class="col-md-4">
                    <label>Start Date</label>
                    <input type="date" class="form-control" name="start_date" 
                           value="<?php echo $start_date; ?>">
                </div>
                <div class="col-md-4">
                    <label>End Date</label>
                    <input type="date" class="form-control" name="end_date" 
                           value="<?php echo $end_date; ?>">
                </div>
                <div class="col-md-4">
                    <label>&nbsp;</label><br>
                    <button type="submit" class="btn btn-primary">Filter</button>
                </div>
            </div>
        </form>

        <!-- Summary Table -->
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Employee</th>
                        <th>Total Closures</th>
                        <th>Shortages</th>
                        <th>Total Shortage</th>
                        <th>Max Shortage</th>
                        <th>Excesses</th>
                        <th>Total Excess</th>
                        <th>Max Excess</th>
                        <th>Net Difference</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($summary = $summaries->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($summary['full_name'] ?: $summary['username']); ?></td>
                            <td><?php echo $summary['total_closures']; ?></td>
                            <td>
                                <?php 
                                if ($summary['shortage_count'] > 0) {
                                    $percentage = ($summary['shortage_count'] / $summary['total_closures']) * 100;
                                    echo "<span class='text-danger'>";
                                    echo $summary['shortage_count'] . " (" . number_format($percentage, 1) . "%)";
                                    echo "</span>";
                                } else {
                                    echo "0";
                                }
                                ?>
                            </td>
                            <td class="text-danger">
                                <?php echo $summary['total_shortage'] > 0 ? formatMoney($summary['total_shortage']) : '-'; ?>
                            </td>
                            <td class="text-danger">
                                <?php echo $summary['max_shortage'] > 0 ? formatMoney($summary['max_shortage']) : '-'; ?>
                            </td>
                            <td>
                                <?php 
                                if ($summary['excess_count'] > 0) {
                                    $percentage = ($summary['excess_count'] / $summary['total_closures']) * 100;
                                    echo "<span class='text-success'>";
                                    echo $summary['excess_count'] . " (" . number_format($percentage, 1) . "%)";
                                    echo "</span>";
                                } else {
                                    echo "0";
                                }
                                ?>
                            </td>
                            <td class="text-success">
                                <?php echo $summary['total_excess'] > 0 ? formatMoney($summary['total_excess']) : '-'; ?>
                            </td>
                            <td class="text-success">
                                <?php echo $summary['max_excess'] > 0 ? formatMoney($summary['max_excess']) : '-'; ?>
                            </td>
                            <td>
                                <?php 
                                $net_difference = $summary['total_excess'] - $summary['total_shortage'];
                                $class = $net_difference > 0 ? 'text-success' : ($net_difference < 0 ? 'text-danger' : '');
                                echo "<span class='$class'>";
                                echo formatMoney(abs($net_difference));
                                echo $net_difference != 0 ? " " . ($net_difference > 0 ? "(Excess)" : "(Shortage)") : "";
                                echo "</span>";
                                ?>
                            </td>
                            <td>
                                <button type="button" class="btn btn-sm btn-info" 
                                        onclick="viewDetails(<?php echo $summary['employee_id']; ?>)">
                                    View Details
                                </button>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Details Modal -->
<div class="modal fade" id="detailsModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Shortage Details</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" id="shortageDetails">
                Loading...
            </div>
        </div>
    </div>
</div>

<script>
function viewDetails(employeeId) {
    const modal = new bootstrap.Modal(document.getElementById('detailsModal'));
    const detailsDiv = document.getElementById('shortageDetails');
    
    detailsDiv.innerHTML = 'Loading...';
    modal.show();
    
    const params = new URLSearchParams({
        employee_id: employeeId,
        start_date: '<?php echo $start_date; ?>',
        end_date: '<?php echo $end_date; ?>'
    });
    
    fetch('get_shortage_details.php?' + params)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                detailsDiv.innerHTML = data.html;
            } else {
                detailsDiv.innerHTML = `Error: ${data.error}`;
            }
        })
        .catch(error => {
            detailsDiv.innerHTML = `Error: ${error.message}`;
        });
}

function exportToExcel() {
    window.location.href = 'export_shortages.php?start_date=<?php echo $start_date; ?>&end_date=<?php echo $end_date; ?>';
}
</script>

<?php require_once '../../includes/footer.php'; ?> 