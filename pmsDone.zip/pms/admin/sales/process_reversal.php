<?php
require_once '../../config/database.php';
require_once '../../includes/auth.php';
requireAdmin();

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get JSON input
    $input = json_decode(file_get_contents('php://input'), true);
    $reversal_id = $input['reversal_id'] ?? 0;
    $status = $input['status'] ?? '';
    $admin_notes = $input['admin_notes'] ?? '';

    try {
        $conn->begin_transaction();

        // Get reversal details
        $stmt = $conn->prepare("
            SELECT r.*, s.id as sale_id 
            FROM sale_reversals r
            JOIN sales s ON r.sale_id = s.id
            WHERE r.id = ?
        ");
        $stmt->bind_param("i", $reversal_id);
        $stmt->execute();
        $reversal = $stmt->get_result()->fetch_assoc();

        if (!$reversal) {
            throw new Exception("Reversal not found");
        }

        if ($status === 'approved') {
            // Update sale status to 'reversed'
            $stmt = $conn->prepare("UPDATE sales SET status = 'reversed' WHERE id = ?");
            $stmt->bind_param("i", $reversal['sale_id']);
            $stmt->execute();

            // Get sale items to restore stock
            $stmt = $conn->prepare("SELECT medicine_id, quantity FROM sale_items WHERE sale_id = ?");
            $stmt->bind_param("i", $reversal['sale_id']);
            $stmt->execute();
            $items = $stmt->get_result();

            // Restore stock quantities
            while ($item = $items->fetch_assoc()) {
                // Update medicine stock
                $stmt = $conn->prepare("
                    UPDATE medicines 
                    SET stock_quantity = stock_quantity + ? 
                    WHERE id = ?
                ");
                $stmt->bind_param("ii", $item['quantity'], $item['medicine_id']);
                $stmt->execute();

                // Log stock adjustment
                $stmt = $conn->prepare("
                    INSERT INTO stock_history (
                        medicine_id, quantity_added, added_by, 
                        transaction_type, notes
                    ) VALUES (?, ?, ?, 'return', ?)
                ");
                $notes = "Stock restored from reversed sale #{$reversal['sale_id']}";
                $stmt->bind_param("iiis", 
                    $item['medicine_id'], 
                    $item['quantity'],
                    $_SESSION['user_id'],
                    $notes
                );
                $stmt->execute();
            }
        }

        // Update reversal status
        $stmt = $conn->prepare("
            UPDATE sale_reversals 
            SET status = ?, 
                approved_by = ?, 
                processed_at = CURRENT_TIMESTAMP,
                notes = ?
            WHERE id = ?
        ");
        $stmt->bind_param("sisi", 
            $status, 
            $_SESSION['user_id'],
            $admin_notes,
            $reversal_id
        );
        $stmt->execute();

        // Log the action
        logUserActivity(
            $_SESSION['user_id'], 
            'process_reversal', 
            "Processed sale reversal #$reversal_id - Status: $status"
        );

        $conn->commit();
        echo json_encode(['success' => true]);

    } catch (Exception $e) {
        $conn->rollback();
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
} else {
    echo json_encode(['success' => false, 'error' => 'Invalid request method']);
} 