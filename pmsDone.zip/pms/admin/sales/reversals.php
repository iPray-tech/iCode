<?php
require_once '../../config/database.php';
require_once '../../includes/auth.php';
require_once '../../includes/header.php';
requireAdmin();

// Get all reversal requests
$requests = $conn->query("
    SELECT r.*, 
           s.total_amount,
           s.sale_date,
           u1.username as requested_by_name,
           u2.username as approved_by_name
    FROM sale_reversals r
    JOIN sales s ON r.sale_id = s.id
    JOIN users u1 ON r.requested_by = u1.id
    LEFT JOIN users u2 ON r.approved_by = u2.id
    ORDER BY r.requested_at DESC
");
?>

<div class="card">
    <div class="card-header">
        <h5 class="card-title mb-0">Sale Reversal Requests</h5>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Sale ID</th>
                        <th>Amount</th>
                        <th>Requested By</th>
                        <th>Reason</th>
                        <th>Status</th>
                        <th>Requested At</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($request = $requests->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo $request['sale_id']; ?></td>
                        <td><?php echo formatMoney($request['total_amount']); ?></td>
                        <td><?php echo htmlspecialchars($request['requested_by_name']); ?></td>
                        <td><?php echo htmlspecialchars($request['reason']); ?></td>
                        <td>
                            <?php if ($request['status'] === 'pending'): ?>
                            <button onclick="processReversal(<?php echo $request['id']; ?>, 'approved')" 
                                    class="btn btn-sm btn-success">
                                <i class="bi bi-check"></i> Approve
                            </button>
                            <button onclick="processReversal(<?php echo $request['id']; ?>, 'rejected')" 
                                    class="btn btn-sm btn-danger">
                                <i class="bi bi-x"></i> Reject
                            </button>
                            <?php else: ?>
                            <?php echo ucfirst($request['status']); ?>
                            <?php endif; ?>
                        </td>
                        <td><?php echo formatDate($request['requested_at']); ?></td>
                        <td>
                            <button class="btn btn-sm btn-info" 
                                    onclick="viewSale(<?php echo $request['sale_id']; ?>)">
                                View Sale
                            </button>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
function processReversal(reversalId, status) {
    if (!confirm('Are you sure you want to ' + status + ' this reversal?')) {
        return;
    }

    const notes = prompt('Enter any notes for this ' + status + ':');
    if (notes === null) return; // User clicked cancel

    // Show loading state
    const btn = event.target;
    const originalText = btn.innerHTML;
    btn.disabled = true;
    btn.innerHTML = 'Processing...';

    fetch('process_reversal.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            reversal_id: reversalId,
            status: status,
            admin_notes: notes
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert('Reversal has been ' + status + ' successfully!');
            location.reload(); // Refresh the page
        } else {
            alert('Error: ' + (data.error || 'Unknown error occurred'));
            btn.disabled = false;
            btn.innerHTML = originalText;
        }
    })
    .catch(error => {
        alert('Error: ' + error.message);
        btn.disabled = false;
        btn.innerHTML = originalText;
    });
}

function viewSale(saleId) {
    window.location.href = `view_sale.php?id=${saleId}`;
}
</script>

<?php require_once '../../includes/footer.php'; ?> 