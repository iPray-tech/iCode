<?php
require_once '../../config/database.php';
require_once '../../includes/auth.php';
require_once '../../includes/header.php';
requireAdmin();

if (!isset($_GET['id'])) {
    header('Location: reversals.php');
    exit();
}

$reversal_id = (int)$_GET['id'];

// Get reversal details with related information
$stmt = $conn->prepare("
    SELECT r.*, 
           s.total_amount,
           s.sale_date,
           u1.username as requested_by_name,
           u2.username as approved_by_name
    FROM sale_reversals r
    JOIN sales s ON r.sale_id = s.id
    JOIN users u1 ON r.requested_by = u1.id
    LEFT JOIN users u2 ON r.approved_by = u2.id
    WHERE r.id = ?
");
$stmt->bind_param("i", $reversal_id);
$stmt->execute();
$reversal = $stmt->get_result()->fetch_assoc();

if (!$reversal) {
    header('Location: reversals.php');
    exit();
}
?>

<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="card-title mb-0">Reversal Details</h5>
        <a href="reversals.php" class="btn btn-secondary">Back to List</a>
    </div>
    <div class="card-body">
        <div class="row">
            <div class="col-md-6">
                <table class="table">
                    <tr>
                        <th>Sale ID:</th>
                        <td><?php echo htmlspecialchars($reversal['sale_id']); ?></td>
                    </tr>
                    <tr>
                        <th>Status:</th>
                        <td>
                            <span class="badge bg-<?php 
                                echo $reversal['status'] === 'pending' ? 'warning' : 
                                    ($reversal['status'] === 'approved' ? 'success' : 'danger'); 
                            ?>">
                                <?php echo ucfirst($reversal['status']); ?>
                            </span>
                        </td>
                    </tr>
                    <tr>
                        <th>Amount:</th>
                        <td><?php echo formatMoney($reversal['total_amount']); ?></td>
                    </tr>
                    <tr>
                        <th>Requested By:</th>
                        <td><?php echo htmlspecialchars($reversal['requested_by_name']); ?></td>
                    </tr>
                    <tr>
                        <th>Requested At:</th>
                        <td><?php echo formatDate($reversal['requested_at'], 'Y-m-d H:i'); ?></td>
                    </tr>
                    <?php if ($reversal['status'] !== 'pending'): ?>
                    <tr>
                        <th>Processed By:</th>
                        <td><?php echo htmlspecialchars($reversal['approved_by_name'] ?? 'N/A'); ?></td>
                    </tr>
                    <tr>
                        <th>Processed At:</th>
                        <td><?php echo formatDate($reversal['processed_at'], 'Y-m-d H:i'); ?></td>
                    </tr>
                    <?php endif; ?>
                </table>
            </div>
            <div class="col-md-6">
                <h6>Reason for Reversal</h6>
                <p><?php echo nl2br(htmlspecialchars($reversal['reason'])); ?></p>

                <?php if (!empty($reversal['notes'])): ?>
                <h6>Admin Notes</h6>
                <p><?php echo nl2br(htmlspecialchars($reversal['notes'])); ?></p>
                <?php endif; ?>
            </div>
        </div>

        <?php if ($reversal['status'] === 'pending'): ?>
        <div class="mt-3">
            <button onclick="processReversal(<?php echo $reversal_id; ?>, 'approved')" 
                    class="btn btn-success">
                <i class="bi bi-check"></i> Approve Reversal
            </button>
            <button onclick="processReversal(<?php echo $reversal_id; ?>, 'rejected')" 
                    class="btn btn-danger">
                <i class="bi bi-x"></i> Reject Reversal
            </button>
        </div>
        <?php endif; ?>
    </div>
</div>

<script>
function processReversal(reversalId, status) {
    if (!confirm('Are you sure you want to ' + status + ' this reversal?')) {
        return;
    }

    const notes = prompt('Enter any notes for this ' + status + ':');
    if (notes === null) return;

    const btn = event.target;
    const originalText = btn.innerHTML;
    btn.disabled = true;
    btn.innerHTML = 'Processing...';

    fetch('process_reversal.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            reversal_id: reversalId,
            status: status,
            admin_notes: notes
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert('Reversal has been ' + status + ' successfully!');
            location.reload();
        } else {
            alert('Error: ' + (data.error || 'Unknown error occurred'));
            btn.disabled = false;
            btn.innerHTML = originalText;
        }
    })
    .catch(error => {
        alert('Error: ' + error.message);
        btn.disabled = false;
        btn.innerHTML = originalText;
    });
}
</script>

<?php require_once '../../includes/footer.php'; ?> 