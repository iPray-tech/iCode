<?php
require_once '../../config/database.php';
require_once '../../includes/auth.php';
require_once '../../includes/header.php';
requireAdmin();

if (!isset($_GET['id'])) {
    header("Location: list.php");
    exit();
}

$sale_id = (int)$_GET['id'];

// Get sale details including reversal information
$stmt = $conn->prepare("
    SELECT s.*, 
           u.username as employee_name,
           COALESCE(p.name, '') as patient_name,
           COALESCE(p.phone, '') as patient_phone,
           r.status as reversal_status,
           r.reason as reversal_reason,
           r.requested_at as reversal_requested_at,
           ru.username as reversal_requested_by,
           ra.username as reversal_approved_by,
           rs.total_amount as reversal_amount,
           rs.sale_date as reversal_date
    FROM sales s
    LEFT JOIN users u ON s.employee_id = u.id
    LEFT JOIN patients p ON s.patient_id = p.id
    LEFT JOIN sale_reversals r ON s.id = r.sale_id
    LEFT JOIN users ru ON r.requested_by = ru.id
    LEFT JOIN users ra ON r.approved_by = ra.id
    LEFT JOIN sales rs ON rs.reference_sale_id = s.id
    WHERE s.id = ?
");

$stmt->bind_param("i", $sale_id);
$stmt->execute();
$sale = $stmt->get_result()->fetch_assoc();

// Add reversal information to the view
if ($sale['status'] === 'reversed'): ?>
    <div class="alert alert-warning">
        <h5>Reversal Information</h5>
        <p>This sale was reversed on <?php echo formatDate($sale['reversal_date']); ?></p>
        <p>Requested by: <?php echo htmlspecialchars($sale['reversal_requested_by']); ?></p>
        <p>Reason: <?php echo htmlspecialchars($sale['reversal_reason']); ?></p>
        <p>Amount reversed: <?php echo formatMoney($sale['reversal_amount']); ?></p>
    </div>
<?php endif; ?> 