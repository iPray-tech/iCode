<?php
require_once '../../config/database.php';
require_once '../../includes/auth.php';
require_once '../../includes/header.php';
requireAdmin();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $conn->begin_transaction();
        
        // Update Paystack settings
        updateSetting('paystack_public_key', $_POST['paystack_public_key']);
        updateSetting('paystack_secret_key', $_POST['paystack_secret_key']);
        updateSetting('paystack_enabled', isset($_POST['paystack_enabled']) ? 'true' : 'false');
        
        // Update Mobile Money settings
        updateSetting('momo_merchant_id', $_POST['momo_merchant_id']);
        updateSetting('momo_merchant_key', $_POST['momo_merchant_key']);
        updateSetting('momo_enabled', isset($_POST['momo_enabled']) ? 'true' : 'false');
        
        $conn->commit();
        $success = "Payment gateway settings updated successfully";
        
    } catch (Exception $e) {
        $conn->rollback();
        $error = "Error updating settings: " . $e->getMessage();
    }
}

$settings = [
    'paystack_public_key' => getSetting('paystack_public_key'),
    'paystack_secret_key' => getSetting('paystack_secret_key'),
    'paystack_enabled' => getSetting('paystack_enabled') === 'true',
    'momo_merchant_id' => getSetting('momo_merchant_id'),
    'momo_merchant_key' => getSetting('momo_merchant_key'),
    'momo_enabled' => getSetting('momo_enabled') === 'true'
];
?>

<div class="card">
    <div class="card-header">
        <h5 class="card-title mb-0">Payment Gateway Settings</h5>
    </div>
    <div class="card-body">
        <form method="POST">
            <h6>Paystack Integration</h6>
            <div class="mb-3">
                <div class="form-check form-switch">
                    <input class="form-check-input" type="checkbox" id="paystack_enabled" 
                           name="paystack_enabled" <?php echo $settings['paystack_enabled'] ? 'checked' : ''; ?>>
                    <label class="form-check-label" for="paystack_enabled">Enable Paystack</label>
                </div>
            </div>
            <div class="mb-3">
                <label class="form-label">Public Key</label>
                <input type="text" class="form-control" name="paystack_public_key" 
                       value="<?php echo htmlspecialchars($settings['paystack_public_key']); ?>">
            </div>
            <div class="mb-3">
                <label class="form-label">Secret Key</label>
                <input type="password" class="form-control" name="paystack_secret_key" 
                       value="<?php echo htmlspecialchars($settings['paystack_secret_key']); ?>">
            </div>

            <h6 class="mt-4">Mobile Money Integration</h6>
            <div class="mb-3">
                <div class="form-check form-switch">
                    <input class="form-check-input" type="checkbox" id="momo_enabled" 
                           name="momo_enabled" <?php echo $settings['momo_enabled'] ? 'checked' : ''; ?>>
                    <label class="form-check-label" for="momo_enabled">Enable Mobile Money</label>
                </div>
            </div>
            <div class="mb-3">
                <label class="form-label">Merchant ID</label>
                <input type="text" class="form-control" name="momo_merchant_id" 
                       value="<?php echo htmlspecialchars($settings['momo_merchant_id']); ?>">
            </div>
            <div class="mb-3">
                <label class="form-label">API Key</label>
                <input type="password" class="form-control" name="momo_merchant_key" 
                       value="<?php echo htmlspecialchars($settings['momo_merchant_key']); ?>">
            </div>

            <button type="submit" class="btn btn-primary">Save Settings</button>
        </form>
    </div>
</div> 