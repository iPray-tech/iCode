<?php
require_once '../../config/database.php';
require_once '../../includes/auth.php';
requireAdmin();

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'] ?? '';
    
    if (empty($id)) {
        echo json_encode(['success' => false, 'error' => 'Supplier ID is required']);
        exit;
    }
    
    // Check if supplier exists
    $stmt = $conn->prepare("SELECT id FROM suppliers WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    if ($stmt->get_result()->num_rows === 0) {
        echo json_encode(['success' => false, 'error' => 'Supplier not found']);
        exit;
    }
    
    // Start transaction
    $conn->begin_transaction();
    
    try {
        // Update medicines to remove supplier reference
        $stmt = $conn->prepare("UPDATE medicines SET supplier_id = NULL WHERE supplier_id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        
        // Delete the supplier
        $stmt = $conn->prepare("DELETE FROM suppliers WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        
        $conn->commit();
        echo json_encode(['success' => true]);
    } catch (Exception $e) {
        $conn->rollback();
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
} else {
    echo json_encode(['success' => false, 'error' => 'Invalid request method']);
}
?> 