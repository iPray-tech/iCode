<?php
require_once '../../config/database.php';
require_once '../../includes/auth.php';
require_once '../../includes/header.php';
requireAdmin();

// Get all suppliers
$query = "SELECT s.*, 
          COUNT(m.id) as total_medicines,
          COALESCE(SUM(m.stock_quantity), 0) as total_stock
          FROM suppliers s
          LEFT JOIN medicines m ON s.id = m.supplier_id
          GROUP BY s.id
          ORDER BY s.name ASC";
$result = $conn->query($query);
?>

<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="card-title mb-0">Suppliers Management</h5>
        <a href="add.php" class="btn btn-primary">Add New Supplier</a>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Contact Person</th>
                        <th>Phone</th>
                        <th>Email</th>
                        <th>Total Medicines</th>
                        <th>Total Stock</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($supplier = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo $supplier['id']; ?></td>
                        <td><?php echo htmlspecialchars($supplier['name']); ?></td>
                        <td><?php echo htmlspecialchars($supplier['contact_person']); ?></td>
                        <td><?php echo htmlspecialchars($supplier['phone']); ?></td>
                        <td><?php echo htmlspecialchars($supplier['email']); ?></td>
                        <td><?php echo $supplier['total_medicines']; ?></td>
                        <td><?php echo $supplier['total_stock']; ?></td>
                        <td>
                            <a href="edit.php?id=<?php echo $supplier['id']; ?>" class="btn btn-sm btn-warning">Edit</a>
                            <button class="btn btn-sm btn-danger" onclick="deleteSupplier(<?php echo $supplier['id']; ?>)">Delete</button>
                            <a href="view.php?id=<?php echo $supplier['id']; ?>" class="btn btn-sm btn-info">View Details</a>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
function deleteSupplier(supplierId) {
    if (confirm('Are you sure you want to delete this supplier? This will remove the supplier reference from all associated medicines.')) {
        fetch('delete.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: 'id=' + supplierId
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                location.reload();
            } else {
                alert('Error deleting supplier: ' + data.error);
            }
        });
    }
}
</script>

<?php require_once '../../includes/footer.php'; ?>
