<?php
require_once '../../config/database.php';
require_once '../../includes/auth.php';
require_once '../../includes/header.php';
requireAdmin();

if (!isset($_GET['id'])) {
    header("Location: list.php");
    exit();
}

$id = (int)$_GET['id'];

// Get supplier details
$stmt = $conn->prepare("SELECT * FROM suppliers WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$supplier = $stmt->get_result()->fetch_assoc();

if (!$supplier) {
    header("Location: list.php");
    exit();
}

// Get supplier's medicines
$stmt = $conn->prepare("
    SELECT m.*, 
           DATEDIFF(m.expiry_date, CURDATE()) as days_until_expiry
    FROM medicines m 
    WHERE m.supplier_id = ?
    ORDER BY m.name ASC
");
$stmt->bind_param("i", $id);
$stmt->execute();
$medicines = $stmt->get_result();
?>

<div class="row">
    <div class="col-md-4">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-0">Supplier Details</h5>
            </div>
            <div class="card-body">
                <table class="table">
                    <tr>
                        <th>Name:</th>
                        <td><?php echo htmlspecialchars($supplier['name']); ?></td>
                    </tr>
                    <tr>
                        <th>Contact Person:</th>
                        <td><?php echo htmlspecialchars($supplier['contact_person']); ?></td>
                    </tr>
                    <tr>
                        <th>Phone:</th>
                        <td><?php echo htmlspecialchars($supplier['phone']); ?></td>
                    </tr>
                    <tr>
                        <th>Email:</th>
                        <td><?php echo htmlspecialchars($supplier['email']); ?></td>
                    </tr>
                    <tr>
                        <th>Address:</th>
                        <td><?php echo nl2br(htmlspecialchars($supplier['address'])); ?></td>
                    </tr>
                </table>
                
                <div class="mt-3">
                    <a href="edit.php?id=<?php echo $supplier['id']; ?>" class="btn btn-warning">Edit Supplier</a>
                    <a href="list.php" class="btn btn-secondary">Back to List</a>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-md-8">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-0">Supplied Medicines</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Category</th>
                                <th>Stock</th>
                                <th>Unit Price</th>
                                <th>Expiry Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($medicine = $medicines->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($medicine['name']); ?></td>
                                <td><?php echo htmlspecialchars($medicine['category']); ?></td>
                                <td>
                                    <?php 
                                    $stock_class = $medicine['stock_quantity'] < 10 ? 'text-danger' : 'text-success';
                                    echo "<span class='$stock_class'>" . $medicine['stock_quantity'] . "</span>";
                                    ?>
                                </td>
                                <td>$<?php echo number_format($medicine['unit_price'], 2); ?></td>
                                <td>
                                    <?php
                                    if ($medicine['expiry_date']) {
                                        if ($medicine['days_until_expiry'] < 0) {
                                            echo '<span class="badge bg-danger">Expired</span>';
                                        } elseif ($medicine['days_until_expiry'] < 30) {
                                            echo '<span class="badge bg-warning">Expiring Soon</span>';
                                        } else {
                                            echo '<span class="badge bg-success">Valid</span>';
                                        }
                                    }
                                    ?>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once '../../includes/footer.php'; ?> 