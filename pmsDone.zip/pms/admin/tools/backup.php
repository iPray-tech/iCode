<?php
require_once '../../config/database.php';
require_once '../../includes/auth.php';
requireAdmin();

function backupDatabase() {
    $backup_path = "../../backups/";
    if (!file_exists($backup_path)) {
        mkdir($backup_path, 0755, true);
    }

    $filename = "backup_" . date("Y-m-d_H-i-s") . ".sql";
    $command = sprintf(
        'mysqldump --host=%s --user=%s --password=%s %s > %s',
        DB_HOST,
        DB_USER,
        DB_PASS,
        DB_NAME,
        $backup_path . $filename
    );

    system($command, $return_var);
    return $return_var === 0;
} 