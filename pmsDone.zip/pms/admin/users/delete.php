<?php
require_once '../../config/database.php';
require_once '../../includes/auth.php';
requireAdmin();

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'error' => 'Invalid request method']);
    exit;
}

$id = $_POST['id'] ?? '';

if (empty($id)) {
    echo json_encode(['success' => false, 'error' => 'User ID is required']);
    exit;
}

// Prevent deletion of admin users
$stmt = $conn->prepare("SELECT role FROM users WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

if (!$user) {
    echo json_encode(['success' => false, 'error' => 'User not found']);
    exit;
}

if ($user['role'] === 'admin') {
    echo json_encode(['success' => false, 'error' => 'Cannot delete admin users']);
    exit;
}

try {
    $conn->begin_transaction();

    // Update sale_reversals to set requested_by to NULL
    $stmt = $conn->prepare("UPDATE sale_reversals SET requested_by = NULL WHERE requested_by = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();

    // Update sale_reversals to set approved_by to NULL
    $stmt = $conn->prepare("UPDATE sale_reversals SET approved_by = NULL WHERE approved_by = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();

    // Update stock_history to set added_by to NULL
    $stmt = $conn->prepare("UPDATE stock_history SET added_by = NULL WHERE added_by = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();

    // Update user_activity_logs to set user_id to NULL
    $stmt = $conn->prepare("UPDATE user_activity_logs SET user_id = NULL WHERE user_id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();

    // Update sales to set employee_id to NULL
    $stmt = $conn->prepare("UPDATE sales SET employee_id = NULL WHERE employee_id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();

    // Log the deletion
    logUserActivity($_SESSION['user_id'], 'delete_user', "Deleted user ID: $id");

    // Finally, delete the user
    $stmt = $conn->prepare("DELETE FROM users WHERE id = ? AND role != 'admin'");
    $stmt->bind_param("i", $id);
    
    if ($stmt->execute() && $stmt->affected_rows > 0) {
        $conn->commit();
        echo json_encode(['success' => true]);
    } else {
        throw new Exception('Failed to delete user');
    }
} catch (Exception $e) {
    $conn->rollback();
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
} 