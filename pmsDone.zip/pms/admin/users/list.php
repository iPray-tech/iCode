<?php

require_once '../../config/database.php';
require_once '../../includes/auth.php';
require_once '../../includes/header.php';

requireAdmin();

// Get all users except the current admin
$result = $conn->query("

    SELECT id, username, full_name, email, role, created_at 
    FROM users 
    WHERE id != {$_SESSION['user_id']}
    ORDER BY id DESC
");
?>

<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="card-title mb-0">Users Management</h5>
        <a href="add.php" class="btn btn-primary">Add New User</a>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Username</th>
                        <th>Full Name</th>
                        <th>Email</th>
                        <th>Role</th>
                        <th>Created At</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($user = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($user['username']); ?></td>
                        <td><?php echo htmlspecialchars($user['full_name']); ?></td>
                        <td><?php echo htmlspecialchars($user['email']); ?></td>
                        <td><?php echo ucfirst($user['role']); ?></td>
                        <td><?php echo formatDate($user['created_at']); ?></td>
                        <td>
                            <a href="view.php?id=<?php echo $user['id']; ?>" class="btn btn-sm btn-info">View</a>
                            <a href="edit.php?id=<?php echo $user['id']; ?>" class="btn btn-sm btn-primary">Edit</a>
                            <?php if ($user['role'] !== 'admin'): ?>
                            <button onclick="deleteUser(<?php echo $user['id']; ?>, '<?php echo htmlspecialchars($user['username']); ?>')" 
                                    class="btn btn-sm btn-danger">Delete</button>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
function deleteUser(userId, username) {
    if (confirm(`Are you sure you want to delete user "${username}"? This action cannot be undone.`)) {
        fetch('delete.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: `id=${userId}`
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                location.reload();
            } else {
                alert('Error deleting user: ' + data.error);
            }
        });
    }
}
</script>

<?php require_once '../../includes/footer.php'; ?>
