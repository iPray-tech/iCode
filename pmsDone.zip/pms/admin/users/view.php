<?php
require_once '../../config/database.php';
require_once '../../includes/auth.php';
require_once '../../includes/header.php';
requireAdmin();

if (!isset($_GET['id'])) {
    header("Location: list.php");
    exit();
}

$user_id = (int)$_GET['id'];

// Get user details
$stmt = $conn->prepare("
    SELECT u.*, 
           COUNT(DISTINCT s.id) as total_sales,
           COALESCE(SUM(s.total_amount), 0) as total_revenue
    FROM users u
    LEFT JOIN sales s ON u.id = s.employee_id
    WHERE u.id = ?
    GROUP BY u.id
");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

if (!$user) {
    header("Location: list.php");
    exit();
}

// Get recent activity
$stmt = $conn->prepare("
    SELECT action, details, created_at
    FROM user_activity_logs
    WHERE user_id = ?
    ORDER BY created_at DESC
    LIMIT 10
");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$activities = $stmt->get_result();
?>

<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="card-title mb-0">User Details</h5>
        <div>
            <a href="list.php" class="btn btn-secondary">Back to List</a>
            <a href="edit.php?id=<?php echo $user_id; ?>" class="btn btn-primary">Edit User</a>
        </div>
    </div>
    <div class="card-body">
        <div class="row">
            <div class="col-md-6">
                <h6>Basic Information</h6>
                <table class="table">
                    <tr>
                        <th>Username:</th>
                        <td><?php echo htmlspecialchars($user['username']); ?></td>
                    </tr>
                    <tr>
                        <th>Full Name:</th>
                        <td><?php echo htmlspecialchars($user['full_name']); ?></td>
                    </tr>
                    <tr>
                        <th>Email:</th>
                        <td><?php echo htmlspecialchars($user['email']); ?></td>
                    </tr>
                    <tr>
                        <th>Role:</th>
                        <td><?php echo ucfirst($user['role']); ?></td>
                    </tr>
                    <tr>
                        <th>Created At:</th>
                        <td><?php echo formatDate($user['created_at']); ?></td>
                    </tr>
                    <tr>
                        <th>Last Login:</th>
                        <td><?php echo $user['last_login'] ? formatDate($user['last_login'], 'Y-m-d H:i') : 'Never'; ?></td>
                    </tr>
                </table>
            </div>
            <div class="col-md-6">
                <h6>Performance Statistics</h6>
                <table class="table">
                    <tr>
                        <th>Total Sales:</th>
                        <td><?php echo $user['total_sales']; ?></td>
                    </tr>
                    <tr>
                        <th>Total Revenue:</th>
                        <td><?php echo formatMoney($user['total_revenue']); ?></td>
                    </tr>
                </table>
            </div>
        </div>

        <div class="mt-4">
            <h6>Recent Activity</h6>
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Action</th>
                        <th>Details</th>
                        <th>Date</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($activity = $activities->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($activity['action']); ?></td>
                        <td><?php echo htmlspecialchars($activity['details']); ?></td>
                        <td><?php echo formatDate($activity['created_at'], 'Y-m-d H:i'); ?></td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require_once '../../includes/footer.php'; ?> 