<?php
// Database Configuration
define('DB_HOST', 'localhost');
define('DB_USER', 'root');  // Change this for production
define('DB_PASS', '');      // Change this for production
define('DB_NAME', 'pms_dbms');

// Application Configuration
define('SITE_NAME', 'Pharmacy Management System');
define('COMPANY_NAME', 'iPray Pharmacy');
define('COMPANY_ADDRESS', 'Kasoa, Iron City');
define('COMPANY_PHONE', '+233(0)543-310-4304 | +233(0)202797700');
define('COMPANY_EMAIL', 'nicholas.ampong@regent.edu.gh');
define('DATE_FORMAT', 'Y-m-d');
define('DATETIME_FORMAT', 'Y-m-d H:i:s');

// Security Configuration
define('SESSION_TIMEOUT', 1800); // 30 minutes
define('HASH_COST', 10);         // Password hashing cost

// Error Reporting
error_reporting(E_ALL);
ini_set('display_errors', 0);     // Set to 0 in production
ini_set('log_errors', 1);
ini_set('error_log', '../logs/error.log');

// File Upload Settings
define('MAX_FILE_SIZE', 5 * 1024 * 1024); // 5MB
define('ALLOWED_FILE_TYPES', ['jpg', 'jpeg', 'png', 'pdf']);
define('UPLOAD_PATH', '../uploads/');

// Version
define('APP_VERSION', '1.0.0');

// File paths
define('ROOT_PATH', dirname(__DIR__));
define('INCLUDES_PATH', ROOT_PATH . '/includes');
define('UPLOADS_PATH', ROOT_PATH . '/uploads');

// Add these constants after the existing configuration
define('PASSWORD_MIN_LENGTH', 8);
define('PASSWORD_REQUIRES_SPECIAL', true);
define('PASSWORD_REQUIRES_NUMBER', true);
define('PASSWORD_REQUIRES_UPPERCASE', true);

// Add these constants for currency
define('CURRENCY_CODE', 'GHS');
define('CURRENCY_SYMBOL', 'GH₵');


// Session configuration
function initSession() {
    $session_options = [
        'cookie_httponly' => 1,
        'cookie_secure' => isset($_SERVER['HTTPS']),
        'use_only_cookies' => 1,
        'cookie_samesite' => 'Lax'
    ];
    
    session_start($session_options);
    
    // Regenerate session ID periodically to prevent session fixation
    if (!isset($_SESSION['last_regeneration'])) {
        session_regenerate_id(true);
        $_SESSION['last_regeneration'] = time();
    } else if (time() - $_SESSION['last_regeneration'] > 1800) { // 30 minutes
        session_regenerate_id(true);
        $_SESSION['last_regeneration'] = time();
    }
}

// Initialize session if it hasn't been started
if (session_status() === PHP_SESSION_NONE) {
    initSession();
}

// Timezone
date_default_timezone_set('Africa/Accra'); // Updated to Ghana timezone

// Helper functions
function getBasePath() {
    $current_path = $_SERVER['PHP_SELF'];
    $path_parts = explode('/', trim($current_path, '/'));
    $depth = count($path_parts) - 2;
    return str_repeat('../', $depth);
}

function formatMoney($amount) {
    $amount = floatval($amount ?? 0); // Convert null to 0
    return CURRENCY_SYMBOL . ' ' . number_format($amount, 2);
}

function formatDate($date, $format = 'Y-m-d') {
    if (empty($date)) {
        return '';
    }
    return date($format, strtotime($date));
}

function sanitizeHTML($string) {
    return htmlspecialchars($string, ENT_QUOTES, 'UTF-8');
}

function redirectTo($path) {
    $base_path = getBasePath();
    header("Location: {$base_path}{$path}");
    exit();
}

function isActive($path) {
    return strpos($_SERVER['PHP_SELF'], $path) !== false ? 'active' : '';
}

// Add CSRF protection
function generateCSRFToken() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function verifyCSRFToken($token) {
    if (empty($_SESSION['csrf_token']) || empty($token)) {
        return false;
    }
    return hash_equals($_SESSION['csrf_token'], $token);
}

// Add these helper functions
function validatePassword($password) {
    $errors = [];
    
    if (strlen($password) < PASSWORD_MIN_LENGTH) {
        $errors[] = "Password must be at least " . PASSWORD_MIN_LENGTH . " characters long";
    }
    
    if (PASSWORD_REQUIRES_SPECIAL && !preg_match('/[!@#$%^&*(),.?":{}|<>]/', $password)) {
        $errors[] = "Password must contain at least one special character";
    }
    
    if (PASSWORD_REQUIRES_NUMBER && !preg_match('/[0-9]/', $password)) {
        $errors[] = "Password must contain at least one number";
    }
    
    if (PASSWORD_REQUIRES_UPPERCASE && !preg_match('/[A-Z]/', $password)) {
        $errors[] = "Password must contain at least one uppercase letter";
    }
    
    return $errors;
}

function logUserActivity($user_id, $action, $details = '') {
    global $conn;
    
    try {
        $stmt = $conn->prepare("
            INSERT INTO user_activity_logs (user_id, action, details, ip_address) 
            VALUES (?, ?, ?, ?)
        ");
        $ip = $_SERVER['REMOTE_ADDR'];
        $stmt->bind_param("isss", $user_id, $action, $details, $ip);
        return $stmt->execute();
    } catch (Exception $e) {
        // If table doesn't exist, create it
        if (strpos($e->getMessage(), "doesn't exist") !== false) {
            $conn->query("
                CREATE TABLE IF NOT EXISTS user_activity_logs (
                    id INT PRIMARY KEY AUTO_INCREMENT,
                    user_id INT,
                    action VARCHAR(100) NOT NULL,
                    details TEXT,
                    ip_address VARCHAR(45),
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
                )
            ");
            
            // Try the insert again
            $stmt = $conn->prepare("
                INSERT INTO user_activity_logs (user_id, action, details, ip_address) 
                VALUES (?, ?, ?, ?)
            ");
            $ip = $_SERVER['REMOTE_ADDR'];
            $stmt->bind_param("isss", $user_id, $action, $details, $ip);
            return $stmt->execute();
        }
        // If other error, just continue without logging
        return false;
    }
} 