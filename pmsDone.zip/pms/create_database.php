<?php
// ... existing code ...
require_once 'config/database.php';

// First, create the database if it doesn't exist
$conn->query("CREATE DATABASE IF NOT EXISTS pms_dbms");
$conn->query("USE pms_dbms");

// Create users table
$conn->query("CREATE TABLE IF NOT EXISTS users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    full_name VARCHAR(100),
    role ENUM('admin', 'employee') NOT NULL DEFAULT 'employee',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_login DATETIME NULL DEFAULT NULL
)");

// Create suppliers table first (since medicines references it)
$conn->query("CREATE TABLE IF NOT EXISTS suppliers (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    contact_person VARCHAR(100),
    phone VARCHAR(20),
    email VARCHAR(100),
    address TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
)");

// Create medicines table
$conn->query("CREATE TABLE IF NOT EXISTS medicines (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    generic_name VARCHAR(100),
    description TEXT,
    unit_price DECIMAL(10,2) NOT NULL,
    stock_quantity INT NOT NULL DEFAULT 0,
    expiry_date DATE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    category VARCHAR(50),
    supplier_id INT,
    reorder_level INT DEFAULT 10,
    manufacturer VARCHAR(100),
    dosage_form VARCHAR(50),
    strength VARCHAR(50),
    location VARCHAR(50),
    batch_number VARCHAR(50),
    UNIQUE KEY unique_medicine_name (name),
    FOREIGN KEY (supplier_id) REFERENCES suppliers(id) ON DELETE SET NULL
)");

// Create patients table
$conn->query("CREATE TABLE IF NOT EXISTS patients (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    age INT,
    gender ENUM('Male', 'Female', 'Other'),
    phone VARCHAR(20),
    email VARCHAR(100),
    address TEXT,
    emergency_contact VARCHAR(100),
    emergency_phone VARCHAR(20),
    blood_group VARCHAR(5),
    allergies TEXT,
    medical_conditions TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
)");

// Alter patients table to add new fields
$conn->query("ALTER TABLE patients
    ADD COLUMN gender ENUM('Male', 'Female', 'Other') AFTER age,
    ADD COLUMN emergency_contact VARCHAR(100) AFTER address,
    ADD COLUMN emergency_phone VARCHAR(20) AFTER emergency_contact,
    ADD COLUMN blood_group VARCHAR(5) AFTER emergency_phone,
    ADD COLUMN allergies TEXT AFTER blood_group,
    ADD COLUMN medical_conditions TEXT AFTER allergies,
    MODIFY COLUMN created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    MODIFY COLUMN updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
");

// Create prescriptions table
$conn->query("CREATE TABLE IF NOT EXISTS prescriptions (
    id INT PRIMARY KEY AUTO_INCREMENT,
    patient_id INT NOT NULL,
    doctor_name VARCHAR(100) NOT NULL,
    diagnosis TEXT,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE CASCADE
)");

// Create prescription_items table
$conn->query("CREATE TABLE IF NOT EXISTS prescription_items (
    id INT PRIMARY KEY AUTO_INCREMENT,
    prescription_id INT NOT NULL,
    medicine_id INT NOT NULL,
    dosage VARCHAR(100) NOT NULL,
    duration VARCHAR(100) NOT NULL,
    instructions TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (prescription_id) REFERENCES prescriptions(id) ON DELETE CASCADE,
    FOREIGN KEY (medicine_id) REFERENCES medicines(id) ON DELETE CASCADE
)");

// Create sales table
$conn->query("CREATE TABLE IF NOT EXISTS sales (
    id INT PRIMARY KEY AUTO_INCREMENT,
    employee_id INT,
    customer_name VARCHAR(100),
    total_amount DECIMAL(10,2) NOT NULL,
    sale_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status ENUM('completed', 'reversed', 'reversal') DEFAULT 'completed',
    patient_id INT DEFAULT NULL,
    prescription_id INT DEFAULT NULL,
    reference_sale_id INT DEFAULT NULL,
    notes TEXT,
    FOREIGN KEY (employee_id) REFERENCES users(id) ON DELETE SET NULL,
    FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE SET NULL,
    FOREIGN KEY (prescription_id) REFERENCES prescriptions(id) ON DELETE SET NULL,
    FOREIGN KEY (reference_sale_id) REFERENCES sales(id) ON DELETE SET NULL
)");

// Create sale_reversals table
$conn->query("CREATE TABLE IF NOT EXISTS sale_reversals (
    id INT PRIMARY KEY AUTO_INCREMENT,
    sale_id INT NOT NULL,
    requested_by INT,
    approved_by INT DEFAULT NULL,
    reason TEXT NOT NULL,
    notes TEXT,
    status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
    requested_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    processed_at TIMESTAMP NULL,
    FOREIGN KEY (sale_id) REFERENCES sales(id) ON DELETE CASCADE,
    FOREIGN KEY (requested_by) REFERENCES users(id) ON DELETE SET NULL,
    FOREIGN KEY (approved_by) REFERENCES users(id) ON DELETE SET NULL
)");

// Add notes column to sale_reversals if it doesn't exist
$conn->query("ALTER TABLE sale_reversals ADD COLUMN IF NOT EXISTS notes TEXT AFTER reason");

// Create sale_items table
$conn->query("CREATE TABLE IF NOT EXISTS sale_items (
    id INT PRIMARY KEY AUTO_INCREMENT,
    sale_id INT NOT NULL,
    medicine_id INT NOT NULL,
    quantity INT NOT NULL,
    unit_price DECIMAL(10,2) NOT NULL,
    total_price DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (sale_id) REFERENCES sales(id) ON DELETE CASCADE,
    FOREIGN KEY (medicine_id) REFERENCES medicines(id) ON DELETE CASCADE
)");

// Create stock_history table
$conn->query("DROP TABLE IF EXISTS stock_history");
$conn->query("CREATE TABLE IF NOT EXISTS stock_history (
    id INT PRIMARY KEY AUTO_INCREMENT,
    medicine_id INT NOT NULL,
    quantity_added INT NOT NULL,
    expiry_date DATE,
    added_by INT,
    supplier_id INT,
    unit_cost DECIMAL(10,2),
    batch_number VARCHAR(50),
    invoice_number VARCHAR(50),
    transaction_type ENUM('purchase', 'adjustment', 'return') DEFAULT 'purchase',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (medicine_id) REFERENCES medicines(id) ON DELETE CASCADE,
    FOREIGN KEY (added_by) REFERENCES users(id) ON DELETE SET NULL,
    FOREIGN KEY (supplier_id) REFERENCES suppliers(id) ON DELETE SET NULL
)");

// Create user_activity_logs table
$conn->query("CREATE TABLE IF NOT EXISTS user_activity_logs (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    action VARCHAR(100) NOT NULL,
    details TEXT,
    ip_address VARCHAR(45),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
)");

// Create settings table
$conn->query("CREATE TABLE IF NOT EXISTS settings (
    id INT PRIMARY KEY AUTO_INCREMENT,
    setting_key VARCHAR(50) UNIQUE NOT NULL,
    setting_value TEXT,
    description TEXT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
)");

// Insert default admin user

// Insert default settings
$conn->query("INSERT IGNORE INTO settings (setting_key, setting_value, description) VALUES
('company_name', 'iPray Pharmacy', 'Company name'),
('company_address', 'Kasoa, Iron City', 'Company address'),
('company_phone', '+233(0)543-310-4304 | +233(0)202797700', 'Company phone numbers'),
('company_email', 'nicholas.ampong@regent.edu.gh', 'Company email'),
('currency', 'GHS', 'Default currency'),
('currency_symbol', 'GH₵', 'Currency symbol'),
('low_stock_threshold', '10', 'Low stock alert threshold'),
('expiry_alert_days', '30', 'Days before expiry to show alert'),
('enable_batch_tracking', 'true', 'Enable batch number tracking'),
('enable_expiry_tracking', 'true', 'Enable expiry date tracking')
");

// Create account_closures table
$conn->query("CREATE TABLE IF NOT EXISTS account_closures (
    id INT PRIMARY KEY AUTO_INCREMENT,
    requested_by INT NOT NULL,
    date DATE NOT NULL,
    cash_amount DECIMAL(10,2) NOT NULL,
    total_sales DECIMAL(10,2) NOT NULL,
    status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
    notes TEXT,
    admin_notes TEXT,
    requested_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    approved_by INT,
    approved_at TIMESTAMP NULL,
    FOREIGN KEY (requested_by) REFERENCES users(id),
    FOREIGN KEY (approved_by) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// Update the sales table to remove payment_method column if it exists
$conn->query("ALTER TABLE sales DROP COLUMN IF EXISTS payment_method");

// Create prescriptions table
$conn->query("CREATE TABLE IF NOT EXISTS prescriptions (
    id INT PRIMARY KEY AUTO_INCREMENT,
    patient_id INT NOT NULL,
    doctor_name VARCHAR(100) NOT NULL,
    diagnosis TEXT,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE CASCADE
)");

// Create prescription_items table
$conn->query("CREATE TABLE IF NOT EXISTS prescription_items (
    id INT PRIMARY KEY AUTO_INCREMENT,
    prescription_id INT NOT NULL,
    medicine_id INT NOT NULL,
    dosage VARCHAR(100) NOT NULL,
    duration VARCHAR(100) NOT NULL,
    instructions TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (prescription_id) REFERENCES prescriptions(id) ON DELETE CASCADE,
    FOREIGN KEY (medicine_id) REFERENCES medicines(id) ON DELETE CASCADE
)");

// ... rest of existing code ...

echo "Database and tables created successfully!";
?>
