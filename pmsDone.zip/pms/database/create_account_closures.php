<?php
require_once '../config/database.php';

// Drop the existing table if it exists
$conn->query("DROP TABLE IF EXISTS account_closures");

// Create the account_closures table with the correct structure
$conn->query("
    CREATE TABLE account_closures (
        id INT PRIMARY KEY AUTO_INCREMENT,
        requested_by INT NOT NULL,
        date DATE NOT NULL,
        cash_amount DECIMAL(10,2) NOT NULL,
        total_sales DECIMAL(10,2) NOT NULL,
        status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
        notes TEXT,
        admin_notes TEXT,
        requested_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        approved_by INT,
        processed_at TIMESTAMP NULL,
        FOREIGN KEY (requested_by) REFERENCES users(id),
        FOREIGN KEY (approved_by) REFERENCES users(id),
        INDEX idx_date_user (date, requested_by)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
");

echo "Account closures table created successfully!";
?> 