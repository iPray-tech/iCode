<?php
require_once '../vendor/autoload.php'; // For TCPDF or other PDF library
require_once '../config/config.php';

// Create new PDF document
$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

// Set document information
$pdf->SetCreator('PMS Documentation Generator');
$pdf->SetAuthor('iPray Pharmacy');
$pdf->SetTitle('Pharmacy Management System Documentation');

// Set default header data
$pdf->SetHeaderData(PDF_HEADER_LOGO, PDF_HEADER_LOGO_WIDTH, 'PMS Documentation', 'iPray Pharmacy');

// Set header and footer fonts
$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));

// Set default monospaced font
$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);

// Set margins
$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);

// Set auto page breaks
$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);

// Add a page
$pdf->AddPage();

// Set font
$pdf->SetFont('helvetica', '', 11);

// Title
$pdf->SetFont('helvetica', 'B', 20);
$pdf->Cell(0, 10, 'Pharmacy Management System Documentation', 0, 1, 'C');
$pdf->Ln(10);

// Table of Contents
$pdf->SetFont('helvetica', 'B', 16);
$pdf->Cell(0, 10, 'Table of Contents', 0, 1, 'L');
$pdf->SetFont('helvetica', '', 11);
$pdf->Ln(5);

$toc = array(
    '1. System Overview',
    '2. Installation Guide',
    '3. Database Structure',
    '4. User Management',
    '5. Sales Processing',
    '6. Inventory Management',
    '7. Account Closures',
    '8. Reporting System',
    '9. Configuration Guide',
    '10. Security Features',
    '11. Troubleshooting',
    '12. API Documentation'
);

foreach ($toc as $item) {
    $pdf->Cell(0, 8, $item, 0, 1, 'L');
}

$pdf->AddPage();

// 1. System Overview
$pdf->SetFont('helvetica', 'B', 16);
$pdf->Cell(0, 10, '1. System Overview', 0, 1, 'L');
$pdf->SetFont('helvetica', '', 11);
$pdf->writeHTML(getSystemOverview(), true, false, true, false, '');

$pdf->AddPage();

// 2. Installation Guide
$pdf->SetFont('helvetica', 'B', 16);
$pdf->Cell(0, 10, '2. Installation Guide', 0, 1, 'L');
$pdf->SetFont('helvetica', '', 11);
$pdf->writeHTML(getInstallationGuide(), true, false, true, false, '');

// Continue with other sections...

$pdf->Output('documentation.pdf', 'F');

// Helper functions to get content
function getSystemOverview() {
    return '<h2>Overview</h2>
    <p>The Pharmacy Management System (PMS) is a comprehensive solution for managing pharmacy operations, including:</p>
    <ul>
        <li>Sales and inventory management</li>
        <li>Employee tracking and account closures</li>
        <li>Financial reporting and analysis</li>
        <li>Customer relationship management</li>
    </ul>
    <h3>Key Features</h3>
    <ul>
        <li>User role management (Admin/Employee)</li>
        <li>Real-time inventory tracking</li>
        <li>Sales processing and history</li>
        <li>Cash management and reconciliation</li>
        <li>Comprehensive reporting system</li>
    </ul>';
}

function getInstallationGuide() {
    return '<h2>Installation Requirements</h2>
    <ul>
        <li>PHP 7.4 or higher</li>
        <li>MySQL 5.7 or higher</li>
        <li>Web server (Apache/Nginx)</li>
        <li>Modern web browser</li>
    </ul>
    <h3>Installation Steps</h3>
    <ol>
        <li>Clone the repository</li>
        <li>Create database \'pms_dbms\'</li>
        <li>Run create_database.php</li>
        <li>Configure config.php</li>
        <li>Set up web server</li>
    </ol>';
}

// Add more content functions for each section...
?> 