<?php
require_once '../../config/database.php';
require_once '../../includes/auth.php';
requireLogin();

header('Content-Type: application/json');

if (isset($_GET['id'])) {
    $closure_id = (int)$_GET['id'];
    
    try {
        // Get closure details
        $stmt = $conn->prepare("
            SELECT ac.*,
                   u1.username as requested_by_name,
                   u2.username as approved_by_name
            FROM account_closures ac
            JOIN users u1 ON ac.requested_by = u1.id
            LEFT JOIN users u2 ON ac.approved_by = u2.id
            WHERE ac.id = ? AND ac.requested_by = ?
        ");
        $stmt->bind_param("ii", $closure_id, $_SESSION['user_id']);
        $stmt->execute();
        $closure = $stmt->get_result()->fetch_assoc();

        if (!$closure) {
            throw new Exception('Account closure not found');
        }

        // Get sales details for the closure date
        $stmt = $conn->prepare("
            SELECT 
                COUNT(*) as total_transactions,
                COALESCE(SUM(CASE WHEN status = 'completed' THEN total_amount ELSE 0 END), 0) as total_sales,
                COALESCE(SUM(CASE WHEN payment_method = 'cash' AND status = 'completed' THEN total_amount ELSE 0 END), 0) as cash_sales,
                COALESCE(SUM(CASE WHEN payment_method = 'card' AND status = 'completed' THEN total_amount ELSE 0 END), 0) as card_sales,
                COUNT(CASE WHEN status = 'reversed' THEN 1 END) as reversed_sales
            FROM sales 
            WHERE DATE(sale_date) = ? AND employee_id = ?
        ");
        $stmt->bind_param("si", $closure['date'], $_SESSION['user_id']);
        $stmt->execute();
        $sales_summary = $stmt->get_result()->fetch_assoc();

        // Build HTML response
        $html = "
            <div class='container-fluid'>
                <div class='row mb-3'>
                    <div class='col-md-6'>
                        <strong>Date:</strong> " . formatDate($closure['date']) . "<br>
                        <strong>Status:</strong> " . ucfirst($closure['status']) . "<br>
                        <strong>Requested By:</strong> " . htmlspecialchars($closure['requested_by_name']) . "<br>
                        <strong>Requested At:</strong> " . formatDate($closure['requested_at'], 'Y-m-d H:i:s') . "
                    </div>
                    <div class='col-md-6'>
                        <strong>Total Transactions:</strong> " . $sales_summary['total_transactions'] . "<br>
                        <strong>Total Sales:</strong> " . formatMoney($sales_summary['total_sales']) . "<br>
                        <strong>Cash Sales:</strong> " . formatMoney($sales_summary['cash_sales']) . "<br>
                        <strong>Card Sales:</strong> " . formatMoney($sales_summary['card_sales']) . "<br>
                        <strong>Reversed Sales:</strong> " . $sales_summary['reversed_sales'] . "
                    </div>
                </div>

                <div class='row mb-3'>
                    <div class='col-12'>
                        <strong>Cash Count:</strong> " . formatMoney($closure['cash_amount']) . "<br>
                        <strong>System Total:</strong> " . formatMoney($sales_summary['cash_sales']) . "<br>
                        <strong>Difference:</strong> " . formatMoney($closure['cash_amount'] - $sales_summary['cash_sales']) . "
                    </div>
                </div>

                " . ($closure['notes'] ? "<div class='mb-3'><strong>Notes:</strong><br>" . nl2br(htmlspecialchars($closure['notes'])) . "</div>" : "") . "
                " . ($closure['admin_notes'] ? "<div class='mb-3'><strong>Admin Notes:</strong><br>" . nl2br(htmlspecialchars($closure['admin_notes'])) . "</div>" : "") . "
            </div>";

        echo json_encode(['success' => true, 'html' => $html]);

    } catch (Exception $e) {
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
} else {
    echo json_encode(['success' => false, 'error' => 'No closure ID provided']);
} 