<?php
require_once '../../config/database.php';
require_once '../../includes/auth.php';
require_once '../../includes/header.php';
requireLogin();

// Get account closures for this employee
$stmt = $conn->prepare("
    SELECT ac.*,
           u1.username as requested_by_name,
           u2.username as approved_by_name,
           COALESCE(SUM(CASE WHEN s.status = 'completed' THEN s.total_amount ELSE 0 END), 0) as system_total,
           COALESCE(SUM(CASE WHEN s.payment_method = 'cash' AND s.status = 'completed' THEN s.total_amount ELSE 0 END), 0) as cash_sales
    FROM account_closures ac
    JOIN users u1 ON ac.requested_by = u1.id
    LEFT JOIN users u2 ON ac.approved_by = u2.id
    LEFT JOIN sales s ON DATE(s.sale_date) = ac.date AND s.employee_id = ?
    WHERE ac.requested_by = ?
    GROUP BY ac.id
    ORDER BY ac.date DESC
");

$stmt->bind_param("ii", $_SESSION['user_id'], $_SESSION['user_id']);
$stmt->execute();
$closures = $stmt->get_result();
?>

<div class="card">
    <div class="card-header">
        <h5 class="card-title mb-0">My Account Closures</h5>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>System Total</th>
                        <th>Cash Amount</th>
                        <th>Difference</th>
                        <th>Status</th>
                        <th>Admin Notes</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($closure = $closures->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo formatDate($closure['date']); ?></td>
                            <td><?php echo formatMoney($closure['system_total']); ?></td>
                            <td><?php echo formatMoney($closure['cash_amount']); ?></td>
                            <td>
                                <?php 
                                $difference = $closure['cash_amount'] - $closure['system_total'];
                                $class = $difference < 0 ? 'text-danger' : 'text-success';
                                echo "<span class='$class'>" . formatMoney($difference) . "</span>";
                                ?>
                            </td>
                            <td>
                                <?php
                                $status_class = match($closure['status']) {
                                    'approved' => 'bg-success',
                                    'rejected' => 'bg-danger',
                                    default => 'bg-warning'
                                };
                                ?>
                                <span class="badge <?php echo $status_class; ?>">
                                    <?php echo ucfirst($closure['status']); ?>
                                </span>
                            </td>
                            <td><?php echo htmlspecialchars($closure['admin_notes'] ?? ''); ?></td>
                            <td>
                                <button type="button" class="btn btn-sm btn-info" 
                                        onclick="viewDetails(<?php echo $closure['id']; ?>)">
                                    View Details
                                </button>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Details Modal -->
<div class="modal fade" id="detailsModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Account Closure Details</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" id="closureDetails">
                Loading...
            </div>
        </div>
    </div>
</div>

<script>
function viewDetails(closureId) {
    const modal = new bootstrap.Modal(document.getElementById('detailsModal'));
    const detailsDiv = document.getElementById('closureDetails');
    
    detailsDiv.innerHTML = 'Loading...';
    modal.show();
    
    fetch(`get_closure_details.php?id=${closureId}`)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                detailsDiv.innerHTML = data.html;
            } else {
                detailsDiv.innerHTML = `Error: ${data.error}`;
            }
        })
        .catch(error => {
            detailsDiv.innerHTML = `Error: ${error.message}`;
        });
}
</script>

<?php require_once '../../includes/footer.php'; ?> 