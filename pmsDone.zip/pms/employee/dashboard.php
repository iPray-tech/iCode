<?php
require_once '../config/database.php';
require_once '../includes/auth.php';
require_once '../includes/header.php';
requireEmployee();

// Prevent admin access to employee dashboard
if (isAdmin()) {
    redirectToUserDashboard();
}

// Get user details
$stmt = $conn->prepare("
    SELECT u.*, 
           COUNT(DISTINCT CASE WHEN s.status = 'completed' THEN s.id END) as today_sales,
           COALESCE(SUM(CASE WHEN s.status = 'completed' THEN s.total_amount ELSE 0 END), 0) as today_revenue,
           COUNT(DISTINCT CASE WHEN s.status = 'reversed' THEN s.id END) as today_reversals
    FROM users u
    LEFT JOIN sales s ON u.id = s.employee_id AND DATE(s.sale_date) = CURDATE()
    WHERE u.id = ?
    GROUP BY u.id
");
$stmt->bind_param("i", $_SESSION['user_id']);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

// Get today's sales summary
$stmt = $conn->prepare("
    SELECT 
        COUNT(DISTINCT s.id) as total_sales,
        COALESCE(SUM(s.total_amount), 0) as total_revenue,
        COUNT(DISTINCT CASE WHEN s.status = 'reversed' THEN s.id END) as reversed_sales,
        COALESCE(SUM(CASE WHEN s.status = 'reversed' THEN s.total_amount ELSE 0 END), 0) as reversed_amount,
        COALESCE(SUM(CASE 
            WHEN s.status = 'completed' THEN s.total_amount 
            WHEN s.status = 'reversed' THEN -s.total_amount 
            ELSE 0 
        END), 0) as net_revenue,
        COUNT(DISTINCT CASE WHEN payment_method = 'cash' THEN s.id END) as cash_sales,
        COALESCE(SUM(CASE WHEN payment_method = 'cash' THEN s.total_amount ELSE 0 END), 0) as cash_amount
    FROM sales s
    WHERE s.employee_id = ? AND DATE(s.sale_date) = CURDATE()
");
$stmt->bind_param("i", $_SESSION['user_id']);
$stmt->execute();
$today_stats = $stmt->get_result()->fetch_assoc();

// Get recent sales
$stmt = $conn->prepare("
    SELECT s.*, 
           COUNT(si.id) as total_items,
           GROUP_CONCAT(CONCAT(m.name, ' (', si.quantity, ')') SEPARATOR ', ') as items_list
    FROM sales s
    LEFT JOIN sale_items si ON s.id = si.sale_id
    LEFT JOIN medicines m ON si.medicine_id = m.id
    WHERE s.employee_id = ? AND DATE(s.sale_date) = CURDATE()
    GROUP BY s.id
    ORDER BY s.sale_date DESC
    LIMIT 5
");
$stmt->bind_param("i", $_SESSION['user_id']);
$stmt->execute();
$recent_sales = $stmt->get_result();

// Get monthly sales excluding reversed sales
$stmt = $conn->prepare("
    SELECT 
        COUNT(DISTINCT CASE WHEN status = 'completed' THEN id END) as total_sales,
        SUM(CASE WHEN status = 'completed' THEN total_amount ELSE 0 END) as total_revenue
    FROM sales 
    WHERE employee_id = ? 
    AND MONTH(sale_date) = MONTH(CURRENT_DATE())
    AND YEAR(sale_date) = YEAR(CURRENT_DATE())
");
$stmt->bind_param("i", $_SESSION['user_id']);
$stmt->execute();
$monthly_sales = $stmt->get_result()->fetch_assoc();

// Get low stock alerts
$low_stock_items = $conn->query("
    SELECT id, name, stock_quantity
    FROM medicines
    WHERE stock_quantity < 10
    ORDER BY stock_quantity ASC
    LIMIT 5
");

// Get expiring medicines
$expiring_medicines = $conn->query("
    SELECT id, name, expiry_date,
           DATEDIFF(expiry_date, CURDATE()) as days_until_expiry
    FROM medicines
    WHERE expiry_date IS NOT NULL
    AND expiry_date <= DATE_ADD(CURDATE(), INTERVAL 30 DAY)
    ORDER BY expiry_date ASC
    LIMIT 5
");
?>

<!-- User Profile Card -->
<div class="row mb-4">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <div class="d-flex align-items-center">
                    <div class="flex-shrink-0">
                        <i class="bi bi-person-circle text-primary" style="font-size: 3rem;"></i>
                    </div>
                    <div class="flex-grow-1 ms-3">
                        <h4 class="mb-1"><?php echo htmlspecialchars($user['full_name']); ?></h4>
                        <p class="text-muted mb-0">
                            Username: <?php echo htmlspecialchars($user['username']); ?><br>
                            Email: <?php echo htmlspecialchars($user['email']); ?>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Statistics Cards -->
<div class="row mb-4">
    <!-- Today's Sales -->
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-primary shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Today's Sales</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $today_stats['total_sales']; ?></div>
                    </div>
                    <div class="col-auto">
                        <i class="bi bi-cart text-gray-300 fs-2"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Net Revenue -->
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-success shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-success text-uppercase mb-1">Net Revenue</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800">
                            <?php echo formatMoney($today_stats['net_revenue']); ?>
                        </div>
                    </div>
                    <div class="col-auto">
                        <i class="bi bi-currency-dollar text-gray-300 fs-2"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Cash Sales -->
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-info shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Cash Sales</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800">
                            <?php echo formatMoney($today_stats['cash_amount']); ?>
                        </div>
                    </div>
                    <div class="col-auto">
                        <i class="bi bi-cash text-gray-300 fs-2"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Reversals -->
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-warning shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">Reversals</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $today_stats['reversed_sales']; ?></div>
                    </div>
                    <div class="col-auto">
                        <i class="bi bi-arrow-return-left text-gray-300 fs-2"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Quick Actions -->
<div class="row mb-4">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title mb-3">Quick Actions</h5>
                <div class="row">
                    <div class="col-md-3 mb-2">
                        <a href="sales/new_sale.php" class="btn btn-primary w-100">
                            <i class="bi bi-cart-plus"></i> New Sale
                        </a>
                    </div>
                    <div class="col-md-3 mb-2">
                        <a href="sales/daily_summary.php" class="btn btn-success w-100">
                            <i class="bi bi-calendar-check"></i> Daily Summary
                        </a>
                    </div>
                    <div class="col-md-3 mb-2">
                        <a href="prescriptions/list.php" class="btn btn-info w-100">
                            <i class="bi bi-file-medical"></i> Prescriptions
                        </a>
                    </div>
                    <div class="col-md-3 mb-2">
                        <a href="patients/list.php" class="btn btn-secondary w-100">
                            <i class="bi bi-people"></i> Patients
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Recent Sales -->
<div class="card mb-4">
    <div class="card-header">
        <h5 class="card-title mb-0">Recent Sales Today</h5>
    </div>
    <div class="card-body">
        <?php if ($recent_sales->num_rows > 0): ?>
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Time</th>
                            <th>Items</th>
                            <th>Amount</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($sale = $recent_sales->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo formatDate($sale['sale_date'], 'h:i A'); ?></td>
                            <td>
                                <small><?php echo htmlspecialchars($sale['items_list']); ?></small>
                            </td>
                            <td><?php echo formatMoney($sale['total_amount']); ?></td>
                            <td>
                                <span class="badge bg-<?php echo $sale['status'] === 'completed' ? 'success' : 'danger'; ?>">
                                    <?php echo ucfirst($sale['status']); ?>
                                </span>
                            </td>
                            <td>
                                <a href="sales/view_sale.php?id=<?php echo $sale['id']; ?>" class="btn btn-sm btn-info">View</a>
                                <button onclick="printReceipt(<?php echo $sale['id']; ?>)" class="btn btn-sm btn-secondary">Print</button>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <p class="text-center mb-0">No sales recorded today</p>
        <?php endif; ?>
    </div>
</div>

<style>
.border-left-primary { border-left: 4px solid #4e73df; }
.border-left-success { border-left: 4px solid #1cc88a; }
.border-left-info { border-left: 4px solid #36b9cc; }
.border-left-warning { border-left: 4px solid #f6c23e; }
.text-gray-300 { color: #dddfeb; }
.text-gray-800 { color: #5a5c69; }
</style>

<script>
function printReceipt(saleId) {
    window.open('sales/print_receipt.php?id=' + saleId, '_blank');
}
</script>

<?php require_once '../includes/footer.php'; ?>
