<?php
require_once '../../config/database.php';
require_once '../../includes/auth.php';
require_once '../../includes/header.php';
requireLogin();

$success = $error = '';
$patient = null;

if (isset($_GET['id'])) {
    $id = (int)$_GET['id'];
    $stmt = $conn->prepare("SELECT * FROM patients WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $patient = $stmt->get_result()->fetch_assoc();
    
    if (!$patient) {
        header("Location: list.php");
        exit();
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'] ?? '';
    $age = $_POST['age'] ?? null;
    $gender = $_POST['gender'] ?? '';
    $phone = $_POST['phone'] ?? '';
    $email = $_POST['email'] ?? '';
    $address = $_POST['address'] ?? '';
    $emergency_contact = $_POST['emergency_contact'] ?? '';
    $emergency_phone = $_POST['emergency_phone'] ?? '';
    $blood_group = $_POST['blood_group'] ?? '';
    $allergies = $_POST['allergies'] ?? '';
    $medical_conditions = $_POST['medical_conditions'] ?? '';
    
    if (empty($name)) {
        $error = "Name is required";
    } else {
        $stmt = $conn->prepare("
            UPDATE patients 
            SET name = ?,
                age = ?,
                gender = ?,
                phone = ?,
                email = ?,
                address = ?,
                emergency_contact = ?,
                emergency_phone = ?,
                blood_group = ?,
                allergies = ?,
                medical_conditions = ?
            WHERE id = ?
        ");

        // Debug the values
        /*
        echo "Values being bound:<br>";
        echo "name: $name<br>";
        echo "age: $age<br>";
        echo "gender: $gender<br>";
        echo "phone: $phone<br>";
        echo "email: $email<br>";
        echo "address: $address<br>";
        echo "emergency_contact: $emergency_contact<br>";
        echo "emergency_phone: $emergency_phone<br>";
        echo "blood_group: $blood_group<br>";
        echo "allergies: $allergies<br>";
        echo "medical_conditions: $medical_conditions<br>";
        echo "id: $id<br>";
        */

        $stmt->bind_param(
            "sisssssssssi", 
            $name,
            $age,
            $gender,
            $phone,
            $email,
            $address,
            $emergency_contact,
            $emergency_phone,
            $blood_group,
            $allergies,
            $medical_conditions,
            $id
        );
        
        if ($stmt->execute()) {
            $success = "Patient updated successfully";
            // Refresh patient data
            $stmt = $conn->prepare("SELECT * FROM patients WHERE id = ?");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $patient = $stmt->get_result()->fetch_assoc();
        } else {
            $error = "Error updating patient: " . $conn->error;
        }
    }
}
?>

<div class="card">
    <div class="card-header">
        <h5 class="card-title mb-0">Edit Patient</h5>
    </div>
    <div class="card-body">
        <?php if ($success): ?>
            <div class="alert alert-success"><?php echo $success; ?></div>
        <?php endif; ?>
        
        <?php if ($error): ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php endif; ?>

        <form method="POST" action="">
            <div class="row">
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="name" class="form-label">Full Name</label>
                        <input type="text" class="form-control" id="name" name="name" required 
                               value="<?php echo htmlspecialchars($patient['name']); ?>">
                    </div>

                    <div class="mb-3">
                        <label for="age" class="form-label">Age</label>
                        <input type="number" class="form-control" id="age" name="age" min="0" max="150"
                               value="<?php echo htmlspecialchars($patient['age'] ?? ''); ?>">
                    </div>

                    <div class="mb-3">
                        <label for="gender" class="form-label">Gender</label>
                        <select class="form-control" id="gender" name="gender">
                            <option value="">Select Gender</option>
                            <option value="Male" <?php echo ($patient['gender'] ?? '') === 'Male' ? 'selected' : ''; ?>>Male</option>
                            <option value="Female" <?php echo ($patient['gender'] ?? '') === 'Female' ? 'selected' : ''; ?>>Female</option>
                            <option value="Other" <?php echo ($patient['gender'] ?? '') === 'Other' ? 'selected' : ''; ?>>Other</option>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label for="phone" class="form-label">Phone Number</label>
                        <input type="tel" class="form-control" id="phone" name="phone"
                               value="<?php echo htmlspecialchars($patient['phone'] ?? ''); ?>">
                    </div>

                    <div class="mb-3">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" class="form-control" id="email" name="email"
                               value="<?php echo htmlspecialchars($patient['email'] ?? ''); ?>">
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="address" class="form-label">Address</label>
                        <textarea class="form-control" id="address" name="address" rows="2"><?php echo htmlspecialchars($patient['address'] ?? ''); ?></textarea>
                    </div>

                    <div class="mb-3">
                        <label for="emergency_contact" class="form-label">Emergency Contact Name</label>
                        <input type="text" class="form-control" id="emergency_contact" name="emergency_contact"
                               value="<?php echo htmlspecialchars($patient['emergency_contact'] ?? ''); ?>">
                    </div>

                    <div class="mb-3">
                        <label for="emergency_phone" class="form-label">Emergency Contact Phone</label>
                        <input type="tel" class="form-control" id="emergency_phone" name="emergency_phone"
                               value="<?php echo htmlspecialchars($patient['emergency_phone'] ?? ''); ?>">
                    </div>

                    <div class="mb-3">
                        <label for="blood_group" class="form-label">Blood Group</label>
                        <select class="form-control" id="blood_group" name="blood_group">
                            <option value="">Select Blood Group</option>
                            <?php
                            $blood_groups = ['A+', 'A-', 'B+', 'B-', 'O+', 'O-', 'AB+', 'AB-'];
                            foreach ($blood_groups as $bg) {
                                $selected = ($patient['blood_group'] ?? '') === $bg ? 'selected' : '';
                                echo "<option value=\"$bg\" $selected>$bg</option>";
                            }
                            ?>
                        </select>
                    </div>
                </div>

                <div class="col-12">
                    <div class="mb-3">
                        <label for="allergies" class="form-label">Allergies</label>
                        <textarea class="form-control" id="allergies" name="allergies" rows="2"><?php echo htmlspecialchars($patient['allergies'] ?? ''); ?></textarea>
                    </div>

                    <div class="mb-3">
                        <label for="medical_conditions" class="form-label">Medical Conditions</label>
                        <textarea class="form-control" id="medical_conditions" name="medical_conditions" rows="2"><?php echo htmlspecialchars($patient['medical_conditions'] ?? ''); ?></textarea>
                    </div>
                </div>
            </div>

            <div class="mt-3">
                <button type="submit" class="btn btn-primary">Update Patient</button>
                <a href="view.php?id=<?php echo $id; ?>" class="btn btn-secondary">Cancel</a>
            </div>
        </form>
    </div>
</div>

<?php require_once '../../includes/footer.php'; ?>

