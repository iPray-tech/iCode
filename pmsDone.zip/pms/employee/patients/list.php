<?php
require_once '../../config/database.php';
require_once '../../includes/auth.php';
require_once '../../includes/header.php';
requireLogin();

// Get all patients with their last visit date
$query = "SELECT p.*, 
          COUNT(s.id) as total_visits,
          MAX(s.sale_date) as last_visit
          FROM patients p
          LEFT JOIN sales s ON p.id = s.patient_id
          GROUP BY p.id
          ORDER BY p.name ASC";
$result = $conn->query($query);
?>

<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="card-title mb-0">Patient Management</h5>
        <a href="add.php" class="btn btn-primary">Add New Patient</a>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-striped" id="patientsTable">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Phone</th>
                        <th>Email</th>
                        <th>Age</th>
                        <th>Total Visits</th>
                        <th>Last Visit</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($patient = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo $patient['id']; ?></td>
                        <td><?php echo htmlspecialchars($patient['name']); ?></td>
                        <td><?php echo htmlspecialchars($patient['phone']); ?></td>
                        <td><?php echo htmlspecialchars($patient['email']); ?></td>
                        <td><?php echo $patient['age']; ?></td>
                        <td><?php echo $patient['total_visits']; ?></td>
                        <td>
                            <?php 
                            echo $patient['last_visit'] 
                                ? date('Y-m-d', strtotime($patient['last_visit']))
                                : 'Never';
                            ?>
                        </td>
                        <td>
                            <a href="edit.php?id=<?php echo $patient['id']; ?>" class="btn btn-sm btn-warning">Edit</a>
                            <a href="view.php?id=<?php echo $patient['id']; ?>" class="btn btn-sm btn-info">View History</a>
                            <button class="btn btn-sm btn-danger" onclick="deletePatient(<?php echo $patient['id']; ?>)">Delete</button>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
function deletePatient(patientId) {
    if (confirm('Are you sure you want to delete this patient? This action cannot be undone.')) {
        fetch('delete.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: 'id=' + patientId
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                location.reload();
            } else {
                alert('Error deleting patient: ' + data.error);
            }
        });
    }
}
</script>

<?php require_once '../../includes/footer.php'; ?>
