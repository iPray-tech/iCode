<?php
require_once '../../config/database.php';
require_once '../../includes/auth.php';
requireLogin();

header('Content-Type: application/json');

$search = $_GET['q'] ?? '';

if (empty($search)) {
    echo json_encode(['success' => false, 'error' => 'Search term is required']);
    exit;
}

$search = "%$search%";
$stmt = $conn->prepare("
    SELECT id, name, phone, email 
    FROM patients 
    WHERE name LIKE ? OR phone LIKE ? OR email LIKE ?
    ORDER BY name ASC 
    LIMIT 10
");
$stmt->bind_param("sss", $search, $search, $search);
$stmt->execute();
$result = $stmt->get_result();

$patients = [];
while ($row = $result->fetch_assoc()) {
    $patients[] = $row;
}

echo json_encode(['success' => true, 'patients' => $patients]);
?> 