<?php
require_once '../../config/database.php';
require_once '../../includes/auth.php';
require_once '../../includes/header.php';
requireLogin();

if (!isset($_GET['id'])) {
    header("Location: list.php");
    exit();
}

$id = (int)$_GET['id'];

// Get patient details
$stmt = $conn->prepare("SELECT * FROM patients WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$patient = $stmt->get_result()->fetch_assoc();

if (!$patient) {
    header("Location: list.php");
    exit();
}

// Get patient's purchase history with more details
$stmt = $conn->prepare("
    SELECT s.*, 
           u.username as employee_name,
           COUNT(DISTINCT si.id) as total_items,
           GROUP_CONCAT(DISTINCT CONCAT(m.name, ' (', si.quantity, ')') SEPARATOR ', ') as medicines_list
    FROM sales s
    LEFT JOIN users u ON s.employee_id = u.id
    LEFT JOIN sale_items si ON s.id = si.sale_id
    LEFT JOIN medicines m ON si.medicine_id = m.id
    WHERE s.patient_id = ?
    GROUP BY s.id
    ORDER BY s.sale_date DESC
");
$stmt->bind_param("i", $id);
$stmt->execute();
$sales = $stmt->get_result();

// Calculate detailed statistics
$stats_query = "
    SELECT 
        COUNT(DISTINCT s.id) as total_visits,
        COALESCE(SUM(s.total_amount), 0) as total_spent,
        COUNT(DISTINCT si.medicine_id) as unique_medicines,
        MAX(s.sale_date) as last_visit
    FROM patients p
    LEFT JOIN sales s ON p.id = s.patient_id
    LEFT JOIN sale_items si ON s.id = si.sale_id
    WHERE p.id = ?
    GROUP BY p.id
";

$stmt = $conn->prepare($stats_query);
$stmt->bind_param("i", $id);
$stmt->execute();
$stats = $stmt->get_result()->fetch_assoc();
?>

<div class="row">
    <div class="col-md-4">
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="card-title mb-0">Patient Information</h5>
            </div>
            <div class="card-body">
                <table class="table">
                    <tr>
                        <th>Name:</th>
                        <td><?php echo htmlspecialchars($patient['name']); ?></td>
                    </tr>
                    <tr>
                        <th>Phone:</th>
                        <td><?php echo htmlspecialchars($patient['phone']); ?></td>
                    </tr>
                    <tr>
                        <th>Email:</th>
                        <td><?php echo htmlspecialchars($patient['email'] ?? 'N/A'); ?></td>
                    </tr>
                    <tr>
                        <th>Age:</th>
                        <td><?php echo $patient['age'] ?? 'N/A'; ?></td>
                    </tr>
                    <?php if (!empty($patient['address'])): ?>
                    <tr>
                        <th>Address:</th>
                        <td><?php echo nl2br(htmlspecialchars($patient['address'])); ?></td>
                    </tr>
                    <?php endif; ?>
                </table>

                <div class="mt-3">
                    <h6>Visit Statistics</h6>
                    <table class="table table-sm">
                        <tr>
                            <th>Total Visits:</th>
                            <td><?php echo $stats['total_visits']; ?></td>
                        </tr>
                        <tr>
                            <th>Total Spent:</th>
                            <td><?php echo formatMoney($stats['total_spent']); ?></td>
                        </tr>
                        <tr>
                            <th>Unique Medicines:</th>
                            <td><?php echo $stats['unique_medicines']; ?></td>
                        </tr>
                        <tr>
                            <th>Last Visit:</th>
                            <td>
                                <?php 
                                echo $stats['last_visit'] 
                                    ? formatDate($stats['last_visit'], 'Y-m-d') 
                                    : 'Never';
                                ?>
                            </td>
                        </tr>
                    </table>
                </div>

                <?php if (!empty($patient['medical_history']) || !empty($patient['allergies'])): ?>
                <div class="mt-3">
                    <?php if (!empty($patient['medical_history'])): ?>
                    <h6>Medical History</h6>
                    <p class="text-muted"><?php echo nl2br(htmlspecialchars($patient['medical_history'])); ?></p>
                    <?php endif; ?>

                    <?php if (!empty($patient['allergies'])): ?>
                    <h6>Allergies</h6>
                    <p class="text-muted"><?php echo nl2br(htmlspecialchars($patient['allergies'])); ?></p>
                    <?php endif; ?>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <div class="col-md-8">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-0">Purchase History</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Items</th>
                                <th>Amount</th>
                                <th>Served By</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($sale = $sales->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo formatDate($sale['sale_date'], 'Y-m-d H:i'); ?></td>
                                <td>
                                    <span class="text-muted" title="<?php echo htmlspecialchars($sale['medicines_list']); ?>">
                                        <?php echo $sale['total_items']; ?> items
                                    </span>
                                </td>
                                <td><?php echo formatMoney($sale['total_amount']); ?></td>
                                <td><?php echo htmlspecialchars($sale['employee_name']); ?></td>
                                <td>
                                    <button class="btn btn-sm btn-info" onclick="viewSaleDetails(<?php echo $sale['id']; ?>)">
                                        View Details
                                    </button>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Sale Details Modal -->
<div class="modal fade" id="saleDetailsModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Sale Details</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" id="saleDetailsContent">
                Loading...
            </div>
        </div>
    </div>
</div>

<script>
function viewSaleDetails(saleId) {
    const modal = new bootstrap.Modal(document.getElementById('saleDetailsModal'));
    const contentDiv = document.getElementById('saleDetailsContent');
    
    contentDiv.innerHTML = 'Loading...';
    modal.show();
    
    fetch(`../sales/get_sale_details.php?id=${saleId}`)
        .then(response => response.text())
        .then(html => {
            contentDiv.innerHTML = html;
        })
        .catch(error => {
            contentDiv.innerHTML = 'Error loading sale details: ' + error;
        });
}
</script>

<?php require_once '../../includes/footer.php'; ?> 