<?php
require_once '../../config/database.php';
require_once '../../includes/auth.php';
require_once '../../includes/header.php';
requireLogin();

$success = $error = '';
$patient_id = $_GET['patient_id'] ?? null;

// Get patient details if patient_id is provided
$patient = null;
if ($patient_id) {
    $stmt = $conn->prepare("SELECT * FROM patients WHERE id = ?");
    $stmt->bind_param("i", $patient_id);
    $stmt->execute();
    $patient = $stmt->get_result()->fetch_assoc();
}

// Get all medicines for dropdown
$medicines = $conn->query("SELECT id, name, generic_name FROM medicines ORDER BY name ASC");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $patient_id = $_POST['patient_id'];
    $doctor_name = $_POST['doctor_name'];
    $diagnosis = $_POST['diagnosis'];
    $notes = $_POST['notes'];
    $medicines_list = $_POST['medicines'] ?? [];
    $dosages = $_POST['dosages'] ?? [];
    $durations = $_POST['durations'] ?? [];
    $instructions = $_POST['instructions'] ?? [];
    
    if (empty($patient_id) || empty($doctor_name) || empty($medicines_list)) {
        $error = "Required fields are missing";
    } else {
        $conn->begin_transaction();
        
        try {
            // Create prescription
            $stmt = $conn->prepare("INSERT INTO prescriptions (patient_id, doctor_name, diagnosis, notes) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("isss", $patient_id, $doctor_name, $diagnosis, $notes);
            $stmt->execute();
            $prescription_id = $conn->insert_id;
            
            // Add prescription items
            $stmt = $conn->prepare("INSERT INTO prescription_items (prescription_id, medicine_id, dosage, duration, instructions) VALUES (?, ?, ?, ?, ?)");
            
            foreach ($medicines_list as $index => $medicine_id) {
                if (!empty($medicine_id)) {
                    $stmt->bind_param("iisss", 
                        $prescription_id, 
                        $medicine_id,
                        $dosages[$index],
                        $durations[$index],
                        $instructions[$index]
                    );
                    $stmt->execute();
                }
            }
            
            $conn->commit();
            $success = "Prescription added successfully";
            
            // Redirect to prescription view
            header("Location: view.php?id=" . $prescription_id);
            exit();
        } catch (Exception $e) {
            $conn->rollback();
            $error = "Error adding prescription: " . $e->getMessage();
        }
    }
}
?>

<div class="card">
    <div class="card-header">
        <h5 class="card-title mb-0">New Prescription</h5>
    </div>
    <div class="card-body">
        <?php if ($success): ?>
            <div class="alert alert-success"><?php echo $success; ?></div>
        <?php endif; ?>
        
        <?php if ($error): ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php endif; ?>
        
        <form method="POST" action="">
            <div class="row">
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="patient_id" class="form-label">Patient</label>
                        <?php if ($patient): ?>
                            <input type="hidden" name="patient_id" value="<?php echo $patient['id']; ?>">
                            <input type="text" class="form-control" value="<?php echo htmlspecialchars($patient['name']); ?>" readonly>
                        <?php else: ?>
                            <select class="form-select" id="patient_id" name="patient_id" required>
                                <option value="">Select Patient</option>
                                <?php 
                                $patients = $conn->query("SELECT id, name, phone FROM patients ORDER BY name ASC");
                                while ($p = $patients->fetch_assoc()):
                                ?>
                                <option value="<?php echo $p['id']; ?>">
                                    <?php echo htmlspecialchars($p['name'] . ' (' . $p['phone'] . ')'); ?>
                                </option>
                                <?php endwhile; ?>
                            </select>
                        <?php endif; ?>
                    </div>
                    
                    <div class="mb-3">
                        <label for="doctor_name" class="form-label">Doctor Name</label>
                        <input type="text" class="form-control" id="doctor_name" name="doctor_name" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="diagnosis" class="form-label">Diagnosis</label>
                        <textarea class="form-control" id="diagnosis" name="diagnosis" rows="3"></textarea>
                    </div>
                </div>
                
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="notes" class="form-label">Notes</label>
                        <textarea class="form-control" id="notes" name="notes" rows="3"></textarea>
                    </div>
                </div>
            </div>
            
            <h6 class="mt-4">Prescribed Medicines</h6>
            <div id="medicinesList">
                <!-- Medicine items will be added here -->
            </div>
            
            <button type="button" class="btn btn-secondary mb-3" onclick="addMedicine()">Add Medicine</button>
            
            <div class="mt-4">
                <button type="submit" class="btn btn-primary">Save Prescription</button>
                <a href="<?php echo $patient ? '../patients/view.php?id=' . $patient['id'] : 'list.php'; ?>" 
                   class="btn btn-secondary">Cancel</a>
            </div>
        </form>
    </div>
</div>

<script>
let medicineCounter = 0;

function addMedicine() {
    const container = document.getElementById('medicinesList');
    const div = document.createElement('div');
    div.className = 'row mb-3 medicine-item';
    
    div.innerHTML = `
        <div class="col-md-3">
            <select class="form-select" name="medicines[]" required>
                <option value="">Select Medicine</option>
                <?php 
                $medicines->data_seek(0);
                while ($medicine = $medicines->fetch_assoc()): 
                ?>
                <option value="<?php echo $medicine['id']; ?>">
                    <?php echo htmlspecialchars($medicine['name']); ?>
                </option>
                <?php endwhile; ?>
            </select>
        </div>
        <div class="col-md-2">
            <input type="text" class="form-control" name="dosages[]" placeholder="Dosage" required>
        </div>
        <div class="col-md-2">
            <input type="text" class="form-control" name="durations[]" placeholder="Duration" required>
        </div>
        <div class="col-md-4">
            <input type="text" class="form-control" name="instructions[]" placeholder="Instructions" required>
        </div>
        <div class="col-md-1">
            <button type="button" class="btn btn-danger" onclick="removeMedicine(this)">×</button>
        </div>
    `;
    
    container.appendChild(div);
    medicineCounter++;
}

function removeMedicine(button) {
    button.closest('.medicine-item').remove();
}

// Add first medicine item by default
addMedicine();
</script>

<?php require_once '../../includes/footer.php'; ?> 