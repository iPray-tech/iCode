<?php
require_once '../../config/database.php';
require_once '../../includes/auth.php';
require_once '../../includes/header.php';
requireLogin();

// Get all prescriptions with patient information
$query = "SELECT p.*, 
          pt.name as patient_name,
          pt.phone as patient_phone,
          COUNT(pi.id) as total_medicines
          FROM prescriptions p
          JOIN patients pt ON p.patient_id = pt.id
          LEFT JOIN prescription_items pi ON p.id = pi.prescription_id
          GROUP BY p.id
          ORDER BY p.created_at DESC";
$result = $conn->query($query);
?>

<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="card-title mb-0">Prescriptions</h5>
        <a href="add.php" class="btn btn-primary">New Prescription</a>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Patient</th>
                        <th>Doctor</th>
                        <th>Medicines</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($prescription = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo date('Y-m-d', strtotime($prescription['created_at'])); ?></td>
                        <td>
                            <?php 
                            echo htmlspecialchars($prescription['patient_name']) . 
                                 ' (' . htmlspecialchars($prescription['patient_phone']) . ')';
                            ?>
                        </td>
                        <td><?php echo htmlspecialchars($prescription['doctor_name']); ?></td>
                        <td><?php echo $prescription['total_medicines']; ?></td>
                        <td>
                            <a href="view.php?id=<?php echo $prescription['id']; ?>" 
                               class="btn btn-sm btn-info">View</a>
                            <button class="btn btn-sm btn-success" 
                                    onclick="createSale(<?php echo $prescription['id']; ?>)">
                                Create Sale
                            </button>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
function createSale(prescriptionId) {
    window.location.href = '../sales/new_sale.php?prescription_id=' + prescriptionId;
}
</script>

<?php require_once '../../includes/footer.php'; ?> 