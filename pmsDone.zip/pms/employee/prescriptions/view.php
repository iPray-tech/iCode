<?php
require_once '../../config/database.php';
require_once '../../includes/auth.php';
require_once '../../includes/header.php';
requireLogin();

if (!isset($_GET['id'])) {
    header("Location: list.php");
    exit();
}

$id = (int)$_GET['id'];

// Get prescription details with patient information
$stmt = $conn->prepare("
    SELECT p.*, pt.name as patient_name, pt.phone, pt.age
    FROM prescriptions p
    JOIN patients pt ON p.patient_id = pt.id
    WHERE p.id = ?
");
$stmt->bind_param("i", $id);
$stmt->execute();
$prescription = $stmt->get_result()->fetch_assoc();

if (!$prescription) {
    header("Location: list.php");
    exit();
}

// Get prescription items with medicine details
$stmt = $conn->prepare("
    SELECT pi.*, m.name as medicine_name, m.generic_name
    FROM prescription_items pi
    JOIN medicines m ON pi.medicine_id = m.id
    WHERE pi.prescription_id = ?
");
$stmt->bind_param("i", $id);
$stmt->execute();
$items = $stmt->get_result();
?>

<div class="card mb-4">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="card-title mb-0">Prescription Details</h5>
        <div>
            <button onclick="printPrescription()" class="btn btn-primary">
                <i class="bi bi-printer"></i> Print
            </button>
            <a href="list.php" class="btn btn-secondary">Back to List</a>
        </div>
    </div>
    <div class="card-body">
        <div id="prescription-content">
            <!-- Pharmacy Header - Only visible when printing -->
            <div class="print-only text-center mb-4">
                <h2> <?php echo SITE_NAME; ?></h2>
                <p><?php echo COMPANY_NAME; ?></p>
                <p><?php echo COMPANY_PHONE; ?></p>
                <p><?php echo COMPANY_ADDRESS; ?></p>
                <p><?php echo COMPANY_EMAIL; ?></p>
                <hr>
            </div>

            <div class="row">
                <div class="col-md-6">
                    <p><strong>Patient Name:</strong> <?php echo htmlspecialchars($prescription['patient_name']); ?></p>
                    <p><strong>Phone:</strong> <?php echo htmlspecialchars($prescription['phone']); ?></p>
                    <p><strong>Age:</strong> <?php echo $prescription['age']; ?></p>
                </div>
                <div class="col-md-6 text-md-end">
                    <p><strong>Date:</strong> <?php echo date('Y-m-d', strtotime($prescription['created_at'])); ?></p>
                    <p><strong>Doctor:</strong> <?php echo htmlspecialchars($prescription['doctor_name']); ?></p>
                    <p><strong>Prescription #:</strong> <?php echo str_pad($prescription['id'], 6, '0', STR_PAD_LEFT); ?></p>
                </div>
            </div>

            <?php if ($prescription['diagnosis']): ?>
            <div class="row mt-3">
                <div class="col-12">
                    <p><strong>Diagnosis:</strong></p>
                    <p><?php echo nl2br(htmlspecialchars($prescription['diagnosis'])); ?></p>
                </div>
            </div>
            <?php endif; ?>

            <div class="row mt-4">
                <div class="col-12">
                    <h6>Prescribed Medicines</h6>
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Medicine</th>
                                <th>Dosage</th>
                                <th>Duration</th>
                                <th>Instructions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($item = $items->fetch_assoc()): ?>
                            <tr>
                                <td>
                                    <?php 
                                    echo htmlspecialchars($item['medicine_name']);
                                    if ($item['generic_name']) {
                                        echo ' (' . htmlspecialchars($item['generic_name']) . ')';
                                    }
                                    ?>
                                </td>
                                <td><?php echo htmlspecialchars($item['dosage']); ?></td>
                                <td><?php echo htmlspecialchars($item['duration']); ?></td>
                                <td><?php echo htmlspecialchars($item['instructions']); ?></td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <?php if ($prescription['notes']): ?>
            <div class="row mt-3">
                <div class="col-12">
                    <p><strong>Notes:</strong></p>
                    <p><?php echo nl2br(htmlspecialchars($prescription['notes'])); ?></p>
                </div>
            </div>
            <?php endif; ?>

            <!-- Signature - Only visible when printing -->
            <div class="print-only mt-5">
                <div class="row">
                    <div class="col-6">
                        <p class="mt-5">____________________</p>
                        <p>Doctor's Signature</p>
                    </div>
                    <div class="col-6 text-end">
                        <p class="mt-5">____________________</p>
                        <p>Pharmacy Stamp</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
@media screen {
    .print-only {
        display: none;
    }
}

@media print {
    .btn, .navbar, .footer {
        display: none !important;
    }
    .card {
        border: none !important;
    }
    .card-header {
        display: none !important;
    }
    .card-body {
        padding: 0 !important;
    }
    .container {
        max-width: 100% !important;
        padding: 0 !important;
        margin: 0 !important;
    }
}
</style>

<script>
function printPrescription() {
    window.print();
}
</script>

<?php require_once '../../includes/footer.php'; ?> 