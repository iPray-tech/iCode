<?php
require_once '../../config/database.php';
require_once '../../includes/auth.php';
requireLogin();

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'] ?? '';
    $phone = $_POST['phone'] ?? '';
    $email = $_POST['email'] ?? '';
    $address = $_POST['address'] ?? '';
    $allergies = $_POST['allergies'] ?? '';
    
    if (empty($name) || empty($phone)) {
        echo json_encode(['success' => false, 'error' => 'Name and phone are required']);
        exit;
    }
    
    $stmt = $conn->prepare("INSERT INTO patients (name, phone, email, address, allergies) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssss", $name, $phone, $email, $address, $allergies);
    
    if ($stmt->execute()) {
        $patient_id = $conn->insert_id;
        echo json_encode([
            'success' => true,
            'patient' => [
                'id' => $patient_id,
                'name' => $name,
                'phone' => $phone
            ]
        ]);
    } else {
        echo json_encode(['success' => false, 'error' => $conn->error]);
    }
} else {
    echo json_encode(['success' => false, 'error' => 'Invalid request method']);
}
?> 