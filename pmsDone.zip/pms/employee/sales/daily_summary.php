<?php
require_once '../../config/database.php';
require_once '../../includes/auth.php';
require_once '../../includes/header.php';
requireLogin();

// Get date from query parameter, default to today
$date = $_GET['date'] ?? date('Y-m-d');

// Get all sales for the specified date
$stmt = $conn->prepare("
    SELECT s.*,
           u.username as employee_name,
           COUNT(si.id) as total_items,
           GROUP_CONCAT(
               CONCAT(m.name, ' (', si.quantity, ')') 
               SEPARATOR ', '
           ) as items_list
    FROM sales s
    JOIN users u ON s.employee_id = u.id
    LEFT JOIN sale_items si ON s.id = si.sale_id
    LEFT JOIN medicines m ON si.medicine_id = m.id
    WHERE DATE(s.sale_date) = ?
    GROUP BY s.id, s.sale_date, s.employee_id, s.customer_name, s.total_amount, s.status, u.username
    ORDER BY s.sale_date DESC
");
$stmt->bind_param("s", $date);
$stmt->execute();
$sales = $stmt->get_result();

// Get daily summary with COALESCE to handle nulls
$stmt = $conn->prepare("
    SELECT 
        COUNT(DISTINCT CASE WHEN status = 'completed' THEN s.id END) as total_sales,
        COALESCE(SUM(CASE WHEN status = 'completed' THEN total_amount ELSE 0 END), 0) as total_revenue,
        COUNT(DISTINCT CASE WHEN status = 'reversed' THEN s.id END) as reversed_sales,
        COALESCE(SUM(CASE WHEN status = 'reversed' THEN total_amount ELSE 0 END), 0) as reversed_amount,
        COALESCE(SUM(CASE 
            WHEN status = 'completed' THEN total_amount 
            WHEN status = 'reversed' THEN -total_amount 
            ELSE 0 
        END), 0) as net_revenue,
        COUNT(DISTINCT employee_id) as active_employees,
        
        -- Payment method statistics for completed sales
        COUNT(CASE WHEN payment_method = 'cash' AND status = 'completed' THEN 1 END) as cash_transactions,
        COALESCE(SUM(CASE WHEN payment_method = 'cash' AND status = 'completed' THEN total_amount ELSE 0 END), 0) as cash_sales,
        
        -- Add reversed cash amount
        COALESCE(SUM(CASE WHEN payment_method = 'cash' AND status = 'reversed' THEN total_amount ELSE 0 END), 0) as reversed_cash,
        
        COUNT(CASE WHEN payment_method = 'card' AND status = 'completed' THEN 1 END) as card_transactions,
        COALESCE(SUM(CASE WHEN payment_method = 'card' AND status = 'completed' THEN total_amount ELSE 0 END), 0) as card_sales,
        
        COUNT(CASE WHEN payment_method = 'mobile_money' AND status = 'completed' THEN 1 END) as mobile_transactions,
        COALESCE(SUM(CASE WHEN payment_method = 'mobile_money' AND status = 'completed' THEN total_amount ELSE 0 END), 0) as mobile_sales
    FROM sales s
    WHERE DATE(sale_date) = ?
");
$stmt->bind_param("s", $date);
$stmt->execute();
$summary = $stmt->get_result()->fetch_assoc();

// Get per-employee summary with COALESCE
$stmt = $conn->prepare("
    SELECT 
        u.username,
        COUNT(DISTINCT CASE WHEN status = 'completed' THEN s.id END) as total_sales,
        COALESCE(SUM(CASE WHEN status = 'completed' THEN total_amount ELSE 0 END), 0) as total_revenue,
        COUNT(DISTINCT CASE WHEN status = 'reversed' THEN s.id END) as reversed_sales,
        COALESCE(SUM(CASE WHEN status = 'reversed' THEN total_amount ELSE 0 END), 0) as reversed_amount,
        COALESCE(SUM(CASE 
            WHEN status = 'completed' THEN total_amount 
            WHEN status = 'reversed' THEN -total_amount 
            ELSE 0 
        END), 0) as net_revenue
    FROM users u
    LEFT JOIN sales s ON u.id = s.employee_id AND DATE(s.sale_date) = ?
    WHERE u.role = 'employee'
    GROUP BY u.id, u.username
    ORDER BY net_revenue DESC
");
$stmt->bind_param("s", $date);
$stmt->execute();
$employee_summary = $stmt->get_result();

// Check if there's already an account closure request for this date
$stmt = $conn->prepare("
    SELECT * FROM account_closures 
    WHERE requested_by = ? AND date = ?
    ORDER BY requested_at DESC 
    LIMIT 1
");
$stmt->bind_param("is", $_SESSION['user_id'], $date);
$stmt->execute();
$existing_closure = $stmt->get_result()->fetch_assoc();

// Determine if user can request closure
$can_request_closure = true;
$closure_message = '';

if ($existing_closure) {
    switch ($existing_closure['status']) {
        case 'pending':
            $can_request_closure = false;
            $closure_message = '<div class="alert alert-info">Your account closure request is pending approval.</div>';
            break;
        case 'approved':
            $can_request_closure = false;
            $closure_message = '<div class="alert alert-success">Your account has been closed for this date.</div>';
            break;
        case 'rejected':
            $can_request_closure = true;
            $closure_message = '<div class="alert alert-warning">Your previous request was rejected. You can submit a new request.</div>';
            break;
    }
}

?>

<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="card-title mb-0">Daily Sales Summary</h5>
        <div>
            <form class="d-inline-block me-2">
                <input type="date" class="form-control" name="date" value="<?php echo $date; ?>" 
                       onchange="this.form.submit()">
            </form>
            <div class="mb-3">
                <?php 
                echo $closure_message;
                if ($can_request_closure): 
                ?>
                    <button type="button" class="btn btn-primary" onclick="requestAccountClosure()">
                        <?php echo $existing_closure ? 'Request New Account Closure' : 'Request Account Closure'; ?>
                    </button>
                <?php endif; ?>
            </div>
            <a href="history.php" class="btn btn-secondary">Back to Sales</a>
        </div>
    </div>
    <div class="card-body">
        <!-- Daily Summary -->
        <div class="row mb-4">
            <div class="col-md-3">
                <div class="card bg-primary bg-gradient text-white">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-start">
                            <div>
                                <h6 class="card-title">Total Sales</h6>
                                <h3 class="mb-0"><?php echo $summary['total_sales']; ?></h3>
                            </div>
                            <div class="rounded-circle bg-white p-2">
                                <i class="bi bi-cart text-primary"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card bg-success bg-gradient text-white">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-start">
                            <div>
                                <h6 class="card-title">Gross Revenue</h6>
                                <h3 class="mb-0"><?php echo formatMoney($summary['total_revenue']); ?></h3>
                            </div>
                            <div class="rounded-circle bg-white p-2">
                                <i class="bi bi-cash text-success"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card bg-danger bg-gradient text-white">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-start">
                            <div>
                                <h6 class="card-title">Reversed Sales</h6>
                                <h3 class="mb-0"><?php echo formatMoney($summary['reversed_amount']); ?></h3>
                            </div>
                            <div class="rounded-circle bg-white p-2">
                                <i class="bi bi-arrow-return-left text-danger"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card bg-info bg-gradient text-white">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-start">
                            <div>
                                <h6 class="card-title">Net Revenue</h6>
                                <h3 class="mb-0"><?php echo formatMoney($summary['net_revenue']); ?></h3>
                            </div>
                            <div class="rounded-circle bg-white p-2">
                                <i class="bi bi-wallet2 text-info"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Add this after the summary cards -->
        <div class="row mb-4">
            <div class="col-md-4">
                <div class="card">
                    <div class="card-body">
                        <h6 class="card-title">Cash Payments</h6>
                        <div class="d-flex justify-content-between">
                            <div>
                                <p class="mb-0">Transactions: <?php echo $summary['cash_transactions']; ?></p>
                                <h4><?php echo formatMoney($summary['cash_sales']); ?></h4>
                            </div>
                            <div class="text-end">
                                <i class="bi bi-cash-stack text-success fs-3"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card">
                    <div class="card-body">
                        <h6 class="card-title">Card Payments</h6>
                        <div class="d-flex justify-content-between">
                            <div>
                                <p class="mb-0">Transactions: <?php echo $summary['card_transactions']; ?></p>
                                <h4><?php echo formatMoney($summary['card_sales']); ?></h4>
                            </div>
                            <div class="text-end">
                                <i class="bi bi-credit-card text-primary fs-3"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card">
                    <div class="card-body">
                        <h6 class="card-title">Mobile Money</h6>
                        <div class="d-flex justify-content-between">
                            <div>
                                <p class="mb-0">Transactions: <?php echo $summary['mobile_transactions']; ?></p>
                                <h4><?php echo formatMoney($summary['mobile_sales']); ?></h4>
                            </div>
                            <div class="text-end">
                                <i class="bi bi-phone text-info fs-3"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Employee Summary -->
        <h6>Employee Performance</h6>
        <div class="table-responsive mb-4">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Employee</th>
                        <th>Sales Count</th>
                        <th>Gross Revenue</th>
                        <th>Reversed Sales</th>
                        <th>Reversed Amount</th>
                        <th>Net Revenue</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($emp = $employee_summary->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($emp['username']); ?></td>
                        <td><?php echo $emp['total_sales']; ?></td>
                        <td><?php echo formatMoney($emp['total_revenue']); ?></td>
                        <td><?php echo $emp['reversed_sales']; ?></td>
                        <td><?php echo formatMoney($emp['reversed_amount']); ?></td>
                        <td>
                            <span class="<?php echo $emp['net_revenue'] >= 0 ? 'text-success' : 'text-danger'; ?>">
                                <?php echo formatMoney($emp['net_revenue']); ?>
                            </span>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>

        <!-- Detailed Sales List -->
        <h6>Detailed Sales List</h6>
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Time</th>
                        <th>Employee</th>
                        <th>Customer</th>
                        <th>Items</th>
                        <th>Amount</th>
                        <th>Payment</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($sale = $sales->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo formatDate($sale['sale_date'], 'H:i'); ?></td>
                        <td><?php echo htmlspecialchars($sale['employee_name'] ?? ''); ?></td>
                        <td><?php echo htmlspecialchars($sale['customer_name'] ?? ''); ?></td>
                        <td>
                            <small><?php echo htmlspecialchars($sale['items_list'] ?? ''); ?></small>
                        </td>
                        <td><?php echo formatMoney($sale['total_amount']); ?></td>
                        <td>
                            <span class="badge bg-<?php 
                                echo $sale['payment_method'] === 'cash' ? 'success' : 
                                    ($sale['payment_method'] === 'card' ? 'info' : 'warning'); 
                            ?>">
                                <?php echo ucfirst($sale['payment_method']); ?>
                            </span>
                        </td>
                        <td>
                            <span class="badge bg-<?php 
                                echo $sale['status'] === 'completed' ? 'success' : 
                                    ($sale['status'] === 'reversed' ? 'danger' : 'warning'); 
                            ?>">
                                <?php echo ucfirst($sale['status']); ?>
                            </span>
                        </td>
                        <td>
                            <a href="view_sale.php?id=<?php echo $sale['id']; ?>" 
                               class="btn btn-sm btn-info">
                                <i class="bi bi-eye"></i>
                            </a>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>

        <!-- Payment Methods Breakdown -->
        <div class="mb-3">
            <h6>Payment Methods Breakdown</h6>
            <table class="table table-sm">
                <tr>
                    <th>Method</th>
                    <th>Transactions</th>
                    <th>Amount</th>
                </tr>
                <tr>
                    <td>Cash</td>
                    <td><?php echo $summary['cash_transactions']; ?></td>
                    <td><?php echo formatMoney($summary['cash_sales']); ?></td>
                </tr>
                <tr>
                    <td>Card</td>
                    <td><?php echo $summary['card_transactions']; ?></td>
                    <td><?php echo formatMoney($summary['card_sales']); ?></td>
                </tr>
                <tr>
                    <td>Mobile Money</td>
                    <td><?php echo $summary['mobile_transactions']; ?></td>
                    <td><?php echo formatMoney($summary['mobile_sales']); ?></td>
                </tr>
                <?php if ($summary['reversed_sales'] > 0): ?>
                <tr class="text-danger">
                    <td>Reversed Sales</td>
                    <td><?php echo $summary['reversed_sales']; ?></td>
                    <td><?php echo formatMoney($summary['reversed_amount']); ?></td>
                </tr>
                <?php endif; ?>
                <tr class="table-info">
                    <th>Total</th>
                    <th><?php echo $summary['total_sales']; ?></th>
                    <th><?php echo formatMoney($summary['total_revenue']); ?></th>
                </tr>
            </table>
        </div>
    </div>
</div>

<div class="modal fade" id="closeAccountModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Close Daily Account</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <form id="closeAccountForm">
                    <input type="hidden" name="date" value="<?php echo $date; ?>">
                    <div class="mb-3">
                        <h6>System Totals</h6>
                        <table class="table table-sm">
                            <tr>
                                <td>Cash Sales:</td>
                                <td><?php echo formatMoney($summary['cash_sales']); ?></td>
                            </tr>
                            <tr>
                                <td>Card Sales:</td>
                                <td><?php echo formatMoney($summary['card_sales']); ?></td>
                            </tr>
                            <tr>
                                <td>Mobile Money:</td>
                                <td><?php echo formatMoney($summary['mobile_sales']); ?></td>
                            </tr>
                            <tr>
                                <td>Reversed Sales:</td>
                                <td>
                                    <span class="text-danger"><?php echo $summary['reversed_sales']; ?> sales</span>
                                    <br>
                                    <small class="text-muted">Already in cash: <?php echo formatMoney($summary['reversed_cash']); ?></small>
                                </td>
                            </tr>
                            <tr class="table-info">
                                <th>Total Cash Expected:</th>
                                <th><?php echo formatMoney($summary['cash_sales']); ?></th>
                            </tr>
                        </table>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Cash in Hand</label>
                        <input type="number" step="0.01" class="form-control" name="cash_amount" required
                               onchange="calculateDifference(this.value)">
                        <div id="cashDifference" class="form-text"></div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Notes</label>
                        <textarea class="form-control" name="notes" rows="3" 
                                  placeholder="Enter any notes about the day's sales or discrepancies..."></textarea>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-primary" onclick="submitCloseAccount()">Submit</button>
            </div>
        </div>
    </div>
</div>

<script>
function calculateDifference(cashAmount) {
    const expectedCash = <?php echo $summary['cash_sales']; ?>;
    const difference = cashAmount - expectedCash;
    const percentage = expectedCash > 0 ? (difference / expectedCash) * 100 : 0;
    
    const diffElement = document.getElementById('cashDifference');
    if (Math.abs(difference) > 0.01) { // More than 1 pesewa difference
        const color = difference > 0 ? 'text-success' : 'text-danger';
        diffElement.innerHTML = `
            <span class="${color}">
                ${difference > 0 ? 'Excess' : 'Shortage'}: ${formatMoney(Math.abs(difference))}
                (${Math.abs(percentage).toFixed(1)}%)
            </span>`;
    } else {
        diffElement.innerHTML = '<span class="text-success">Balanced ✓</span>';
    }
}

function requestAccountClosure() {
    // Get the system total from PHP
    const systemTotal = <?php echo $summary['cash_sales'] ?? 0; ?>;
    
    if (!confirm('Are you sure you want to request account closure?')) {
        return;
    }

    // Show the confirmation dialog with system amount
    const message = `System Total Amount: ${formatMoney(systemTotal)}\n\nPlease enter your cash amount:`;
    const cashAmount = prompt(message);
    
    if (cashAmount === null || cashAmount.trim() === '') {
        return;
    }

    // Calculate and show the difference
    const cashValue = parseFloat(cashAmount);
    const difference = cashValue - systemTotal;
    const differenceMessage = difference === 0 ? 
        'The amounts match perfectly!' : 
        `Difference: ${formatMoney(Math.abs(difference))} (${difference > 0 ? 'Excess' : 'Shortage'})`;

    const confirmMessage = `System Amount: ${formatMoney(systemTotal)}\n` +
                         `Cash Amount: ${formatMoney(cashValue)}\n` +
                         `${differenceMessage}\n\n` +
                         `Would you like to add any notes?`;

    const notes = prompt(confirmMessage);

    const formData = new FormData();
    formData.append('date', '<?php echo $date; ?>');
    formData.append('cash_amount', cashValue);
    formData.append('system_amount', systemTotal);
    if (notes) {
        formData.append('notes', notes);
    }

    // Add difference information to notes
    const autoNotes = `System Amount: ${formatMoney(systemTotal)}\n` +
                     `Cash Amount: ${formatMoney(cashValue)}\n` +
                     `${differenceMessage}\n` +
                     (notes ? `\nUser Notes: ${notes}` : '');
    
    formData.append('notes', autoNotes);

    fetch('request_close_account.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert('Account closure request submitted successfully!');
            location.reload();
        } else {
            alert('Error: ' + data.error);
        }
    })
    .catch(error => {
        alert('Error: ' + error);
    });
}

function formatMoney(amount) {
    return 'GH₵ ' + parseFloat(amount).toFixed(2);
}
</script>

<?php require_once '../../includes/footer.php'; ?> 