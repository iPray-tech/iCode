<?php
require_once '../../config/database.php';
require_once '../../includes/auth.php';
requireLogin();

if (!isset($_GET['id'])) {
    echo "Sale ID is required";
    exit;
}

$sale_id = (int)$_GET['id'];

// Get sale details
$stmt = $conn->prepare("
    SELECT s.*, u.username as employee_name 
    FROM sales s
    LEFT JOIN users u ON s.employee_id = u.id
    WHERE s.id = ?
");
$stmt->bind_param("i", $sale_id);
$stmt->execute();
$sale = $stmt->get_result()->fetch_assoc();

if (!$sale) {
    echo "Sale not found";
    exit;
}

// Get sale items
$stmt = $conn->prepare("
    SELECT si.*, m.name as medicine_name, m.generic_name
    FROM sale_items si
    JOIN medicines m ON si.medicine_id = m.id
    WHERE si.sale_id = ?
");
$stmt->bind_param("i", $sale_id);
$stmt->execute();
$items = $stmt->get_result();
?>

<div class="container-fluid">
    <div class="row mb-3">
        <div class="col-md-6">
            <p><strong>Sale ID:</strong> <?php echo $sale['id']; ?></p>
            <p><strong>Customer:</strong> <?php echo htmlspecialchars($sale['customer_name']); ?></p>
            <p><strong>Date:</strong> <?php echo date('Y-m-d H:i', strtotime($sale['sale_date'])); ?></p>
        </div>
        <div class="col-md-6">
            <p><strong>Employee:</strong> <?php echo htmlspecialchars($sale['employee_name']); ?></p>
            <p><strong>Total Amount:</strong> $<?php echo number_format($sale['total_amount'], 2); ?></p>
        </div>
    </div>

    <div class="table-responsive">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Medicine</th>
                    <th>Generic Name</th>
                    <th>Quantity</th>
                    <th>Unit Price</th>
                    <th>Total</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($item = $items->fetch_assoc()): ?>
                <tr>
                    <td><?php echo htmlspecialchars($item['medicine_name']); ?></td>
                    <td><?php echo htmlspecialchars($item['generic_name']); ?></td>
                    <td><?php echo $item['quantity']; ?></td>
                    <td>$<?php echo number_format($item['unit_price'], 2); ?></td>
                    <td>$<?php echo number_format($item['total_price'], 2); ?></td>
                </tr>
                <?php endwhile; ?>
            </tbody>
            <tfoot>
                <tr>
                    <td colspan="4" class="text-end"><strong>Grand Total:</strong></td>
                    <td><strong>$<?php echo number_format($sale['total_amount'], 2); ?></strong></td>
                </tr>
            </tfoot>
        </table>
    </div>
</div> 