<?php
require_once '../../config/database.php';
require_once '../../includes/auth.php';
require_once '../../includes/header.php';
requireLogin();

// Display success message if exists
if (isset($_SESSION['success_message'])) {
    echo '<div class="alert alert-success alert-dismissible fade show" role="alert">';
    echo htmlspecialchars($_SESSION['success_message']);
    echo '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>';
    echo '</div>';
    unset($_SESSION['success_message']); // Clear the message
}

// Prevent admin access to employee sales
if (isAdmin()) {
    redirectToUserDashboard();
}

// Get sales history for this employee
try {
    $stmt = $conn->prepare("
        SELECT s.*, 
               s.status,
               COUNT(si.id) as total_items,
               COALESCE(p.name, '') as patient_name,
               COALESCE(pr.id, 0) as prescription_id,
               CASE 
                   WHEN s.status = 'reversal' THEN s.reference_sale_id
                   WHEN s.status = 'reversed' THEN (SELECT id FROM sales WHERE reference_sale_id = s.id)
                   ELSE NULL 
               END as related_sale_id
        FROM sales s
        LEFT JOIN sale_items si ON s.id = si.sale_id
        LEFT JOIN patients p ON s.patient_id = p.id
        LEFT JOIN prescriptions pr ON s.prescription_id = pr.id
        WHERE s.employee_id = ?
        GROUP BY s.id
        ORDER BY s.sale_date DESC
    ");
    $stmt->bind_param("i", $_SESSION['user_id']);
    $stmt->execute();
    $sales = $stmt->get_result();
} catch (Exception $e) {
    // If tables don't exist, just show basic sales info
    $stmt = $conn->prepare("
        SELECT s.*, 
               COUNT(si.id) as total_items
        FROM sales s
        LEFT JOIN sale_items si ON s.id = si.sale_id
        WHERE s.employee_id = ?
        GROUP BY s.id
        ORDER BY s.sale_date DESC
    ");
    $stmt->bind_param("i", $_SESSION['user_id']);
    $stmt->execute();
    $sales = $stmt->get_result();
}
?>

<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="card-title mb-0">Sales History</h5>
        <a href="new_sale.php" class="btn btn-primary">New Sale</a>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Customer</th>
                        <th>Patient</th>
                        <th>Items</th>
                        <th>Amount</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($sale = $sales->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo formatDate($sale['sale_date'], 'Y-m-d H:i'); ?></td>
                        <td><?php echo htmlspecialchars($sale['customer_name']); ?></td>
                        <td>
                            <?php if (isset($sale['patient_name']) && $sale['patient_name']): ?>
                                <?php echo htmlspecialchars($sale['patient_name']); ?>
                                <?php if ($sale['prescription_id']): ?>
                                    <span class="badge bg-info">Prescription</span>
                                <?php endif; ?>
                            <?php else: ?>
                                <span class="text-muted">-</span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo $sale['total_items']; ?></td>
                        <td><?php echo formatMoney($sale['total_amount'] ?? 0); ?></td>
                        <td>
                            <?php if ($sale['status'] === 'reversed'): ?>
                                <span class="badge bg-danger">Reversed</span>
                            <?php else: ?>
                                <span class="badge bg-success">Completed</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <a href="view_sale.php?id=<?php echo $sale['id']; ?>" 
                               class="btn btn-sm btn-info">View</a>
                            <button onclick="printReceipt(<?php echo $sale['id']; ?>)" 
                                    class="btn btn-sm btn-secondary">Print</button>
                            <?php if ($sale['status'] === 'completed'): ?>
                                <button onclick="requestReversal(<?php echo $sale['id']; ?>)" 
                                        class="btn btn-sm btn-warning">Request Reversal</button>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
function printReceipt(saleId) {
    window.open('print_receipt.php?id=' + saleId, '_blank');
}

function requestReversal(saleId) {
    const reason = prompt('Please enter the reason for reversal:');
    if (!reason) return; // User cancelled or entered empty reason
    
    fetch('request_reversal.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `sale_id=${saleId}&reason=${encodeURIComponent(reason)}`
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert('Reversal request submitted successfully');
            location.reload();
        } else {
            alert('Error: ' + (data.error || 'Unknown error occurred'));
        }
    })
    .catch(error => {
        alert('Error: ' + error.message);
    });
}
</script>

<?php require_once '../../includes/footer.php'; ?>
