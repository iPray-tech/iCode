<?php
require_once '../../config/database.php';
require_once '../../includes/auth.php';
require_once '../../includes/header.php';
requireLogin();

// Get all available medicines
$query = "SELECT m.*, s.name as supplier_name 
          FROM medicines m 
          LEFT JOIN suppliers s ON m.supplier_id = s.id 
          WHERE m.stock_quantity > 0 
          AND (m.expiry_date IS NULL OR m.expiry_date > CURDATE())
          ORDER BY m.name ASC";
$medicines = $conn->query($query);

// Get all patients for dropdown
$patients = $conn->query("SELECT id, name, phone FROM patients ORDER BY name ASC");

// Convert medicines to JSON for JavaScript
$medicines_json = [];
while ($medicine = $medicines->fetch_assoc()) {
    $medicines_json[] = [
        'id' => $medicine['id'],
        'name' => $medicine['name'],
        'generic_name' => $medicine['generic_name'],
        'unit_price' => $medicine['unit_price'],
        'stock_quantity' => $medicine['stock_quantity']
    ];
}

// Add this at the top of the file after getting medicines
$prescription = null;
if (isset($_GET['prescription_id'])) {
    $prescription_id = (int)$_GET['prescription_id'];
    
    // Get prescription details with patient information
    $stmt = $conn->prepare("
        SELECT p.*, pt.name as patient_name, pt.id as patient_id
        FROM prescriptions p
        JOIN patients pt ON p.patient_id = pt.id
        WHERE p.id = ?
    ");
    $stmt->bind_param("i", $prescription_id);
    $stmt->execute();
    $prescription = $stmt->get_result()->fetch_assoc();
    
    if ($prescription) {
        // Get prescription items
        $stmt = $conn->prepare("
            SELECT pi.*, m.name as medicine_name, m.unit_price, m.stock_quantity
            FROM prescription_items pi
            JOIN medicines m ON pi.medicine_id = m.id
            WHERE pi.prescription_id = ?
        ");
        $stmt->bind_param("i", $prescription_id);
        $stmt->execute();
        $prescription_items = $stmt->get_result();
    }
}
?>

<script>
    const CURRENCY_SYMBOL = '<?php echo CURRENCY_SYMBOL; ?>';
</script>

<div class="card">
    <div class="card-header">
        <h5 class="card-title mb-0">New Sale</h5>
    </div>
    <div class="card-body">
        <form id="saleForm" method="POST" action="process_sale.php">
            <div class="row mb-3">
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="patient_id" class="form-label">Select Patient</label>
                        <select class="form-select" id="patient_id" name="patient_id">
                            <option value="">Walk-in Customer</option>
                            <?php while ($patient = $patients->fetch_assoc()): ?>
                                <option value="<?php echo $patient['id']; ?>">
                                    <?php echo htmlspecialchars($patient['name'] . ' (' . $patient['phone'] . ')'); ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    <button type="button" class="btn btn-secondary mb-3" onclick="showNewPatientModal()">
                        Add New Patient
                    </button>
                </div>
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="customer_name" class="form-label">Customer Name</label>
                        <input type="text" class="form-control" id="customer_name" name="customer_name" required>
                    </div>
                </div>
            </div>
            
            <div class="row mb-3">
                <div class="col-12">
                    <div class="d-flex justify-content-between align-items-center mb-2">
                        <h6>Sale Items</h6>
                        <button type="button" class="btn btn-primary btn-sm" onclick="addItem()">Add Item</button>
                    </div>
                    
                    <div class="table-responsive">
                        <table class="table table-bordered" id="saleItems">
                            <thead>
                                <tr>
                                    <th>Medicine</th>
                                    <th>Available Stock</th>
                                    <th>Quantity</th>
                                    <th>Unit Price</th>
                                    <th>Total</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody></tbody>
                            <tfoot>
                                <tr>
                                    <td colspan="4" class="text-end"><strong>Grand Total:</strong></td>
                                    <td colspan="2"><strong id="grandTotal"><?php echo CURRENCY_SYMBOL; ?> 0.00</strong></td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
            
            <?php if ($prescription): ?>
                <input type="hidden" name="prescription_id" value="<?php echo $prescription['id']; ?>">
                <div class="alert alert-info">
                    <h6>Prescription Details:</h6>
                    <p>
                        <strong>Doctor:</strong> <?php echo htmlspecialchars($prescription['doctor_name']); ?><br>
                        <strong>Date:</strong> <?php echo date('Y-m-d', strtotime($prescription['created_at'])); ?>
                    </p>
                    <?php if ($prescription['diagnosis']): ?>
                        <p><strong>Diagnosis:</strong> <?php echo htmlspecialchars($prescription['diagnosis']); ?></p>
                    <?php endif; ?>
                </div>
                
                <script>
                document.addEventListener('DOMContentLoaded', function() {
                    // Auto-select patient
                    const patientSelect = document.getElementById('patient_id');
                    patientSelect.value = '<?php echo $prescription['patient_id']; ?>';
                    document.getElementById('customer_name').value = '<?php echo addslashes($prescription['patient_name']); ?>';
                    
                    // Add prescription items to sale
                    <?php 
                    $prescription_items->data_seek(0);
                    while ($item = $prescription_items->fetch_assoc()): 
                    ?>
                    addPrescriptionItem({
                        medicine_id: <?php echo $item['medicine_id']; ?>,
                        medicine_name: '<?php echo addslashes($item['medicine_name']); ?>',
                        unit_price: <?php echo $item['unit_price']; ?>,
                        stock_quantity: <?php echo $item['stock_quantity']; ?>,
                        prescribed_quantity: 1 // You might want to calculate this based on dosage
                    });
                    <?php endwhile; ?>
                });
                
                function addPrescriptionItem(item) {
                    const tbody = document.querySelector('#saleItems tbody');
                    const row = document.createElement('tr');
                    
                    row.innerHTML = `
                        <td>
                            <select class="form-select medicine-select" onchange="updateStock(this)" required>
                                <option value="${item.medicine_id}" 
                                        data-price="${item.unit_price}"
                                        data-stock="${item.stock_quantity}" selected>
                                    ${item.medicine_name}
                                </option>
                            </select>
                        </td>
                        <td class="stock-display">${item.stock_quantity}</td>
                        <td>
                            <input type="number" class="form-control quantity-input" 
                                   min="1" max="${item.stock_quantity}" 
                                   value="${item.prescribed_quantity}"
                                   onchange="updateTotal(this)" required>
                        </td>
                        <td class="text-end">${CURRENCY_SYMBOL} ${item.unit_price.toFixed(2)}</td>
                        <td class="text-end">${CURRENCY_SYMBOL} ${(item.unit_price * item.prescribed_quantity).toFixed(2)}</td>
                        <td>
                            <button type="button" class="btn btn-danger btn-sm" onclick="removeItem(this)">
                                Remove
                            </button>
                        </td>
                    `;
                    
                    tbody.appendChild(row);
                    updateGrandTotal();
                }
                </script>
            <?php endif; ?>
            
            <button type="submit" class="btn btn-primary">Complete Sale</button>
            <button type="button" class="btn btn-secondary" onclick="resetForm()">Reset</button>
        </form>
    </div>
</div>

<!-- New Patient Modal -->
<div class="modal fade" id="newPatientModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Add New Customer</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <form id="newPatientForm">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="new_name" class="form-label">Customer Name</label>
                                <input type="text" class="form-control" id="new_name" name="name" required>
                            </div>
                            <div class="mb-3">
                                <label for="new_phone" class="form-label">Phone Number</label>
                                <input type="tel" class="form-control" id="new_phone" name="phone" required>
                            </div>
                            <div class="mb-3">
                                <label for="new_email" class="form-label">Email</label>
                                <input type="email" class="form-control" id="new_email" name="email">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="new_address" class="form-label">Address</label>
                                <textarea class="form-control" id="new_address" name="address" rows="3"></textarea>
                            </div>
                            <div class="mb-3">
                                <label for="new_allergies" class="form-label">Allergies</label>
                                <textarea class="form-control" id="new_allergies" name="allergies" rows="2"></textarea>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" onclick="saveNewPatient()">Save Patient</button>
            </div>
        </div>
    </div>
</div>

<script>
const medicines = <?php echo json_encode($medicines_json); ?>;
let patientModal;

document.addEventListener('DOMContentLoaded', function() {
    patientModal = new bootstrap.Modal(document.getElementById('newPatientModal'));
    
    // Update customer name when patient is selected
    document.getElementById('patient_id').addEventListener('change', function() {
        const selectedOption = this.options[this.selectedIndex];
        document.getElementById('customer_name').value = selectedOption.text.split(' (')[0] || '';
    });
});

function showNewPatientModal() {
    document.getElementById('newPatientForm').reset();
    patientModal.show();
}

function saveNewPatient() {
    const formData = new FormData(document.getElementById('newPatientForm'));
    
    fetch('add_patient_ajax.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Add new patient to dropdown
            const select = document.getElementById('patient_id');
            const option = new Option(
                data.patient.name + ' (' + data.patient.phone + ')', 
                data.patient.id
            );
            select.add(option);
            select.value = data.patient.id;
            
            // Update customer name
            document.getElementById('customer_name').value = data.patient.name;
            
            patientModal.hide();
        } else {
            alert('Error adding patient: ' + data.error);
        }
    });
}

let itemCounter = 0;

function addItem() {
    const tbody = document.querySelector('#saleItems tbody');
    const row = document.createElement('tr');
    
    row.innerHTML = `
        <td>
            <select class="form-select medicine-select" onchange="updateStock(this)" required>
                <option value="">Select Medicine</option>
                ${medicines.map(m => `
                    <option value="${m.id}" 
                            data-price="${m.unit_price}"
                            data-stock="${m.stock_quantity}">
                        ${m.name} (${m.generic_name || 'No generic name'})
                    </option>
                `).join('')}
            </select>
        </td>
        <td class="stock-display">-</td>
        <td>
            <input type="number" class="form-control quantity-input" 
                   min="1" onchange="updateTotal(this)" required>
        </td>
        <td class="text-end">${CURRENCY_SYMBOL} 0.00</td>
        <td class="text-end">${CURRENCY_SYMBOL} 0.00</td>
        <td>
            <button type="button" class="btn btn-danger btn-sm" onclick="removeItem(this)">
                Remove
            </button>
        </td>
    `;
    
    tbody.appendChild(row);
    itemCounter++;
}

function updateStock(select) {
    const row = select.closest('tr');
    const option = select.selectedOptions[0];
    const stockDisplay = row.querySelector('.stock-display');
    const quantityInput = row.querySelector('.quantity-input');
    const unitPriceDisplay = row.querySelectorAll('.text-end')[0];
    
    if (option.value) {
        const stock = option.dataset.stock;
        const price = option.dataset.price;
        
        stockDisplay.textContent = stock;
        unitPriceDisplay.textContent = CURRENCY_SYMBOL + ' ' + parseFloat(price).toFixed(2);
        quantityInput.max = stock;
        quantityInput.value = '1';
        
        updateTotal(quantityInput);
    } else {
        stockDisplay.textContent = '-';
        unitPriceDisplay.textContent = CURRENCY_SYMBOL + ' 0.00';
        quantityInput.value = '';
        updateGrandTotal();
    }
}

function updateTotal(input) {
    const row = input.closest('tr');
    const select = row.querySelector('.medicine-select');
    const option = select.selectedOptions[0];
    const quantity = parseInt(input.value) || 0;
    
    if (option.value && quantity > 0) {
        const price = parseFloat(option.dataset.price);
        const total = price * quantity;
        const totalCell = row.querySelectorAll('.text-end')[1];
        totalCell.textContent = CURRENCY_SYMBOL + ' ' + total.toFixed(2);
    } else {
        const totalCell = row.querySelectorAll('.text-end')[1];
        totalCell.textContent = CURRENCY_SYMBOL + ' 0.00';
    }
    
    updateGrandTotal();
}

function updateGrandTotal() {
    const totals = Array.from(document.querySelectorAll('#saleItems tbody tr'))
        .map(row => {
            const totalCell = row.querySelectorAll('.text-end')[1];
            if (totalCell) {
                return parseFloat(totalCell.textContent.replace(CURRENCY_SYMBOL + ' ', '')) || 0;
            }
            return 0;
        });
    
    const grandTotal = totals.reduce((sum, total) => sum + total, 0);
    const allGrandTotalElements = document.querySelectorAll('#grandTotal');
    allGrandTotalElements.forEach(element => {
        element.textContent = CURRENCY_SYMBOL + ' ' + grandTotal.toFixed(2);
    });
}

function removeItem(button) {
    button.closest('tr').remove();
    updateGrandTotal();
}

function resetForm() {
    document.getElementById('saleForm').reset();
    document.querySelector('#saleItems tbody').innerHTML = '';
    updateGrandTotal();
}

// Add first item row by default
addItem();

// Form submission handling
document.getElementById('saleForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const formData = new FormData();
    formData.append('customer_name', document.getElementById('customer_name').value);
    
    const items = [];
    document.querySelectorAll('#saleItems tbody tr').forEach(row => {
        const select = row.querySelector('.medicine-select');
        const quantity = row.querySelector('.quantity-input').value;
        
        if (select.value && quantity) {
            items.push({
                medicine_id: select.value,
                quantity: quantity,
                unit_price: select.selectedOptions[0].dataset.price
            });
        }
    });
    
    formData.append('items', JSON.stringify(items));
    
    fetch('process_sale.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Redirect to sales history page
            window.location.href = data.redirect;
        } else {
            alert('Error: ' + data.error);
        }
    })
    .catch(error => {
        alert('Error processing sale: ' + error);
    });
});
</script>

<?php require_once '../../includes/footer.php'; ?>
