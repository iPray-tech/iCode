<?php
require_once '../../config/database.php';
require_once '../../includes/auth.php';
requireLogin();

if (!isset($_GET['id'])) {
    exit('Invalid request');
}

$sale_id = (int)$_GET['id'];

// Get sale details
$stmt = $conn->prepare("
    SELECT s.*, 
           COALESCE(p.name, '') as patient_name,
           COALESCE(p.phone, '') as patient_phone,
           COALESCE(pr.doctor_name, '') as doctor_name,
           u.username as employee_name
    FROM sales s
    LEFT JOIN patients p ON s.patient_id = p.id
    LEFT JOIN prescriptions pr ON s.prescription_id = pr.id
    LEFT JOIN users u ON s.employee_id = u.id
    WHERE s.id = ? AND s.employee_id = ?
");
$stmt->bind_param("ii", $sale_id, $_SESSION['user_id']);
$stmt->execute();
$sale = $stmt->get_result()->fetch_assoc();

if (!$sale) {
    exit('Sale not found');
}

// Get sale items
$stmt = $conn->prepare("
    SELECT si.*, m.name as medicine_name, m.unit_price
    FROM sale_items si
    JOIN medicines m ON si.medicine_id = m.id
    WHERE si.sale_id = ?
");
$stmt->bind_param("i", $sale_id);
$stmt->execute();
$items = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Receipt #<?php echo $sale_id; ?> - <?php echo COMPANY_NAME; ?></title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            font-size: 14px;
        }
        .receipt {
            max-width: 800px;
            margin: 0 auto;
        }
        .header {
            text-align: center;
            margin-bottom: 20px;
        }
        .company-name {
            font-size: 24px;
            font-weight: bold;
            margin-bottom: 5px;
        }
        .company-info {
            margin-bottom: 5px;
        }
        .receipt-details {
            margin-bottom: 20px;
        }
        .receipt-details table {
            width: 100%;
        }
        .receipt-details td {
            padding: 3px 0;
        }
        .items-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        .items-table th, .items-table td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        .items-table th {
            background-color: #f8f9fa;
        }
        .total {
            text-align: right;
            margin-top: 20px;
            font-weight: bold;
        }
        .footer {
            text-align: center;
            margin-top: 30px;
            font-size: 12px;
        }
        @media print {
            body {
                padding: 0;
            }
            .no-print {
                display: none;
            }
        }
    </style>
</head>
<body>
    <div class="receipt">
        <div class="header">
            <div class="company-name"><?php echo COMPANY_NAME; ?></div>
            <div class="company-info"><?php echo COMPANY_ADDRESS; ?></div>
            <div class="company-info">Tel: <?php echo COMPANY_PHONE; ?></div>
            <div class="company-info">Email: <?php echo COMPANY_EMAIL; ?></div>
        </div>

        <div class="receipt-details">
            <table>
                <tr>
                    <td><strong>Receipt #:</strong> <?php echo $sale_id; ?></td>
                    <td><strong>Date:</strong> <?php echo formatDate($sale['sale_date'], 'Y-m-d H:i'); ?></td>
                </tr>
                <tr>
                    <td><strong>Customer:</strong> <?php echo htmlspecialchars($sale['customer_name']); ?></td>
                    <td><strong>Served By:</strong> <?php echo htmlspecialchars($sale['employee_name']); ?></td>
                </tr>
                <?php if ($sale['patient_name']): ?>
                <tr>
                    <td><strong>Patient:</strong> <?php echo htmlspecialchars($sale['patient_name']); ?></td>
                    <td><strong>Phone:</strong> <?php echo htmlspecialchars($sale['patient_phone']); ?></td>
                </tr>
                <?php if ($sale['doctor_name']): ?>
                <tr>
                    <td colspan="2"><strong>Doctor:</strong> <?php echo htmlspecialchars($sale['doctor_name']); ?></td>
                </tr>
                <?php endif; ?>
                <?php endif; ?>
            </table>
        </div>

        <table class="items-table">
            <thead>
                <tr>
                    <th>Item</th>
                    <th>Quantity</th>
                    <th>Unit Price</th>
                    <th>Total</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($item = $items->fetch_assoc()): ?>
                <tr>
                    <td><?php echo htmlspecialchars($item['medicine_name']); ?></td>
                    <td><?php echo $item['quantity']; ?></td>
                    <td class="text-end"><?php echo formatMoney($item['unit_price']); ?></td>
                    <td class="text-end"><?php echo formatMoney($item['total_price']); ?></td>
                </tr>
                <?php endwhile; ?>
            </tbody>
            <tfoot>
                <tr>
                    <th colspan="3" style="text-align: right;">Total:</th>
                    <th><?php echo formatMoney($sale['total_amount']); ?></th>
                </tr>
            </tfoot>
        </table>

        <div class="footer">
            Thank you for your business!<br>
            Please keep this receipt for your records.
        </div>

        <div class="no-print" style="margin-top: 20px; text-align: center;">
            <button onclick="window.print()">Print Receipt</button>
            <button onclick="window.close()">Close</button>
        </div>
    </div>

    <script>
        // Auto print when the page loads
        window.onload = function() {
            if (!window.location.search.includes('noprint')) {
                window.print();
            }
        };
    </script>
</body>
</html> 