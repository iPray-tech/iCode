<?php
require_once '../../config/database.php';
require_once '../../includes/auth.php';
requireLogin();

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'error' => 'Invalid request method']);
    exit;
}

$customer_name = $_POST['customer_name'] ?? '';
$patient_id = $_POST['patient_id'] ?? null;
$prescription_id = $_POST['prescription_id'] ?? null;
$items = json_decode($_POST['items'] ?? '[]', true);

if (empty($customer_name) || empty($items)) {
    echo json_encode(['success' => false, 'error' => 'Missing required data']);
    exit;
}

// Start transaction
$conn->begin_transaction();

try {
    // Create sale record
    $stmt = $conn->prepare("INSERT INTO sales (customer_name, employee_id, patient_id, prescription_id, total_amount) VALUES (?, ?, ?, ?, 0)");
    $stmt->bind_param("siid", $customer_name, $_SESSION['user_id'], $patient_id, $prescription_id);
    $stmt->execute();
    $sale_id = $conn->insert_id;
    
    $total_amount = 0;
    
    // Process each sale item
    foreach ($items as $item) {
        // Verify stock availability
        $stmt = $conn->prepare("SELECT stock_quantity, unit_price FROM medicines WHERE id = ?");
        $stmt->bind_param("i", $item['medicine_id']);
        $stmt->execute();
        $medicine = $stmt->get_result()->fetch_assoc();
        
        if (!$medicine || $medicine['stock_quantity'] < $item['quantity']) {
            throw new Exception("Insufficient stock for one or more items");
        }
        
        // Calculate item total
        $item_total = $item['quantity'] * $medicine['unit_price'];
        $total_amount += $item_total;
        
        // Add sale item
        $stmt = $conn->prepare("INSERT INTO sale_items (sale_id, medicine_id, quantity, unit_price, total_price) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("iiids", $sale_id, $item['medicine_id'], $item['quantity'], $medicine['unit_price'], $item_total);
        $stmt->execute();
        
        // Update stock
        $stmt = $conn->prepare("UPDATE medicines SET stock_quantity = stock_quantity - ? WHERE id = ?");
        $stmt->bind_param("ii", $item['quantity'], $item['medicine_id']);
        $stmt->execute();
    }
    
    // Update sale total
    $stmt = $conn->prepare("UPDATE sales SET total_amount = ? WHERE id = ?");
    $stmt->bind_param("di", $total_amount, $sale_id);
    $stmt->execute();
    
    $conn->commit();
    
    // Set success message in session
    $_SESSION['success_message'] = "Sale #$sale_id has been completed successfully!";
    
    // Return success with redirect URL
    echo json_encode([
        'success' => true, 
        'redirect' => '../sales/history.php',
        'sale_id' => $sale_id
    ]);

} catch (Exception $e) {
    $conn->rollback();
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
?> 