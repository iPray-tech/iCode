<?php
require_once '../../config/database.php';
require_once '../../includes/auth.php';
requireLogin();

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $date = $_POST['date'] ?? date('Y-m-d');
    $cash_amount = floatval($_POST['cash_amount'] ?? 0);
    $system_amount = floatval($_POST['system_amount'] ?? 0);
    $notes = $_POST['notes'] ?? '';

    try {
        $conn->begin_transaction();

        // Get total sales for the day to double-check
        $stmt = $conn->prepare("
            SELECT COALESCE(SUM(total_amount), 0) as total_sales
            FROM sales 
            WHERE employee_id = ? 
            AND DATE(sale_date) = ?
            AND status = 'completed'
            AND payment_method = 'cash'
        ");
        $stmt->bind_param("is", $_SESSION['user_id'], $date);
        $stmt->execute();
        $total_sales = $stmt->get_result()->fetch_assoc()['total_sales'];

        // Verify system amount matches database
        if (abs($total_sales - $system_amount) > 0.01) { // Allow for small rounding differences
            throw new Exception('System amount mismatch. Please refresh and try again.');
        }

        // Check for existing closure request
        $stmt = $conn->prepare("
            SELECT id, status 
            FROM account_closures 
            WHERE requested_by = ? AND date = ?
            ORDER BY requested_at DESC 
            LIMIT 1
        ");
        $stmt->bind_param("is", $_SESSION['user_id'], $date);
        $stmt->execute();
        $existing = $stmt->get_result()->fetch_assoc();

        if ($existing && $existing['status'] !== 'rejected') {
            throw new Exception('An account closure request already exists for this date');
        }

        // Create new closure request
        $stmt = $conn->prepare("
            INSERT INTO account_closures (
                requested_by, date, cash_amount, total_sales, notes, status
            ) VALUES (?, ?, ?, ?, ?, 'pending')
        ");
        $stmt->bind_param("isdds", $_SESSION['user_id'], $date, $cash_amount, $total_sales, $notes);
        $stmt->execute();

        // Log the activity
        logUserActivity($_SESSION['user_id'], 'account_closure_request', 
            "Requested account closure for date: $date. Cash: $cash_amount, System: $total_sales");

        $conn->commit();
        echo json_encode(['success' => true]);

    } catch (Exception $e) {
        $conn->rollback();
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
} else {
    echo json_encode(['success' => false, 'error' => 'Invalid request method']);
} 