<?php
require_once '../../config/database.php';
require_once '../../includes/auth.php';
requireLogin();

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'error' => 'Invalid request method']);
    exit;
}

$sale_id = $_POST['sale_id'] ?? '';
$reason = $_POST['reason'] ?? '';

if (empty($sale_id) || empty($reason)) {
    echo json_encode(['success' => false, 'error' => 'Missing required fields']);
    exit;
}

try {
    // Add this check before inserting new request
    $stmt = $conn->prepare("
        SELECT id FROM sale_reversals 
        WHERE sale_id = ? AND status = 'pending'
    ");
    $stmt->bind_param("i", $sale_id);
    $stmt->execute();
    if ($stmt->get_result()->num_rows > 0) {
        echo json_encode(['success' => false, 'error' => 'A reversal request is already pending for this sale']);
        exit;
    }

    // Also check if sale is already reversed
    $stmt = $conn->prepare("SELECT status FROM sales WHERE id = ?");
    $stmt->bind_param("i", $sale_id);
    $stmt->execute();
    $sale = $stmt->get_result()->fetch_assoc();
    if ($sale['status'] === 'reversed') {
        echo json_encode(['success' => false, 'error' => 'This sale has already been reversed']);
        exit;
    }

    $stmt = $conn->prepare("
        INSERT INTO sale_reversals (sale_id, requested_by, reason) 
        VALUES (?, ?, ?)
    ");
    $stmt->bind_param("iis", $sale_id, $_SESSION['user_id'], $reason);
    
    if ($stmt->execute()) {
        logUserActivity($_SESSION['user_id'], 'reversal_request', "Requested reversal for sale #$sale_id");
        echo json_encode(['success' => true]);
    } else {
        throw new Exception($conn->error);
    }
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
} 