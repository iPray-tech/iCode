<?php
require_once '../../config/database.php';
require_once '../../includes/auth.php';
require_once '../../includes/header.php';
requireLogin();

if (!isset($_GET['id'])) {
    header('Location: daily_summary.php');
    exit();
}

$sale_id = (int)$_GET['id'];

// Get sale details
$stmt = $conn->prepare("
    SELECT s.*, 
           u.username as employee_name,
           p.name as patient_name,
           pr.id as prescription_id
    FROM sales s
    LEFT JOIN users u ON s.employee_id = u.id
    LEFT JOIN patients p ON s.patient_id = p.id
    LEFT JOIN prescriptions pr ON s.prescription_id = pr.id
    WHERE s.id = ?
");
$stmt->bind_param("i", $sale_id);
$stmt->execute();
$sale = $stmt->get_result()->fetch_assoc();

if (!$sale) {
    header('Location: daily_summary.php');
    exit();
}

// Get sale items
$stmt = $conn->prepare("
    SELECT si.*, m.name as medicine_name, m.generic_name
    FROM sale_items si
    JOIN medicines m ON si.medicine_id = m.id
    WHERE si.sale_id = ?
");
$stmt->bind_param("i", $sale_id);
$stmt->execute();
$items = $stmt->get_result();
?>

<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="card-title mb-0">Sale Details #<?php echo $sale_id; ?></h5>
        <a href="daily_summary.php" class="btn btn-secondary">Back to Summary</a>
    </div>
    <div class="card-body">
        <!-- Sale Information -->
        <div class="row">
            <div class="col-md-6">
                <table class="table">
                    <tr>
                        <th>Date/Time:</th>
                        <td><?php echo formatDate($sale['sale_date'], 'Y-m-d H:i'); ?></td>
                    </tr>
                    <tr>
                        <th>Employee:</th>
                        <td><?php echo htmlspecialchars($sale['employee_name'] ?? ''); ?></td>
                    </tr>
                    <tr>
                        <th>Customer:</th>
                        <td><?php echo htmlspecialchars($sale['customer_name'] ?? ''); ?></td>
                    </tr>
                    <tr>
                        <th>Status:</th>
                        <td>
                            <span class="badge bg-<?php 
                                echo $sale['status'] === 'completed' ? 'success' : 
                                    ($sale['status'] === 'reversed' ? 'danger' : 'warning'); 
                            ?>">
                                <?php echo ucfirst($sale['status']); ?>
                            </span>
                        </td>
                    </tr>
                </table>
            </div>
            <div class="col-md-6">
                <table class="table">
                    <tr>
                        <th>Total Amount:</th>
                        <td><?php echo formatMoney($sale['total_amount']); ?></td>
                    </tr>
                    <tr>
                        <th>Payment Method:</th>
                        <td><?php echo ucfirst($sale['payment_method']); ?></td>
                    </tr>
                    <?php if ($sale['patient_name']): ?>
                    <tr>
                        <th>Patient:</th>
                        <td><?php echo htmlspecialchars($sale['patient_name']); ?></td>
                    </tr>
                    <?php endif; ?>
                    <?php if ($sale['prescription_id']): ?>
                    <tr>
                        <th>Prescription:</th>
                        <td>
                            <a href="../prescriptions/view.php?id=<?php echo $sale['prescription_id']; ?>">
                                View Prescription
                            </a>
                        </td>
                    </tr>
                    <?php endif; ?>
                </table>
            </div>
        </div>

        <!-- Sale Items -->
        <h6 class="mt-4">Items Sold</h6>
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Medicine</th>
                        <th>Generic Name</th>
                        <th>Quantity</th>
                        <th>Unit Price</th>
                        <th>Total</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($item = $items->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($item['medicine_name']); ?></td>
                        <td><?php echo htmlspecialchars($item['generic_name'] ?? ''); ?></td>
                        <td><?php echo $item['quantity']; ?></td>
                        <td><?php echo formatMoney($item['unit_price']); ?></td>
                        <td><?php echo formatMoney($item['total_price']); ?></td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require_once '../../includes/footer.php'; ?> 