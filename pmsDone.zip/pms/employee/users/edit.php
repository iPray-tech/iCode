<?php
require_once '../../config/database.php';
require_once '../../includes/auth.php';
require_once '../../includes/header.php';
requireLogin();

$success = $error = '';
$user = null;

if (!isset($_GET['id'])) {
    redirectTo('users/list.php');
}

$id = (int)$_GET['id'];

// Get user details
$stmt = $conn->prepare("SELECT id, username, email, role FROM users WHERE id = ? AND role != 'admin'");
$stmt->bind_param("i", $id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

if (!$user) {
    redirectTo('users/list.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCSRFToken($_POST['csrf_token'])) {
        $error = "Invalid request";
    } else {
        $email = $_POST['email'] ?? '';
        $password = $_POST['password'] ?? '';
        $confirm_password = $_POST['confirm_password'] ?? '';
        
        if (empty($email)) {
            $error = "Email is required";
        } else {
            $conn->begin_transaction();
            
            try {
                // Update email
                $stmt = $conn->prepare("UPDATE users SET email = ? WHERE id = ?");
                $stmt->bind_param("si", $email, $id);
                $stmt->execute();
                
                // Update password if provided
                if (!empty($password)) {
                    if ($password !== $confirm_password) {
                        throw new Exception("Passwords do not match");
                    }
                    
                    $password_errors = validatePassword($password);
                    if (!empty($password_errors)) {
                        throw new Exception(implode("<br>", $password_errors));
                    }
                    
                    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                    $stmt = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
                    $stmt->bind_param("si", $hashed_password, $id);
                    $stmt->execute();
                    
                    logUserActivity(
                        $_SESSION['user_id'],
                        'update_user_password',
                        "Updated password for user: {$user['username']}"
                    );
                }
                
                $conn->commit();
                $success = "User updated successfully";
                
                // Refresh user data
                $stmt = $conn->prepare("SELECT id, username, email, role FROM users WHERE id = ?");
                $stmt->bind_param("i", $id);
                $stmt->execute();
                $user = $stmt->get_result()->fetch_assoc();
                
                logUserActivity(
                    $_SESSION['user_id'],
                    'update_user',
                    "Updated user details for: {$user['username']}"
                );
                
            } catch (Exception $e) {
                $conn->rollback();
                $error = $e->getMessage();
            }
        }
    }
}
?>

<div class="card">
    <div class="card-header">
        <h5 class="card-title mb-0">Edit User</h5>
    </div>
    <div class="card-body">
        <?php if ($success): ?>
            <div class="alert alert-success"><?php echo $success; ?></div>
        <?php endif; ?>
        
        <?php if ($error): ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php endif; ?>
        
        <form method="POST" action="">
            <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
            
            <div class="mb-3">
                <label for="username" class="form-label">Username</label>
                <input type="text" class="form-control" id="username" 
                       value="<?php echo htmlspecialchars($user['username']); ?>" readonly>
                <small class="text-muted">Username cannot be changed</small>
            </div>
            
            <div class="mb-3">
                <label for="email" class="form-label">Email</label>
                <input type="email" class="form-control" id="email" name="email" 
                       value="<?php echo htmlspecialchars($user['email']); ?>" required>
            </div>
            
            <div class="mb-3">
                <label for="password" class="form-label">New Password</label>
                <input type="password" class="form-control" id="password" name="password">
                <small class="text-muted">Leave blank to keep current password</small>
            </div>
            
            <div class="mb-3">
                <label for="confirm_password" class="form-label">Confirm New Password</label>
                <input type="password" class="form-control" id="confirm_password" name="confirm_password">
            </div>
            
            <button type="submit" class="btn btn-primary">Update User</button>
            <a href="list.php" class="btn btn-secondary">Cancel</a>
        </form>
    </div>
</div>

<?php require_once '../../includes/footer.php'; ?> 