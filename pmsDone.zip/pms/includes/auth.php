<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if user is logged in
function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

// Check if user is admin
function isAdmin() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
}

// Check if user is employee
function isEmployee() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'employee';
}

// Require login for protected pages
function requireLogin() {
    if (!isLoggedIn()) {
        header('Location: ' . getBasePath() . 'login.php');
        exit();
    }
}

// Require admin role
function requireAdmin() {
    requireLogin();
    if (!isAdmin()) {
        header('Location: ' . getBasePath() . 'access_denied.php');
        exit();
    }
}

// Require employee role
function requireEmployee() {
    requireLogin();
    if (!isEmployee()) {
        header('Location: ' . getBasePath() . 'access_denied.php');
        exit();
    }
}

// Redirect to appropriate dashboard based on role
function redirectToUserDashboard() {
    if (isAdmin()) {
        header('Location: ' . getBasePath() . 'admin/dashboard.php');
    } else {
        header('Location: ' . getBasePath() . 'employee/dashboard.php');
    }
    exit();
}

// Get user role
function getUserRole() {
    return $_SESSION['role'] ?? '';
}

// Get user ID
function getUserId() {
    return $_SESSION['user_id'] ?? null;
}

// Get username
function getUsername() {
    return $_SESSION['username'] ?? '';
}

// Set user session
function setUserSession($user) {
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['username'] = $user['username'];
    $_SESSION['role'] = $user['role'];
    $_SESSION['last_activity'] = time();
}

// Clear user session
function clearUserSession() {
    session_unset();
    session_destroy();
}

// Check session timeout (30 minutes)
function checkSessionTimeout() {
    $timeout = 1800; // 30 minutes
    if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > $timeout)) {
        clearUserSession();
        header('Location: ' . getBasePath() . 'login.php?timeout=1');
        exit();
    }
    $_SESSION['last_activity'] = time();
}

// Update last activity
function updateLastActivity() {
    $_SESSION['last_activity'] = time();
}

function logout() {
    session_destroy();
    session_unset();
    $base_path = getBasePath();
    header("Location: {$base_path}index.php");
    exit();
}

function login($username, $password) {
    global $conn;
    
    $username = $conn->real_escape_string($username);
    $stmt = $conn->prepare("SELECT id, username, password, role, email FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();
        if (password_verify($password, $user['password'])) {
            // Set session variables
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['role'] = $user['role'];
            $_SESSION['email'] = $user['email'];
            
            // Try to update last login time
            try {
                $stmt = $conn->prepare("UPDATE users SET last_login = NOW() WHERE id = ?");
                $stmt->bind_param("i", $user['id']);
                $stmt->execute();
            } catch (Exception $e) {
                // If the column doesn't exist, create it
                if (strpos($e->getMessage(), "Unknown column 'last_login'") !== false) {
                    $conn->query("ALTER TABLE users ADD COLUMN last_login DATETIME NULL DEFAULT NULL");
                    // Try the update again
                    $stmt = $conn->prepare("UPDATE users SET last_login = NOW() WHERE id = ?");
                    $stmt->bind_param("i", $user['id']);
                    $stmt->execute();
                }
            }
            
            return true;
        }
    }
    return false;
}

// Add these security headers
header("X-Frame-Options: SAMEORIGIN");
header("X-XSS-Protection: 1; mode=block");
header("X-Content-Type-Options: nosniff");
header("Referrer-Policy: strict-origin-when-cross-origin");
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') {
    header("Strict-Transport-Security: max-age=31536000; includeSubDomains");
}
?>
