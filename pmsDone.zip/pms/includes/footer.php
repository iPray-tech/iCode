        </div> <!-- Close container from header -->
        <footer class="footer mt-auto py-3 bg-light">
            <div class="container">
                <div class="text-center">
                    <small class="text-muted">
                        &copy; <?php echo date('Y') . ' ' . COMPANY_NAME; ?> | 
                        <?php echo COMPANY_ADDRESS; ?> | 
                        Tel: <?php echo COMPANY_PHONE; ?>
                    </small>
                </div>
            </div>
        </footer>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    </body>
</html> 