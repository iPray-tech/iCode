function logUserActivity($user_id, $action_type, $details = '') {
    global $conn;
    try {
        $stmt = $conn->prepare("
            INSERT INTO user_activity (user_id, action_type, details) 
            VALUES (?, ?, ?)
        ");
        $stmt->bind_param("iss", $user_id, $action_type, $details);
        $stmt->execute();
        return true;
    } catch (Exception $e) {
        // Silently fail if table doesn't exist
        return false;
    }
}

// Add this error handling function
function handleError($errno, $errstr, $errfile, $errline) {
    $error_message = date('Y-m-d H:i:s') . " Error: [$errno] $errstr - $errfile:$errline\n";
    error_log($error_message, 3, "../logs/error.log");
    
    if (ini_get('display_errors')) {
        return false; // Display error in development
    } else {
        return true; // Suppress error details in production
    }
}
set_error_handler("handleError");

