<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/auth.php';
requireLogin();

$base_path = getBasePath();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="<?php echo $base_path; ?>index.php"><?php echo COMPANY_NAME; ?></a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <?php if (isAdmin()): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo $base_path; ?>admin/dashboard.php">Dashboard</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo $base_path; ?>admin/inventory/add.php">Inventory</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo $base_path; ?>admin/inventory/stock_history.php">Stock History</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo $base_path; ?>admin/suppliers/list.php">Suppliers</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo $base_path; ?>admin/sales/reversals.php">Reversals</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo $base_path; ?>admin/account_closures.php">
                                <i class="bi bi-cash-stack"></i> Account Closures
                            </a>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="reportsDropdown" role="button" 
                               data-bs-toggle="dropdown" aria-expanded="false">
                                Reports
                            </a>
                            <ul class="dropdown-menu" aria-labelledby="reportsDropdown">
                                <li><a class="dropdown-item" href="<?php echo $base_path; ?>admin/reports/sales.php">Sales Report</a></li>
                                <li><a class="dropdown-item" href="<?php echo $base_path; ?>admin/reports/inventory.php">Inventory Report</a></li>
                                <li><a class="dropdown-item" href="<?php echo $base_path; ?>admin/reports/audit.php">Audit Log</a></li>
                                <li><a class="dropdown-item" href="<?php echo $base_path; ?>admin/reports/shortages.php">Employee Shortages</a></li>
                            </ul>
                        </li>
                    <?php else: ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo $base_path; ?>employee/dashboard.php">Dashboard</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo $base_path; ?>employee/sales/new_sale.php">New Sale</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo $base_path; ?>employee/sales/history.php">Sales History</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo $base_path; ?>employee/patients/list.php">Patients</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo $base_path; ?>employee/prescriptions/list.php">Prescriptions</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo $base_path; ?>employee/sales/daily_summary.php">
                                <i class="bi bi-calendar-check"></i> Daily Summary
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo $base_path; ?>employee/account_closures/view.php">Account Closures</a>
                        </li>
                    <?php endif; ?>
                    <!-- Users menu item available for both admin and employee -->
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo $base_path; ?><?php echo isAdmin() ? 'admin' : 'employee'; ?>/users/list.php">Users</a>
                    </li>
                </ul>
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo $base_path; ?>logout.php">Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <div class="container mt-4">
