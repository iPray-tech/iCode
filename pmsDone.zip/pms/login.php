<?php
require_once 'config/database.php';
require_once 'includes/auth.php';

// Redirect if already logged in
if (isLoggedIn()) {
    $redirect = isAdmin() ? 'admin/dashboard.php' : 'employee/dashboard.php';
    redirectTo($redirect);
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';
    
    if (empty($username) || empty($password)) {
        $error = "Both username and password are required";
    } else {
        if (login($username, $password)) {
            // Update last login time
            $stmt = $conn->prepare("UPDATE users SET last_login = NOW() WHERE id = ?");
            $stmt->bind_param("i", $_SESSION['user_id']);
            $stmt->execute();
            
            logUserActivity($_SESSION['user_id'], 'login', 'User logged in successfully');
            
            // Redirect based on role
            $redirect = $_SESSION['role'] === 'admin' ? 'admin/dashboard.php' : 'employee/dashboard.php';
            redirectTo($redirect);
        } else {
            $error = "Invalid username or password";
            logUserActivity(0, 'login_failed', "Failed login attempt for username: $username");
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
            height: 100vh;
            display: flex;
            align-items: center;
            padding-top: 40px;
            padding-bottom: 40px;
        }
        .login-container {
            max-width: 400px;
            margin: 0 auto;
            padding: 15px;
        }
        .logo {
            text-align: center;
            margin-bottom: 30px;
        }
        .logo h1 {
            color: #0d6efd;
            font-size: 2rem;
            margin-bottom: 0.5rem;
        }
        .card {
            border-radius: 1rem;
            box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15);
        }
        .card-body {
            padding: 2rem;
        }
        .form-control {
            padding: 0.75rem 1rem;
            font-size: 1rem;
            border-radius: 0.5rem;
        }
        .btn-primary {
            padding: 0.75rem 1rem;
            font-size: 1rem;
            border-radius: 0.5rem;
        }
        .company-info {
            text-align: center;
            margin-top: 2rem;
            color: #6c757d;
        }
    </style>
</head>
<body>
    <div class="container login-container">
        <div class="logo">
            <h1><?php echo COMPANY_NAME; ?></h1>
            <p class="text-muted"><?php echo SITE_NAME; ?></p>
        </div>
        
        <div class="card">
            <div class="card-body">
                <h5 class="card-title text-center mb-4">Login to Your Account</h5>
                
                <?php if ($error): ?>
                    <div class="alert alert-danger"><?php echo $error; ?></div>
                <?php endif; ?>
                
                <form method="POST" action="">
                    <div class="mb-3">
                        <label for="username" class="form-label">Username</label>
                        <input type="text" class="form-control" id="username" name="username" 
                               value="<?php echo htmlspecialchars($_POST['username'] ?? ''); ?>" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="password" class="form-label">Password</label>
                        <input type="password" class="form-control" id="password" name="password" required>
                    </div>
                    
                    <button type="submit" class="btn btn-primary w-100 mt-3">Login</button>
                </form>
            </div>
        </div>
        
        <div class="company-info">
            <p class="mb-1"><?php echo COMPANY_ADDRESS; ?></p>
            <p class="mb-1">Tel: <?php echo COMPANY_PHONE; ?></p>
            <p class="mb-0">Email: <?php echo COMPANY_EMAIL; ?></p>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 