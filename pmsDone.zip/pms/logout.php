<?php
require_once 'config/database.php';
require_once 'includes/auth.php';

// Try to log the activity, but continue with logout even if it fails
if (isLoggedIn()) {
    try {
        logUserActivity($_SESSION['user_id'], 'logout', 'User logged out');
    } catch (Exception $e) {
        // Continue with logout even if logging fails
    }
}

// Clear all session data
session_start();
$_SESSION = array();

// Delete the session cookie
if (isset($_COOKIE[session_name()])) {
    setcookie(session_name(), '', time() - 3600, '/');
}

// Destroy the session
session_destroy();

// Redirect to index
header("Location: index.php");
exit();
?>
