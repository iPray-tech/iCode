<?php
$password = 'Ten+ten=20'; // Input your password here

$options = [
    'cost' => 12, // Adjust the computational cost
];
$hashedPassword = password_hash($password, PASSWORD_DEFAULT, $options);

echo "Password: $password<br>";
echo "Hashed Password: $hashedPassword<br>";
?>